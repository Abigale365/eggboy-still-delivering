"""精修时看局部：打开 .blend，从指定方向对准指定点渲一张特写（Workbench 贴图 + 棚灯）。

blender -b <文件.blend> -P closeup_blend.py -- <输出.png> <目标x,y,z> <相机方向x,y,z> <画面宽(米)> [灰模=0]
例：看正面底座   -- out.png 0,-0.8,0.2 0,-1,0.15 1.2
"""
import sys

import bpy
from mathutils import Vector

a = sys.argv[sys.argv.index("--") + 1:]
out = a[0]
tgt = Vector(map(float, a[1].split(",")))
d = Vector(map(float, a[2].split(","))).normalized()
width = float(a[3])
solid = len(a) > 4 and a[4] == "1"
scene = bpy.context.scene
for o in scene.objects:
    if o.name.startswith("COL_"):
        o.hide_render = True
cam = bpy.data.objects.new("ccam", bpy.data.cameras.new("ccam"))
scene.collection.objects.link(cam); scene.camera = cam
cam.data.type = "ORTHO"; cam.data.ortho_scale = width; cam.data.clip_end = 50
cam.location = tgt + d * 6
cam.rotation_euler = (-d).to_track_quat("-Z", "Y").to_euler()
scene.render.engine = "BLENDER_WORKBENCH"
sh = scene.display.shading
sh.light = "STUDIO"; sh.color_type = "SINGLE" if solid else "TEXTURE"; sh.single_color = (0.8, 0.8, 0.8)
sh.show_cavity = True; sh.cavity_type = "BOTH"
if scene.world is None:
    scene.world = bpy.data.worlds.new("w")
scene.world.color = (0.92, 0.92, 0.92)
scene.render.resolution_x = scene.render.resolution_y = 900
scene.view_settings.view_transform = "Standard"
scene.render.filepath = out
bpy.ops.render.render(write_still=True)
print("CLOSEUP", out)
