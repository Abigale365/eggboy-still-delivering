"""Blender 后台脚本：把 GLB 渲染成“展示级”主图（Cycles + 三点布光 + 天光 + 地面接触阴影 + 景深 + AgX 调色）。

blender -b --factory-startup -P hero_render.py -- <模型.glb> <输出.png> [yaw=35] [elev=16] [分辨率=1400] [采样=96] [模式=studio|dusk]

和 render_views.py 的区别：render_views 是给验收量数的正交平光图，不能当展示图；
本脚本只用来出“给人看”的主图 / 比赛报告封面，不参与验收判定。
约定：Z 朝上，正面朝 -Y；COL_ 开头的碰撞体不渲染。
"""
import math, os, sys
import bpy
from mathutils import Vector

a = sys.argv[sys.argv.index("--") + 1:]
src, out = a[0], a[1]
yaw = math.radians(float(a[2]) if len(a) > 2 else 35)
elev = math.radians(float(a[3]) if len(a) > 3 else 16)
res = int(a[4]) if len(a) > 4 else 1400
samples = int(a[5]) if len(a) > 5 else 96
mode = a[6] if len(a) > 6 else "studio"

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=src)
sc = bpy.context.scene
for o in list(sc.objects):
    if o.name.startswith("COL_"):
        o.hide_render = True
meshes = [o for o in sc.objects if o.type == "MESH" and not o.hide_render]
bpy.context.view_layer.update()
pts = [o.matrix_world @ Vector(c) for o in meshes for c in o.bound_box]
lo = Vector([min(p[i] for p in pts) for i in range(3)])
hi = Vector([max(p[i] for p in pts) for i in range(3)])
ctr, size = (lo + hi) / 2, hi - lo
R = max(size)

# 材质：去掉导出带来的过高光泽，避免塑料感；保留贴图
for m in bpy.data.materials:
    if m.use_nodes:
        for n in m.node_tree.nodes:
            if n.type == "BSDF_PRINCIPLED":
                r = n.inputs["Roughness"]
                if not r.is_linked:
                    r.default_value = max(r.default_value, 0.45)
                if "Specular IOR Level" in n.inputs and not n.inputs["Specular IOR Level"].is_linked:
                    n.inputs["Specular IOR Level"].default_value = 0.35

# 渲染设置
sc.render.engine = "CYCLES"
cy = sc.cycles
cy.device = "CPU"; cy.samples = samples; cy.use_denoising = True
cy.max_bounces = 6; cy.diffuse_bounces = 3; cy.glossy_bounces = 3
cy.sample_clamp_indirect = 8
sc.render.resolution_x = sc.render.resolution_y = res
sc.render.film_transparent = False
sc.view_settings.view_transform = "Filmic"   # AgX 会把橙红压成粉色，Filmic 保饱和
try:
    sc.view_settings.look = "Medium High Contrast"
except Exception:
    pass
sc.view_settings.exposure = -0.8

# 世界：天光 + 柔和渐变背景（相机看到的是渐变，光照来自天空）
w = bpy.data.worlds.new("w"); sc.world = w; w.use_nodes = True
nt = w.node_tree; nt.nodes.clear()
out_n = nt.nodes.new("ShaderNodeOutputWorld")
if mode == "dusk":
    top, bot, sky_e = (0.20, 0.25, 0.45, 1), (0.95, 0.60, 0.40, 1), 0.7
    key_col, key_e, rim_col = (1.0, 0.62, 0.35), 900, (0.45, 0.6, 1.0)
else:
    top, bot, sky_e = (0.50, 0.68, 0.90, 1), (0.96, 0.88, 0.76, 1), 0.8
    key_col, key_e, rim_col = (1.0, 0.90, 0.78), 700, (0.6, 0.75, 1.0)
tc = nt.nodes.new("ShaderNodeTexCoord")
sep = nt.nodes.new("ShaderNodeSeparateXYZ")
ramp = nt.nodes.new("ShaderNodeValToRGB")
ramp.color_ramp.elements[0].color = bot
ramp.color_ramp.elements[1].color = top
ramp.color_ramp.elements[0].position = 0.45
ramp.color_ramp.elements[1].position = 0.75
bg = nt.nodes.new("ShaderNodeBackground"); bg.inputs[1].default_value = sky_e
nt.links.new(tc.outputs["Generated"], sep.inputs[0]) if False else None
nt.links.new(tc.outputs["Window"], sep.inputs[0]) if False else None
# 用 Generated 坐标的 Z 作渐变轴
tc2 = nt.nodes.new("ShaderNodeTexCoord")
mp = nt.nodes.new("ShaderNodeMapping")
nt.links.new(tc2.outputs["Generated"], sep.inputs[0])
nt.links.new(sep.outputs["Z"], ramp.inputs[0])
nt.links.new(ramp.outputs[0], bg.inputs[0])
nt.links.new(bg.outputs[0], out_n.inputs[0])

# 地面：大圆盘，接收接触阴影；颜色柔和，边缘靠雾化淡出
bpy.ops.mesh.primitive_circle_add(vertices=128, radius=R * 6, fill_type="NGON",
                                  location=(ctr.x, ctr.y, lo.z - 0.002))
g = bpy.context.object; g.name = "ground"
gm = bpy.data.materials.new("ground"); gm.use_nodes = True
b = gm.node_tree.nodes["Principled BSDF"]
b.inputs["Base Color"].default_value = (0.78, 0.70, 0.58, 1) if mode != "dusk" else (0.35, 0.32, 0.36, 1)
b.inputs["Roughness"].default_value = 0.85
g.data.materials.append(gm)

# 灯：主光(暖,大面光,右前上) + 轮廓光(冷,左后) + 补光(弱) 
def area(name, loc, color, energy, size_):
    d = bpy.data.lights.new(name, "AREA"); d.energy = energy; d.color = color; d.size = size_
    o = bpy.data.objects.new(name, d); sc.collection.objects.link(o)
    o.location = loc
    o.rotation_euler = (ctr - Vector(loc)).to_track_quat("-Z", "Y").to_euler()
    return o
def pol(deg_yaw, dist, h):
    return Vector((ctr.x + dist * math.sin(math.radians(deg_yaw)),
                   ctr.y - dist * math.cos(math.radians(deg_yaw)), ctr.z + h))
area("key", pol(math.degrees(yaw) + 45, R * 2.6, R * 1.6), key_col, key_e * (R ** 2) / 6, R * 2.2)
area("rim", pol(math.degrees(yaw) + 180 - 40, R * 2.4, R * 1.2), rim_col, 500 * (R ** 2) / 4, R * 1.6)
area("fill", pol(math.degrees(yaw) - 70, R * 3.0, R * 0.5), (1, 0.95, 0.9), 120 * (R ** 2) / 4, R * 3)

# 相机：50mm 透视 + 轻微景深，焦点在模型中心
cam_d = bpy.data.cameras.new("cam"); cam_d.lens = 50
cam = bpy.data.objects.new("cam", cam_d); sc.collection.objects.link(cam); sc.camera = cam
fov = 2 * math.atan(cam_d.sensor_width / (2 * cam_d.lens))
dist = (R * 0.5 * 1.45) / math.tan(fov / 2)
d = Vector((math.sin(yaw) * math.cos(elev), -math.cos(yaw) * math.cos(elev), math.sin(elev)))
tgt = ctr + Vector((0, 0, -size.z * 0.02))
cam.location = tgt + d * dist
cam.rotation_euler = (tgt - cam.location).to_track_quat("-Z", "Y").to_euler()
cam_d.dof.use_dof = True
cam_d.dof.focus_distance = (tgt - cam.location).length
cam_d.dof.aperture_fstop = 11.0

os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
sc.render.image_settings.file_format = "PNG"
sc.render.filepath = out
bpy.ops.render.render(write_still=True)
print("HERO_DONE", out)
