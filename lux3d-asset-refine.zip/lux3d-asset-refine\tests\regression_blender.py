"""Offline Blender regression checks. Usage: blender -b -P this.py -- output_dir"""
import contextlib
import io
import json
import runpy
import sys
from pathlib import Path

import bpy
import numpy as np

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "scripts"))
from refine_lib import hinge, decimate_bake, export_glb, apply_transform, add_collider
from common import read_glb_chunks

OUT = Path(sys.argv[sys.argv.index("--") + 1]).resolve()
OUT.mkdir(parents=True, exist_ok=True)
RESULTS = []


def cube(name, location=(0, 0, 0), mesh_offset=(0, 0, 0)):
    bpy.ops.mesh.primitive_cube_add(size=1, location=location)
    obj = bpy.context.object
    obj.name = name
    for vertex in obj.data.vertices:
        vertex.co += __import__("mathutils").Vector(mesh_offset)
    obj["lux3d_origin"] = True
    return obj


def check_fixture(name, obstacle_offset, obstacle_location, axis="Z", rest=0, parent=False):
    folder = OUT / name
    folder.mkdir(exist_ok=True)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    leaf = cube("door_leaf", (3, 0, 0))
    pivot = hinge(leaf, (0, 0, 0), axis, rest_deg=rest, max_deg=90, name="door")
    obstacle = cube("obstacle", obstacle_location, obstacle_offset)
    if parent:
        root = bpy.data.objects.new("transformed_root", None)
        bpy.context.collection.objects.link(root)
        root.location = (5, -2, 1)
        root.rotation_euler.z = .4
        pivot.parent = root
        obstacle.parent = root
    glb = folder / "fixture.glb"
    export_glb(str(glb))
    fn = {"id": "door", "type": "hinge", "node": "door", "desc": "test door",
          "min_deg": 0, "max_deg": 90, "rest_deg": rest, "clips": ["door_open", "door_close"]}
    (folder / "asset.json").write_text(json.dumps({"functions": [fn]}), encoding="utf-8")
    # Deliberately do not create the result's parent: first-run behavior is tested here.
    output = folder / "new_audit" / "function-check.json"
    previous = sys.argv
    sys.argv = ["function_check.py", "--", str(glb), str(folder / "asset.json"), str(output)]
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            runpy.run_path(str(SKILL / "scripts" / "function_check.py"), run_name="__main__")
    finally:
        sys.argv = previous
    data = json.loads(output.read_text(encoding="utf-8"))
    rows = {row["kind"]: row for row in data["checks"]}
    assert all(rows[k]["pass"] for k in ("node", "hinge", "animation")), rows
    assert data["schema_version"] == 2 and data["inputs"]["glb_sha256"]
    return rows["collision"]["pass"], rows["collision"]["value"]


cases = [
    ("separated", (.3, .3, .3), (20, 0, 0), "Z", 0, False, True),
    ("intersecting", (10.3, .3, .3), (-7, 0, 0), "Z", 0, False, False),
    ("y_axis_sign", (2.1, 0, -2.1), (0, 0, 0), "Y", 22, False, False),
    ("transformed_parent", (.3, .3, .3), (20, 0, 0), "Z", 22, True, True),
]
for name, offset, location, axis, rest, parent, expected in cases:
    actual, detail = check_fixture(name, offset, location, axis, rest, parent)
    assert actual == expected, (name, actual, detail)
    RESULTS.append({"test": name, "ok": True, "collision_pass": actual, "detail": detail})


def material_fixture(name, textured):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    high = cube(name)
    mat = bpy.data.materials.new(name + "_source")
    mat.use_nodes = True
    shader = mat.node_tree.nodes["Principled BSDF"]
    shader.inputs["Base Color"].default_value = (.6, .2, .1, 1)
    shader.inputs["Metallic"].default_value = 1
    shader.inputs["Roughness"].default_value = .2
    high.data.materials.append(mat)
    if textured:
        image = bpy.data.images.new("source_mr", 16, 16)
        image.colorspace_settings.name = "Non-Color"
        pixels = np.ones((16, 16, 4), dtype=np.float32)
        pixels[:, :8, 1], pixels[:, 8:, 1] = .2, .8
        pixels[:, :8, 2], pixels[:, 8:, 2] = 0, 1
        image.pixels.foreach_set(pixels.ravel())
        texture = mat.node_tree.nodes.new("ShaderNodeTexImage")
        texture.image = image
        separate = mat.node_tree.nodes.new("ShaderNodeSeparateColor")
        mat.node_tree.links.new(texture.outputs["Color"], separate.inputs["Color"])
        mat.node_tree.links.new(separate.outputs["Green"], shader.inputs["Roughness"])
        mat.node_tree.links.new(separate.outputs["Blue"], shader.inputs["Metallic"])
        shader.inputs["Alpha"].default_value = .5
    else:
        shader.inputs["Emission Color"].default_value = (.3, .1, .05, 1)
        shader.inputs["Emission Strength"].default_value = 3
    before = {"links": len(mat.node_tree.links), "metallic": shader.inputs["Metallic"].default_value,
              "roughness": shader.inputs["Roughness"].default_value}
    low = decimate_bake(high, 12, size=64, cage=.05)
    p = low.data.materials[0].node_tree.nodes["Principled BSDF"]
    assert high.data.materials[0] == mat
    assert before == {"links": len(mat.node_tree.links), "metallic": shader.inputs["Metallic"].default_value,
                      "roughness": shader.inputs["Roughness"].default_value}, "Source material changed"
    if textured:
        assert p.inputs["Metallic"].is_linked and p.inputs["Roughness"].is_linked
        packed = next(n.image for n in low.data.materials[0].node_tree.nodes
                      if n.type == "TEX_IMAGE" and n.image and n.image.name.endswith("_metal_rough"))
        values = np.array(packed.pixels[:]).reshape(-1, 4)
        assert values[:, 1].max() > .7 and values[:, 1].min() < .3, "Roughness variation lost"
        assert values[:, 2].max() > .9 and values[:, 2].min() < .1, "Metallic variation lost"
        assert p.inputs["Alpha"].is_linked
    else:
        assert abs(p.inputs["Metallic"].default_value - 1) < 1e-6
        assert abs(p.inputs["Roughness"].default_value - .2) < 1e-6
        assert p.inputs["Emission Color"].is_linked
        assert p.inputs["Emission Strength"].default_value >= 1
        emitted = next(n.image for n in low.data.materials[0].node_tree.nodes
                       if n.type == "TEX_IMAGE" and n.image and n.image.name.endswith("_emission"))
        assert np.array(emitted.pixels[:]).reshape(-1, 4)[:, :3].max() > .5
    bpy.data.objects.remove(high, do_unlink=True)
    target = OUT / (name + ".glb")
    export_glb(str(target), jpeg_quality=90)
    doc, _ = read_glb_chunks(target)
    material = doc["materials"][0]
    assert material.get("normalTexture"), "Normal map lost in export"
    normal_texture = doc["textures"][material["normalTexture"]["index"]]
    assert doc["images"][normal_texture["source"]]["mimeType"] == "image/png", "Normal map became lossy"
    if textured:
        assert "metallicRoughnessTexture" in material["pbrMetallicRoughness"]
        assert material.get("alphaMode") == "BLEND", material
    else:
        assert abs(material["pbrMetallicRoughness"].get("metallicFactor", 1) - 1) < 1e-5
    RESULTS.append({"test": name, "ok": True, "source_unchanged": True, "exported": str(target)})


material_fixture("constant_metal", False)
material_fixture("textured_metal_alpha", True)


def invisible_collider_fixture():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    source = cube("visible_asset")
    collider = add_collider("COL_fixture", [source], mode="box")
    assert len(source.data.materials) == 0, "Source material changed"
    target = OUT / "invisible_collider.glb"
    export_glb(str(target))
    doc, _ = read_glb_chunks(target)
    node = next(n for n in doc["nodes"] if n.get("name") == "COL_fixture")
    assert node.get("extras", {}).get("collider") is True
    primitive = doc["meshes"][node["mesh"]]["primitives"][0]
    assert doc["accessors"][primitive["indices"]]["count"] > 0, "Collision geometry lost"
    material = doc["materials"][primitive["material"]]
    assert material.get("alphaMode") in {"MASK", "BLEND"}, material
    assert material["pbrMetallicRoughness"]["baseColorFactor"][3] == 0, material
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=str(target))
    restored = bpy.data.objects["COL_fixture"]
    alpha = restored.data.materials[0].node_tree.nodes["Principled BSDF"].inputs["Alpha"]
    assert not alpha.is_linked and alpha.default_value == 0, "Visibility changed on roundtrip"
    assert len(restored.data.polygons) > 0 and restored.get("collider") is True
    RESULTS.append({"test": "invisible_collider_export_roundtrip", "ok": True,
                    "geometry_preserved": True, "alpha": 0})


invisible_collider_fixture()
(OUT / "blender-results.json").write_text(json.dumps(RESULTS, ensure_ascii=False, indent=2), encoding="utf-8")
for result in RESULTS:
    print("PASS", json.dumps(result, ensure_ascii=False))
