"""Blender 后台脚本：按“参考图同一套坐标”渲染模型轮廓（alpha），用来和参考图做数值对比。

blender -b --factory-startup -P sil_render.py -- <模型.glb> <输出前缀>

输出 <前缀>_front.png / <前缀>_back.png（RGBA，alpha=轮廓，像素与参考图 1:1 对齐）。
约定（B8 系列四视图参考，1254x1254，S=120 像素/米）：
  正面：x=(u-350)/120, z=(630-v)/120，窗口 u 0..720, v 0..640
  背面：x=(350-u)/120, z=(1230-v)/120，窗口 u 0..700, v 640..1254
别的素材换窗口/比例时改 VIEWS。用 Cycles 渲染，不依赖 GPU/EGL。
"""
import math, sys
import bpy
from mathutils import Vector

glb, prefix = sys.argv[sys.argv.index("--") + 1:][:2]
S = 120.0
# name: (u0,u1,v0,v1, 相机在哪一侧, x(u) 的符号, z 的原点常数)
VIEWS = {
    "front": dict(u=(0, 720), v=(0, 640), cx=lambda uc: (uc - 350) / S, cz=lambda vc: (630 - vc) / S, side=-1),
    "back":  dict(u=(0, 700), v=(640, 1254), cx=lambda uc: (350 - uc) / S, cz=lambda vc: (1230 - vc) / S, side=1),
}

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=glb)
for o in list(bpy.context.scene.objects):
    if o.name.startswith("COL_"):
        bpy.data.objects.remove(o, do_unlink=True)
sc = bpy.context.scene
sc.render.engine = "CYCLES"
sc.cycles.samples = 1
sc.cycles.use_denoising = False
sc.render.film_transparent = True
sc.render.filter_size = 0.0
sc.render.image_settings.file_format = "PNG"
sc.render.image_settings.color_mode = "RGBA"
sc.render.resolution_percentage = 100
cam_d = bpy.data.cameras.new("c"); cam_d.type = "ORTHO"
cam = bpy.data.objects.new("c", cam_d); sc.collection.objects.link(cam); sc.camera = cam

for name, V in VIEWS.items():
    (u0, u1), (v0, v1) = V["u"], V["v"]
    w, h = u1 - u0, v1 - v0
    cam_d.ortho_scale = w / S
    sc.render.resolution_x, sc.render.resolution_y = w, h
    cx, cz = V["cx"]((u0 + u1) / 2), V["cz"]((v0 + v1) / 2)
    cam.location = Vector((cx, V["side"] * 30, cz))
    cam.rotation_euler = (math.radians(90), 0, 0 if V["side"] < 0 else math.radians(180))
    sc.render.filepath = f"{prefix}_{name}.png"
    bpy.ops.render.render(write_still=True)
print("SIL_DONE")
