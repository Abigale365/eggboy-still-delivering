"""Run with system Python: python -B -m unittest discover -s <skill>/tests -v."""
import json
import struct
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from PIL import Image, ImageDraw

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "scripts"))
from common import function_inputs, render_inputs, sha256_file
from audit import append_function_checks, visual_verdicts
from prep_check import analyse


def write_glb(path, origin=True):
    binary = struct.pack("<9f3H", 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 2) + b"\0\0"
    doc = {"asset": {"version": "2.0"}, "scene": 0, "scenes": [{"nodes": [0]}],
           "nodes": [{"name": "fixture", "mesh": 0, "extras": {"lux3d_origin": origin}}],
           "meshes": [{"name": "fixture", "primitives": [{"attributes": {"POSITION": 0}, "indices": 1}]}],
           "accessors": [{"bufferView": 0, "componentType": 5126, "count": 3, "type": "VEC3", "min": [0, 0, 0], "max": [1, 1, 0]},
                         {"bufferView": 1, "componentType": 5123, "count": 3, "type": "SCALAR"}],
           "bufferViews": [{"buffer": 0, "byteOffset": 0, "byteLength": 36}, {"buffer": 0, "byteOffset": 36, "byteLength": 6}],
           "buffers": [{"byteLength": len(binary)}]}
    chunk = json.dumps(doc).encode()
    chunk += b" " * (-len(chunk) % 4)
    path.write_bytes(struct.pack("<4sII", b"glTF", 2, 28 + len(chunk) + len(binary))
                     + struct.pack("<I4s", len(chunk), b"JSON") + chunk
                     + struct.pack("<I4s", len(binary), b"BIN\0") + binary)


class SystemChecks(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.glb = self.root / "fixture.glb"
        write_glb(self.glb)
        self.asset = {"id": "fixture", "generated": str(self.glb), "reference": {}, "functions": [], "parts": []}
        self.save_asset()

    def tearDown(self):
        self.temp.cleanup()

    def save_asset(self):
        (self.root / "asset.json").write_text(json.dumps(self.asset), encoding="utf-8")

    def function_data(self, rows):
        return {"schema_version": 2, "inputs": function_inputs(self.glb, self.root / "asset.json"), "checks": rows}

    def test_empty_function_evidence_rejected(self):
        self.asset["functions"] = [{"id": "smoke", "type": "socket", "node": "missing"}]
        self.save_asset()
        (self.root / "function-check.json").write_text(json.dumps(self.function_data([])), encoding="utf-8")
        rows = []
        append_function_checks(rows, self.asset, self.glb, self.root, self.root)
        self.assertTrue(any(row["pass"] is False for row in rows))

    def test_stale_function_evidence_rejected(self):
        self.asset["functions"] = [{"id": "smoke", "type": "socket"}]
        self.save_asset()
        data = self.function_data([{"function_id": "smoke", "kind": k, "pass": True, "item": k, "value": "fixture"}
                                   for k in ("node", "socket")])
        data["inputs"]["glb_sha256"] = "old-model"
        (self.root / "function-check.json").write_text(json.dumps(data), encoding="utf-8")
        rows = []
        append_function_checks(rows, self.asset, self.glb, self.root, self.root)
        self.assertFalse(rows[0]["pass"])

    def test_complete_function_evidence_accepted(self):
        self.asset["functions"] = [{"id": "smoke", "type": "socket"}]
        self.save_asset()
        checks = [{"function_id": "smoke", "kind": k, "pass": True, "item": k, "value": "fixture"} for k in ("node", "socket")]
        (self.root / "function-check.json").write_text(json.dumps(self.function_data(checks)), encoding="utf-8")
        rows = []
        append_function_checks(rows, self.asset, self.glb, self.root, self.root)
        self.assertEqual(len(rows), 2)
        self.assertTrue(all(row["pass"] for row in rows))

    def test_visual_decisions_invalidated_by_new_input(self):
        inputs = {"glb_sha256": sha256_file(self.glb)}
        first = visual_verdicts(self.root, self.asset, inputs)
        first["damage"]["pass"] = True
        (self.root / "verdicts.json").write_text(json.dumps(first), encoding="utf-8")
        self.assertTrue(visual_verdicts(self.root, self.asset, inputs)["damage"]["pass"])
        changed = visual_verdicts(self.root, self.asset, {"glb_sha256": "new"})
        self.assertIsNone(changed["damage"]["pass"])
        self.assertEqual(len(list(self.root.glob("verdicts.previous-*.json"))), 1)

    def test_empty_image_is_explained(self):
        image = self.root / "empty.png"
        Image.new("RGBA", (512, 512), (0, 0, 0, 0)).save(image)
        result = analyse(str(image))
        self.assertIsNone(result["bbox"])
        self.assertTrue(result["warnings"])

    def test_missing_views_cannot_generate(self):
        result = subprocess.run([sys.executable, "-B", str(SKILL / "scripts" / "prep_check.py"), str(self.root)], capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertFalse(json.loads((self.root / "prep-check.json").read_text(encoding="utf-8"))["ok"])

    def test_no_render_rejects_old_cache(self):
        (self.root / "audit-v1" / "renders").mkdir(parents=True)
        result = subprocess.run([sys.executable, "-B", str(SKILL / "scripts" / "audit.py"), str(self.root), str(self.glb), "v1", "--no-render"], capture_output=True)
        self.assertNotEqual(result.returncode, 0)

    def test_missing_baseline_and_failed_priority(self):
        write_glb(self.glb, False)
        folder = self.root / "audit-v1" / "renders"
        folder.mkdir(parents=True)
        rgba = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
        ImageDraw.Draw(rgba).rectangle((24, 16, 104, 112), fill=(180, 100, 60, 255))
        solid = Image.new("RGB", rgba.size, (0, 0, 0))
        ImageDraw.Draw(solid).rectangle((24, 16, 104, 112), fill=(200, 200, 200))
        for view in ("front", "left", "back", "right"):
            rgba.save(folder / f"flat_{view}.png")
            rgba.convert("RGB").save(folder / f"lit_{view}.png")
            solid.save(folder / f"solid_{view}.png")
        rgba.save(self.root / "ref.png")
        self.asset["reference"] = {v: "ref.png" for v in ("front", "left", "back", "right")}
        self.save_asset()
        (folder / "render.json").write_text(json.dumps({"inputs": render_inputs(self.glb, 8, 1400, 0)}), encoding="utf-8")
        result = subprocess.run([sys.executable, "-B", str(SKILL / "scripts" / "audit.py"), str(self.root), str(self.glb), "v1", "--no-render"], capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        report = json.loads((folder.parent / "audit.json").read_text(encoding="utf-8"))
        self.assertEqual(report["verdict"], "不达标")
        self.assertTrue(report["pending"])
        self.assertTrue(any("原版基线" in x for x in report["failed"]))
        self.assertTrue(any("原件占比" in x for x in report["failed"]))


if __name__ == "__main__":
    unittest.main()
