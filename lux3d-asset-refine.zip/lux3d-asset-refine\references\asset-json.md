# asset.json 格式

每件素材的工作目录里放一个，路径可以写相对工作目录的。

```json
{
  "id": "brick-oven",
  "name": "户外砖砌烤炉",
  "category": "large",                 // large：5 万面预算；small：1 万；也可以直接写 "tri_budget": 30000
  "height_m": 2.0,                     // 真实高度（米），normalize 用；几何来源核对也靠它，缺了量不了
  "reference": {                       // 参考图四视图（透明背景 PNG）。相机方向：正面在 -Y
    "front": "../inputs/01_front.png", // 从正面看
    "left": "../inputs/02_side_a.png", // 从物体左边看（相机在 -X），画面右边是正面
    "back": "../inputs/03_back.png",
    "right": "../inputs/04_side_b.png" // 相机在 +X，画面左边是正面
  },
  "generated": "../delivery/assets/brick-oven-v1/glb.glb",   // Lux3D 原版 GLB
  "yaw_fix_deg": 0,                    // 原版正面不朝 -Y 时，绕 Z 转多少度能摆正
  "edit_policy": "小手术：只改原件，不新建部件",
  "parts": [                           // 关键部件清单（看图判断用），按参考图写
    {"id": "crescent", "desc": "门上方古铜月牙 + 左右两颗小圆钉"}
  ],
  "functions": [                       // 功能清单，function_check.py 按这个查
    {"id": "door", "type": "hinge", "node": "door", "min_deg": 0, "max_deg": 100, "rest_deg": 22,
     "clips": ["door_open", "door_close"], "collision_step_deg": 2, "axis_ignore_m": 0.04,
     "desc": "炉门绕左侧合页开关"},
    {"id": "smoke", "type": "socket", "node": "socket_smoke", "desc": "烟囱顶冒烟的位置"},
    {"id": "glow", "type": "emissive", "node": "fire_embers", "desc": "会发光的部件（原版有才用）"},
    {"id": "collider", "type": "collider", "node": "COL_body", "desc": "碰撞体"}
  ],
  "details": [                         // 局部放大框：在“缩到同高、对齐后的图”上的比例坐标 [x0, y0, x1, y1]
    {"name": "door", "title": "炉门", "view": "front", "box": [0.22, 0.22, 0.88, 0.76]}
  ],
  "color_regions": {                   // 调色取样区，calibrate_colors.py 用（不调色可不写）
    "leather": {"view": "front", "boxes": [[0.20, 0.80, 0.30, 0.42]], "radius": 30}
  }
}
```

`color_regions` 每项：`view` 用哪个方向的图取样；`boxes` 是在对齐后的图上的比例框，**顺序是 `[x0, x1, y0, y1]`**（和 `details` 的 `[x0, y0, x1, y1]` 不一样，别混）；`radius` 原样写进 `colors.json`，交给 `recolor_masked` 用（默认 30，不写就用默认）。写一个区域就量一个：预览图中位色、原版打光渲染中位色、想要的贴图色、受步长限制的目标色，结果写进 `colors.json`。
`tri_budget` 直接写数字会覆盖 `category`；放宽要先问用户，并在 `budget_note` 里写同意的人、日期和原因。

功能类型：`hinge`（转轴）、`socket`（位置点，空节点）、`emissive`（发光材质）、`collider`（碰撞体）。
