"""audit.judge：对预览图的出入只记录，不拉低总结论；真正的失败照样判不达标。"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import audit  # noqa: E402


def c(group, item, ok, **kw):
    return {"group": group, "item": item, "value": "", "pass": ok, **kw}


class Judge(unittest.TestCase):
    def test_record_only_differences_do_not_fail_the_result(self):
        r = audit.judge([c("外形", "左侧轮廓", False, record_only=True),
                         c("关键部件", "锚徽", False, record_only=True),
                         c("体量", "三角面", True)])
        self.assertEqual(r["verdict"], "达标")
        self.assertEqual(len(r["recorded"]), 2)
        self.assertEqual(r["failed"], [])

    def test_real_failures_still_fail(self):
        r = audit.judge([c("外形", "背面轮廓", False, record_only=True), c("体量", "三角面", False)])
        self.assertEqual(r["verdict"], "不达标")
        self.assertEqual(r["failed"], ["体量·三角面"])

    def test_gross_shape_deviation_is_not_record_only(self):
        # 对预览图偏差超过 10% 高度：严重跑偏，要判失败（audit 里 record_only 只给 5%–10% 之间的）
        gross = audit.SHAPE_GROSS_MAX
        self.assertGreater(gross, audit.SHAPE_P95_MAX)
        p95 = 0.12
        record_only = (not (p95 <= audit.SHAPE_P95_MAX)) and p95 <= gross
        r = audit.judge([c("外形", "背面轮廓", False, record_only=record_only)])
        self.assertEqual(r["verdict"], "不达标")

    def test_pending_visual_checks_wait(self):
        r = audit.judge([c("体量", "三角面", True), c("破损", "破损", None)])
        self.assertEqual(r["verdict"], "待看图判断")

    def test_damage_is_never_record_only(self):
        r = audit.judge([c("破损", "破损", False)])
        self.assertEqual(r["verdict"], "不达标")


if __name__ == "__main__":
    unittest.main()
