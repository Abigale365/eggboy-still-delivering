---
name: lux3d-asset-refine
description: 面向全品类 3D 资产与渲染出图（角色手办、日常道具、服饰软体、机械器物、家具、载具、自然植物、建筑场景）的 Aholo Lux3D 精修、质感增强与影棚级出图 Skill。在保留原版高光釉面/PBR 材质基础上，提供全品类通用的贴图黑斑扩散修补、SDF 薄壁微孔洞无损封口、刚性基准分离的局部 C2 软塑形、单图深度偏移拉回、曲面法线投射补盲、可动部件（门轴/转轴/挂点/碰撞体）装配，以及 Cycles 影棚级展示图与 3D 交互预览工作台直出。Use for refining any category of Lux3D/Aholo 3D assets (characters, props, apparel, appliances, vehicles, foliage, buildings) and generating high-craft studio renders and 3D web viewers.
---

# Lux3D 全品类 3D 资产精修与出图增强（通用小手术管线）

把 Lux3D / Aholo 生成的**任意品类模型与渲染图**（角色手办、日常道具、服饰软体、机械家具、载具、植物、建筑场景）修得更精细、质感更好、结构更准、部件能动，并直出影棚级渲染图与 3D 交互工作台。

## 支持的全品类矩阵与路由

| 资产/出图品类 | 典型对象举例 | 核心增强动作 | 范例脚本 / 参考规范 |
|---|---|---|---|
| **1. 服饰 / 软体 / 生活小物** | 船长帽、被咬过的拖鞋、背包、玩偶、小球 | 保高光釉面、褶皱/咬痕黑斑扩散修补、帽檐/软边局部 $C^2$ 弧度微调、分区重烘焙 | `examples/cap_refine.py`、`references/workflow-captain-cap.md` |
| **2. 机械 / 家具 / 街道器物** | 面包店老烤炉、路灯、秋千、滑梯、老相机、闹钟、长椅 | 刚性立柱/底座垂直锁定、切分可开关门/转轴（`hinge`）、背面散热格栅/铭牌法线投射补件 | `examples/oven_v2.py`、`references/functions.md` |
| **3. 角色 / 生物 / 潮玩手办** | 游戏角色、邮递员、海鸥、宠物雕像 | 保手办高光陶釉（`Roughness ≈ 0.05–0.11`）、五官/关节凹陷黑洞修补、头部/肢体局部姿态微调（锁死脚底支撑平面） | [全品类通用建模与出图规范](references/blender-universal-craft.md) |
| **4. 建筑 / 场景单体** | 阳台小楼 B8、灯塔、邮局、学校、面包房 | 墙体/横梁/烟囱刚性正交锁定 + 屋顶局部 $C^2$ 塑形、SDF 薄壁贯通微孔洞封口、侧/背立面 Raycast 立体补窗 | `examples/b8_balcony_house_refine.py`、`references/building-review.md` |
| **5. 2D 输入原图与影棚级渲染图** | 概念单视角白底图、四视图、封面宣传图、六视角对比图 | 生成前原图透明通道/白底去杂点检查（`prep_check.py`）、ΔE 步长受控调色（`calibrate_colors.py`）、Cycles 三点布光 + 暖奶油影棚 + Filmic 展示主图直出（`hero_render.py`） | `scripts/prep_check.py`、`scripts/hero_render.py` |

## 先选工作路线

- **Lux3D / Aholo 全品类原版精修**：执行下方完整流程（适用于角色、道具、器物、建筑等一切 GLB 资产）。若对象恰好为建筑类，在体检前额外叠加 [建筑逐面检查与返修](references/building-review.md)。
- **已有本地 3D 资产检查或返修**：保存当前 GLB／Blend 为对照基线，按授权范围修订并出对比报告与影棚级展示图。

## Lux3D 原版精修规则

1. **在原版上改，不从零做。** 允许的操作只有 `references/surgery.md` 里的“小手术清单”。替换或重建部件须有对应的明确授权；已有授权可直接使用。验收会按几何核对：精修后的表面有 ≥ 90% 要贴着原版表面，原版表面也要保留 ≥ 90%；节点上的 `lux3d_origin` 标记只用来和几何互相核对，标记写 `True` 不算数。
2. **没有用户这一次的明确同意，不许下付费单。** 生成、四视图、改图、部件拆分、材质重绘会花积分。一次同意只管一张生成单（这几张图、这个版本、这个次数），不延伸到别的任务；拿不准算不算已同意，就当没同意。`scripts/lux3d.mjs` 不加 `--confirm`（或写 `--confirm=false`）不会下单，这个参数只能在用户同意后加，agent 不能自己替用户加。查已有任务、下载已有结果不花积分，可以直接做。
3. **调色只挪一小步，保住原来的暖冷。** 参考图带了光照，不能把贴图颜色直接调成参考图的颜色。每个主色每步最多挪 ΔE 10、色相 ≤ 10°；数据说不需要挪（比如船长帽的帽身）就别挪。验收里“颜色”只和原版比，没有有效的原版基线就不给颜色结论。
4. **以最终渲染出来的模型为准，对预览图的出入只记录。** 外形偏差 5%–10%、关键部件没做到，写进日志，不拉低结论、不为此重建部件；偏差超过 10% 才算失败。
5. **不凭眼睛分诊，不盲调。** 分诊的每一条都要有量出来的数（`references/surgery.md` 开头的核对表）；每次试之前先写预期；同一个毛病同一个思路连试 3 次没改善就停下来，换思路或问用户。
6. **别为了让某一行变绿去改验收规则。** 验收量法有真缺陷（配对错、规则矛盾）才修，并配单元测试；拿不准的，原样报告，写进“需要你决定的”。

开始一件新素材前，**先读 `references/lessons.md`**（症状表 + 反面例子）；想看一次走通的完整流程和数字，读 `references/workflow-captain-cap.md`。

## 需要的环境

- Blender：已在 5.2.3 LTS 验证；其他 4.2+ 版本先跑下方离线回归。找不到时设环境变量 `BLENDER_EXE`。Blender 自带 Python 有 numpy、没有 scipy。
- Python 3.10+，装好 `numpy pillow scipy`（验收、量图用）。
- Node 18+（只有调 Lux3D 时用，key 放环境变量或 `.env` 的 `AHOLO_API_KEY`）。
- Windows PowerShell 5 的坑：单引号里 `\n` 不会换行、传 JSON 参数会丢引号、`Set-Content` 默认 ANSI。多行内容、JSON 一律写成文件再传路径；读 JSON 用 `utf-8-sig`。

下文 `<skill>` 指本 skill 所在目录，`<dir>` 指这件素材的工作目录。

## 流程

### 0. 建工作目录，准备输入（不花积分）
每件素材一个目录，里面写 `asset.json`（格式见 `references/asset-json.md`）：名字、真实高度、参考图四视图、原版 GLB 路径、关键部件清单、功能清单、局部放大框、调色取样区 `color_regions`。
参考图先确认有没有透明通道（读 alpha，别以为是白底），四张用同一个画布边长、不缩放。
```
python <skill>/scripts/prep_check.py <dir> [--clean]
```
检查参考图（透明背景、四张是否一致、有没有杂点、光影是不是烤进图里）。

### 1. 生成（可选；花积分，要用户这一次的明确同意）
1. 写“生成单”给用户看：用哪几张图、G1 还是 G1-Turbo、面数、预计几次调用、预计积分（查不到报价就写明是估计）。
2. `node <skill>/scripts/lux3d.mjs check --env=<.env>` 验 key（不花积分）。
3. 用户同意后：`node <skill>/scripts/lux3d.mjs img3d <dir> <名字> <图...> --turbo --faces=300000 --env=<.env> --confirm`

已有任务等待默认上限 20 分钟，可用 `--timeout-seconds=<秒>` 调整；超时保留 taskId，用 `wait` 继续查询，避免重复创建付费任务。下载 HTTP 失败或 GLB 内容无效时不覆盖输出。

### 2. 体检原版
```
python <skill>/scripts/audit.py <dir> <原版.glb> v0 --baseline
```
会用 Blender 从正面 / 左 / 背 / 右四个方向渲染，和参考图比外形、颜色、体量，生成 `<dir>/audit-v0/report.html` 和 `view_*.jpg`、`detail_*.jpg`。**看图**，把 `audit-v0/verdicts.json` 里每个关键部件和“破损”填上 `pass` / `note`，保留文件里的 `inputs`，再加 `--no-render` 跑一次合进结论。原版诊断只接受 `asset.json.generated` 对应的 GLB。

再用一个 Blender 脚本量原版本身：孤立块数和大小、开口环大小、非流形边数、平均边长、真实尺寸下的包围盒。数据口径见 `references/surgery.md` 开头。

### 3. 分诊（给用户看了再动手）
把每条“不过”分成三类，写进 `<dir>/精修记录.md`（模板见 `references/surgery.md` 末尾）：
- **小手术能修**：照清单修。
- **先别动**：数据说不用动的（细缝不是洞、颜色已对上）。
- **小手术修不了**（形状、结构不对）：只记下来，并写“下次生成时输入怎么改”。要不要重新生成，由用户决定。

记录分诊结果和功能方案（尤其是门从哪里切、开多大）。在既有授权内继续；新增、重建、替换或拉伸部件超出授权时，先给出具体方案。

### 4. 量颜色（要调色时）
```
python <skill>/scripts/calibrate_colors.py <dir>      # 读 asset.json 的 color_regions，写 colors.json
```
每个区域给出：预览图 / 原版打光渲染的中位色、想要的贴图色、按步长上限截断后的目标色、`need`（ΔE < 3 标 False，不用挪）。精修脚本只吃 `colors.json`。

### 5. 写这件素材的精修脚本
在 `<dir>` 里写 `<id>_refine.py`，开头 `sys.path.insert(0, r"<skill>/scripts")` 再 `from refine_lib import *`。分阶段，各存一个 `.blend`，改哪段只重跑哪段：
- `surgery`：定尺寸和原点、合并重复点、切出会动的部件、去碎片、补**真**洞、抹小坑、涂脏色块、按区域小幅调色。
- `export`：减面 + PBR 烘焙（`decimate_bake`，保留底色、法线、金属度、粗糙度；非流形边会先劈开）、装功能（`hinge` / `add_socket` / `add_collider`）、给每个网格标 `lux3d_origin`、导出（`export_glb`）。
- `rebake`（只在烘出局部斑时才做）：分开烘，低模不动、只重烘出毛病那块的颜色（`split_bake.rebake_region`）。

参考实现：`examples/cap_refine.py`（船长帽：小件，surgery / export / export_keepuv / rebake 四段，选区常量只适用于这件）、`examples/oven_v2.py`（砖砌烤炉：有门轴）。运行方式见 `references/example.md`。过程中用 `scripts/preview_blend.py`、`scripts/closeup_blend.py` 出图看。

**改完脚本先 `python -c "import ast,sys;ast.parse(open(sys.argv[1],encoding='utf-8').read())" <脚本>`，再启动要跑几分钟的任务，启动前说清楚在跑什么、预计多久。**

```
blender -b --factory-startup -P <dir>/<id>_refine.py -- surgery <dir>
blender -b --factory-startup -P <dir>/<id>_refine.py -- export <dir> tag=v2
```

烘焙出了黑斑、灰斑、方块：别连着调笼子和面数。按 `references/lessons.md` 的症状表选做法（分开烘 / 保留 UV 减面回退，后者会棱角分明，只作对比），不能为保住面数预算而交付损坏外观，也不自动放宽预算——放宽要问用户。

### 6. 功能检查 + 验收
```
blender -b --factory-startup -P <skill>/scripts/function_check.py -- <新.glb> <dir>/asset.json <dir>/audit-v1/function-check.json
python <skill>/scripts/audit.py <dir> <新.glb> v1 --before=v0 --orig=v0
```
标准见 `references/acceptance.md`。再**看图**（四面图 + 特写，局部毛病色板和轮廓量不出来），填 `verdicts.json`，`--no-render` 重跑。小手术能修的项没过就回第 5 步；修不了的项确认已写进精修记录；颜色行没过又不属于模型问题的，原样报告，别去调验收。

验收会核对原版基线、功能检查和渲染缓存是否对应当前输入。改了 GLB、asset.json 或相关检查脚本后重跑对应步骤；`--no-render` 只复用有效缓存。看图结论也绑定当前模型与渲染，过期记录会备份并恢复为待判断。总状态优先显示已有失败项，不能把待看图或未执行项填成通过。

### 7. 交付和记录
- **要给人“看 3D”时，默认交付带贴图的离线 3D 查看器（`viewer/textured_viewer_main.js`，只有旋转缩放，不加拆解面板），不要只交静态图或白膜；用户明确要拆解时才用下面的可分解版**：见 `viewer/README.md`。节点名要有意义（roof / balcony / door / foundation…），查看器按名字自动分组拆开；自动演示 + 手动接管。静态主图用 `hero_render.py` 只作封面。
- 展示主图：`blender -b --factory-startup -P <skill>/scripts/hero_render.py -- <最终.glb> <dir>/hero.png`。**不要拿 render_views 的 lit 图当展示图**（单太阳光 + 纯白环境，没有阴影层次，会显得扁平）。经验：AgX 会把橙红压成粉色，用 Filmic 并把曝光压到 -0.8 左右；地面与背景别用中性灰，用暖奶油色。
- `<id>-vN.glb`：精修后的模型（功能说明在节点和场景的 extras 里，格式见 `references/functions.md`）。
- `精修记录.md`：做了什么、分诊里说错的、版本表（每个版本的毛病）、没做什么（为什么、下次生成怎么改）、需要用户决定的事。
- `audit-vN/report.html`：原版 / 精修版 / 参考图的逐项对比（比赛报告的“资产迭代对比”可以直接用）。
- 给用户看：Blender 里导入 GLB，隐藏 `COL_*`，切到材质预览。

## 全品类通用 6 大核心增强算子（2026-11-14 实证升级）

针对 Aholo / Lux3D（以及 Hunyuan3D、TRELLIS 等单图/多图转 3D 模型）在**角色手办、日常道具、机械器物、家具、建筑**全品类中共通的五大缺陷（① 凹陷/褶皱/接缝处有 `luma < 0.195` 未烘焙黑斑；② Marching Cubes 在薄壁处打出穿透内腔的暗孔；③ 单图深度估计把前景局部浮雕/耳朵/提手/卷云往深处推歪造成双层鼓包；④ 想要调整局部造型曲线却导致底座/立柱/刚性轴歪斜；⑤ 背面/侧面缺失立体结构细节），沉淀出 **零积分消耗、全品类通用** 的 6 大算子（参考实现：`examples/cap_refine.py` 船长帽、`examples/oven_v2.py` 烤炉、`examples/b8_balcony_house_refine.py` B8 小楼）：

1. **原厂高光釉面保护 + 8 邻域明度扩散补黑斑（适用于：角色五官/服饰褶皱/器物凹槽/建筑接缝）**：
   - 严禁抛弃原版网格从零重建或用高粗糙度（如 `Roughness = 0.78`）覆盖原版 `Designer_Logic_PBR`（原版 `Image_1` 的 `Roughness ≈ 0.05–0.11` 是奶油潮玩/陶瓷手办高光质感的核心）。
   - 对 `Image_0` 中 `luma < 0.195` 的未烘焙黑洞/黑缝，禁止填固定纯色，改用 **48 步 8 邻域有效像素（`luma >= 0.215`）拉普拉斯边界扩散插值**，使角色衣褶、帽子边缘、烤炉砖缝或墙面黑点自动无痕融合为邻近真实底色。
2. **SDF 薄壁贯通微孔洞无损封口片（`build_pinhole_sealer`，适用于：杯具/帽壳/箱体/薄壁建筑）**：
   - 当 Marching Cubes 在薄壁（`~2cm`）上打出水密贯通微隧道（`is_boundary == False`）导致视线直穿暗腔成黑点时，**不删原始网格任何三角面**（100% 保护表面起伏细节），用 `260×260` 正交射线阵列捕获穿透进内腔的射线，经 48 步深度扩散与每连通域 78 分位高明度边界 UV 单点采样，生成无损共面封口片。
3. **刚性基准分离的局部 $C^2$ 软塑形场（适用于：帽檐弧度/秋千滑梯/角色姿态/童话屋顶）**：
   - **刚性承重锁死**：先锁定必须绝对水平或垂直的工学基准（如角色的脚底平面、路灯/秋千的立柱、烤炉的门轴、建筑的一二楼墙体与水平檐梁）。
   - **缓冲带自然归零（禁用硬切掩码）**：在可塑形区（如帽檐、软体靠背、屋面）与刚性垂直件（如徽章、立柱、烟囱）之间留出 `smoothstep` 平滑归零缓冲带，杜绝硬切掩码造成的鲨鱼鳍断层。
4. **单图深度偏移共面拉回与双峰鼓包压平（适用于：前景徽章/角色耳朵配饰/器物提手/建筑卷云）**：
   - 单图转 3D 常将前景内旋/凸起边缘沿视线推深 `20–30cm` 形成斜视双层鼓包。用满足 `|∂(dy)/∂y| < 0.5` 的无自交深度拉回将其归位至前景共面，并配合局部高程包络压平后方多余隆起。
5. **曲面法线投射立体补盲（`ray_cast` + `create_pillow_patch`，适用于：器物背板/背包侧袋/家具五金/建筑侧背窗）**：
   - 对单图未拍到的侧面/背面，沿主网格外法线 `base_obj.ray_cast` 采样真实曲面位置，生成带圆润手办倒角（`power=2.6`）与背面收口裙边（skirt）的立体配件（如散热格栅、铆钉铭牌、搭扣、拱窗），并共享匹配原版色板与高光釉面的过程纹理图集。
6. **粘连小件三维包围盒坍缩与高精度替换（适用于：帽徽/天线/旋钮/灯具挂件/屋顶月牙）**：
   - 当顶部或突出部位的精细金属小件粘连模糊时，先在精确 `X-Y-Z` 三维包围盒内将旧残影平滑坍缩至底座中心（防止误伤邻近高耸部件产生悬浮飞线），再原位嫁接高精度的 3D 程序化部件。

> **附：建筑类专项补充（2026-11-07 屋檐剖面扫掠经验）**
> 若处理对象为建筑且需要参数化屋顶，可用 `scripts/roof_sweep.py`（单一剖面沿进深扫掠，自带对称自检）。注意：`sil_compare.py` 的轮廓 IoU 只能当“外形没跑偏”的门槛，不能当平滑度与收口质量的目标；优先保留原版整体并做上述局部小手术。

## 3D 效果的工作流：不要只靠一个 agent 写脚本

Claude / Codex / Antigravity 等 agent 直接写 Blender/three.js 脚本做复杂 3D，质量都会卡在“看不见自己做的东西”。更稳的做法是分工：

1. **生成**交给专门的图转 3D 模型（Hunyuan3D、TRELLIS、Lux3D 等）出初模，agent 不从零手搓复杂有机形体。
2. **修整**交给 agent + DCC：用 Blender MCP / 本 skill 的小手术脚本，在初模上改（见上文），并用 `roof_sweep.py` 这类参数化工具处理建筑的规则曲面。
3. **看图**：agent 必须“看”渲染结果。无头渲染多角度（`render_views.py`），再 `hero_render.py` 出展示图；有桌面环境时用 computer use 开 Blender 视口或浏览器预览真实转一圈。
4. **展示**：交付可分解的离线 HTML（`viewer/`），不要只交静态图。
5. 已收集的外部 skill 与管线在 `G:\1 business\9 skill们\01_3D与空间\`（teardown、blender-mcp、图转3D管线等），遇到新题型先去那里找现成做法。

## 文件
| 文件 | 用途 |
|---|---|
| `scripts/sil_render.py` / `sil_compare.py` | 把模型轮廓渲到参考图同一套像素坐标，量 IoU、顶轮廓误差并出叠加图（绿=参考 红=模型）。只能当“没跑偏”的门槛 |
| `scripts/profile_from_ref.py` | 从参考图 alpha 量屋顶外轮廓（注意噪声，需平滑） |
| `scripts/roof_sweep.py` | 屋顶剖面扫掠：前后檐共用一条剖面，自带对称自检；`tests/test_roof_sweep.py` 为其测试 |
|---|---|
| `references/blender-universal-craft.md` | 全品类（角色/道具/机械/载具/植物/建筑）建模、材质与影棚出图通用规范（融合开源 Blender Skills 精华） |
| `references/lessons.md` | 症状表、反面例子（烤炉 v1、船长帽的歪路、B8 踩坑）、Lux3D 的脾气、Blender 的坑 |
| `references/workflow-captain-cap.md` | 一次走通的完整流程，带命令和实测数字 |
| `references/surgery.md` | 小手术清单、分诊核对表、停止规则、要先问用户的事、精修记录模板 |
| `references/acceptance.md` | 验收标准、“只记录”语义、已知局限 |
| `references/asset-json.md` / `functions.md` / `example.md` | 配置格式、功能说明格式、示例运行方式 |
| `references/negative-example/` | 反面例子图（烤炉 v1；`cap/` 是船长帽 v1–v8 的毛病和好结果） |
| `scripts/audit.py` | 验收 + 对比报告（外形、改动量、颜色、体量、功能、看图项） |
| `scripts/glb_geom.py` | 几何来源核对：原件占比、原版保留率（numpy + scipy，不读压缩 GLB） |
| `scripts/calibrate_colors.py` | 按 `color_regions` 量颜色，算受步长限制的调色目标 |
| `scripts/render_views.py` | Blender：四方向正交渲染（打光 / 贴图原色 / 灰模） |
| `scripts/function_check.py` | Blender：按 asset.json 检查功能（转轴、动画、转动不穿模、位置点、碰撞体） |
| `scripts/refine_lib.py` | Blender 小手术工具箱（碎片、区域调色、保 UV 减面等，见 `references/surgery.md`） |
| `scripts/pbr_bake.py` | 保留 PBR 通道的减面烘焙，不改写源材质，先劈开非流形边 |
| `scripts/split_bake.py` | 分开烘：只重烘出毛病的区域的颜色 |
| `scripts/hero_render.py` | 展示级主图：Cycles + 三点布光 + 天光渐变背景 + 地面接触阴影 + 轻景深 + Filmic 调色。只用来出给人看的封面图 / 报告图，不参与验收（验收仍用 render_views 的正交平光图）。用法：`blender -b --factory-startup -P hero_render.py -- <glb> <out.png> [yaw=35] [elev=16] [分辨率=1400] [采样=96] [studio\|dusk]` |
| `scripts/preview_blend.py` / `closeup_blend.py` | 精修过程中快速出图 |
| `scripts/glb_stats.py` | 不开 Blender 读 GLB：面数、贴图、动画、节点标记 |
| `scripts/prep_check.py` | 生成前检查参考图 |
| `scripts/lux3d.mjs` | 调 Lux3D（花积分的命令要 `--confirm`） |
| `scripts/common.py` / `bl_common.py` | 公用：找 Blender、读 asset.json、恢复 GLB 节点静止姿态 |
| `examples/` | `cap_refine.py` + `cap_asset.json` + `cap_colors.json`（船长帽）、`oven_v2.py` + `oven_asset.json` + `run_oven.py`（烤炉） |
| `tests/` | 离线回归（见下） |

## 离线回归

修改工具脚本后，运行与改动相关的回归；不调用 Lux3D：

```
python -B -m unittest discover -s <skill>/tests -v
blender -b --factory-startup --python-exit-code 1 -P <skill>/tests/regression_blender.py -- <临时测试目录>
node <skill>/tests/test_paid_gate.mjs
```

前两组覆盖验收完整性、“只记录”判定、颜色逐像素追踪、几何来源核对、调色校准、缓存失效、缺图、转轴、相交与分离模型、材质保留和 GLB 导出；最后一组检查付费入口未确认时会被拦截。实际素材仍要完成一次逐项看图验收与精修记录。
