﻿"""Blender 后台脚本：把 GLB 按四个标准方向渲染成正交图，给验收用。

blender -b --factory-startup -P render_views.py -- <模型.glb> <输出目录> [仰角度数=8] [分辨率=1400] [朝向修正度数=0]

每个方向出三张：
  lit_<视图>.png    打光彩色（看整体效果）
  flat_<视图>.png   不受光的贴图原色（比颜色用）
  solid_<视图>.png  灰模（看形状、破洞、折面），背景纯黑，也用来抠轮廓
物体坐标约定：Z 朝上，正面朝 -Y。名字以 COL_ 开头的碰撞体不渲染。
"""
import json
import math
import os
import sys

import bpy
from mathutils import Euler, Vector

argv = sys.argv[sys.argv.index("--") + 1:]
src, out = argv[0], argv[1]
elev = math.radians(float(argv[2]) if len(argv) > 2 else 8)
res = int(argv[3]) if len(argv) > 3 else 1400
yaw = math.radians(float(argv[4]) if len(argv) > 4 else 0)
os.makedirs(out, exist_ok=True)

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=src)
scene = bpy.context.scene
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bl_common import restore_rest_pose  # noqa: E402
from common import render_inputs  # noqa: E402
restore_rest_pose(src)   # 导入会套上第一段动画，先恢复成文件里的静止姿态
for o in list(scene.objects):
    if o.name.startswith("COL_"):
        o.hide_render = True
if yaw:
    for o in scene.objects:
        if o.parent is None:
            o.matrix_world = Euler((0, 0, yaw)).to_matrix().to_4x4() @ o.matrix_world
bpy.context.view_layer.update()
meshes = [o for o in scene.objects if o.type == "MESH" and not o.hide_render]
pts = []
for o in meshes:
    pts += [o.matrix_world @ Vector(c) for c in o.bound_box]
lo = Vector([min(p[i] for p in pts) for i in range(3)])
hi = Vector([max(p[i] for p in pts) for i in range(3)])
center, ext = (lo + hi) / 2, max(hi - lo)

cam = bpy.data.objects.new("cam", bpy.data.cameras.new("cam"))
scene.collection.objects.link(cam)
scene.camera = cam
cam.data.type = "ORTHO"
cam.data.ortho_scale = ext * 1.2
cam.data.clip_end = ext * 20
scene.render.resolution_x = scene.render.resolution_y = res
scene.render.image_settings.file_format = "PNG"
scene.view_settings.view_transform = "Standard"

world = bpy.data.worlds.new("w")
scene.world = world
world.use_nodes = True
world.color = (0, 0, 0)  # Workbench 渲染的背景色，灰模要纯黑才好抠轮廓
bg =world.node_tree.nodes["Background"]
sun = bpy.data.objects.new("sun", bpy.data.lights.new("sun", "SUN"))
sun.data.energy = 2.6
sun.rotation_euler = (math.radians(50), 0, math.radians(-30))
scene.collection.objects.link(sun)

VIEWS = {"front": (0, -1), "left": (-1, 0), "back": (0, 1), "right": (1, 0)}


def shoot(name, x, y):
    d = Vector((x * math.cos(elev), y * math.cos(elev), math.sin(elev)))
    cam.location = center + d * ext * 4
    cam.rotation_euler = (-d).to_track_quat("-Z", "Y").to_euler()
    scene.render.filepath = os.path.join(out, name + ".png")
    bpy.ops.render.render(write_still=True)


for mode in ("lit", "flat", "solid"):
    if mode == "lit":
        # 4.2 叫 BLENDER_EEVEE_NEXT，其他版本叫 BLENDER_EEVEE：按当前版本支持的枚举选
        _engines = bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items.keys()
        scene.render.engine = "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in _engines else "BLENDER_EEVEE"
        scene.render.film_transparent = False
        bg.inputs[0].default_value = (1, 1, 1, 1)
        bg.inputs[1].default_value = 0.7
        sun.hide_render = False
    else:
        scene.render.engine = "BLENDER_WORKBENCH"
        sh = scene.display.shading
        sun.hide_render = True
        if mode == "flat":
            sh.light = "FLAT"
            sh.color_type = "TEXTURE"
            sh.show_cavity = False
            sh.show_shadows = False
            scene.render.film_transparent = True
        else:
            sh.light = "STUDIO"
            sh.color_type = "SINGLE"
            sh.single_color = (0.8, 0.8, 0.8)
            sh.show_cavity = True
            sh.cavity_type = "BOTH"
            sh.show_shadows = False
            scene.render.film_transparent = False
            sh.background_type = "VIEWPORT"
            sh.background_color = (0, 0, 0)
    for v, (x, y) in VIEWS.items():
        shoot(f"{mode}_{v}", x, y)

tris = sum(sum(len(p.vertices) - 2 for p in o.data.polygons) for o in meshes)
json.dump({"bbox_min": list(lo), "bbox_max": list(hi), "size": list(hi - lo), "triangles": tris,
           "meshes": [o.name for o in meshes], "elevation_deg": math.degrees(elev),
           "schema_version": 2, "inputs": render_inputs(src, math.degrees(elev), res, math.degrees(yaw)),
           "blender_version": bpy.app.version_string},
          open(os.path.join(out, "render.json"), "w"), indent=1)
print("RENDER_DONE")
