import * as THREE from 'three';
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js';
import {OrbitControls} from 'three/examples/jsm/controls/OrbitControls.js';
import {RoomEnvironment} from 'three/examples/jsm/environments/RoomEnvironment.js';

const GROUPS = {
  roof:    {label:'屋顶 Roof',      test:n=>/roof|eave|ridge|chimney|crescent|socket/i.test(n), dir:[0,1,0],  dist:0.55},
  balcony: {label:'阳台 Balcony',   test:n=>/balcony|baluster|finial/i.test(n),                  dir:[0,0.1,1],dist:0.5},
  openings:{label:'门窗 Openings',  test:n=>/door|shutter|window|pediment|arch|relief/i.test(n), dir:[0,0,1],  dist:0.3},
  found:   {label:'基座 Foundation',test:n=>/foundation|underside|corner|closure/i.test(n),     dir:[0,-1,0], dist:0.35},
  walls:   {label:'墙体 Walls',     test:n=>true,                                                dir:[0,0,0],  dist:0}
};
const order = ['roof','balcony','openings','found','walls'];
const gOf = n => order.find(k=>GROUPS[k].test(n));

const canvas = document.getElementById('c');
const renderer = new THREE.WebGLRenderer({canvas, antialias:true, alpha:true, preserveDrawingBuffer:true});
renderer.setClearColor(0x000000,0); renderer.setPixelRatio(Math.min(devicePixelRatio,2));
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 0.9;
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
const scene = new THREE.Scene();
const pm = new THREE.PMREMGenerator(renderer);
scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture;
scene.environmentIntensity = 0.55;
const cam = new THREE.PerspectiveCamera(32, 1, 0.1, 100);
const controls = new OrbitControls(cam, canvas);
controls.enableDamping = true; controls.maxPolarAngle = Math.PI*0.52;

const key = new THREE.DirectionalLight(0xfff0dc, 3.0);
key.castShadow = true; key.shadow.mapSize.set(2048,2048); key.shadow.bias = -0.0004; key.shadow.normalBias = 0.02;
scene.add(key, key.target);
const rim = new THREE.DirectionalLight(0xa8c4ff, 1.2); scene.add(rim);

const floor = new THREE.Mesh(new THREE.CircleGeometry(30,64), new THREE.ShadowMaterial({opacity:0.32}));
floor.rotation.x = -Math.PI/2; floor.receiveShadow = true; scene.add(floor);

const parts = []; let center = new THREE.Vector3(), R = 1, exploded = 0, target = 0;
const state = {roof:true,balcony:true,openings:true,found:true,walls:true};

const b64 = document.getElementById('glb').textContent.trim();
const bin = Uint8Array.from(atob(b64), c=>c.charCodeAt(0));
new GLTFLoader().parse(bin.buffer, '', gltf=>{
  const root = gltf.scene; scene.add(root);
  const box = new THREE.Box3().setFromObject(root);
  const size = box.getSize(new THREE.Vector3()); box.getCenter(center); R = Math.max(size.x,size.y,size.z);
  floor.position.y = box.min.y - 0.002;
  root.traverse(o=>{
    if(!o.isMesh) return;
    o.castShadow = o.receiveShadow = true;
    if(o.material){ o.material.roughness = Math.max(o.material.roughness??0.5, 0.45); o.material.envMapIntensity = 1; }
    const g = gOf(o.name), bb = new THREE.Box3().setFromObject(o), c = bb.getCenter(new THREE.Vector3());
    const rad = c.clone().sub(center); rad.y = 0;
    parts.push({o, g, base:o.position.clone(), rad, c});
  });
  key.position.set(center.x+R*1.4, center.y+R*2.2, center.z+R*1.6);
  key.target.position.copy(center);
  const s = R*1.2; Object.assign(key.shadow.camera,{left:-s,right:s,top:s,bottom:-s,near:0.1,far:R*8}); key.shadow.camera.updateProjectionMatrix();
  rim.position.set(center.x-R*2, center.y+R, center.z-R*2);
  cam.position.set(center.x+R*1.5, center.y+R*0.6, center.z+R*2.2);
  controls.target.copy(center); controls.minDistance = R*1.0; controls.maxDistance = R*8;
  document.body.classList.add('ready'); window.__ready = true;
});

function applyExplode(){
  for(const p of parts){
    const G = GROUPS[p.g], d = new THREE.Vector3(...G.dir).normalize().multiplyScalar(G.dist*R*exploded);
    // 墙体里的零件按径向轻微外推，露出内部层次
    const rad = p.rad.clone().multiplyScalar(0.0);
    const local = d.add(rad);
    if(p.o.parent) local.applyQuaternion(p.o.parent.getWorldQuaternion(new THREE.Quaternion()).invert());
    p.o.position.copy(p.base).add(local);
    p.o.visible = state[p.g];
  }
}

// UI
const ui = document.getElementById('groups');
for(const k of order){
  const b = document.createElement('button'); b.className='on'; b.textContent = GROUPS[k].label;
  b.onclick = ()=>{ state[k]=!state[k]; b.classList.toggle('on',state[k]); touch(); };
  ui.appendChild(b);
}
const sl = document.getElementById('ex');
sl.oninput = ()=>{ target = +sl.value; touch(); };
let auto = true, lastTouch = 0, t0 = performance.now();
function touch(){ auto = false; lastTouch = performance.now(); }
controls.addEventListener('start', touch);
addEventListener('wheel', touch, {passive:true});
document.getElementById('tour').onclick = ()=>{ auto = true; t0 = performance.now(); };
window.__setExplode = v=>{ target = v; exploded = v; sl.value = v; auto=false; applyExplode(); };
window.__setCam = (az,el,dist)=>{ const r=R*dist; controls.target.set(center.x, center.y+R*0.15*exploded, center.z); cam.position.set(center.x+r*Math.sin(az)*Math.cos(el), center.y+R*0.12*exploded+r*Math.sin(el), center.z+r*Math.cos(az)*Math.cos(el)); controls.update(); };

function resize(){ const w=canvas.clientWidth,h=canvas.clientHeight; renderer.setSize(w,h,false); cam.aspect=w/h; cam.updateProjectionMatrix(); }
addEventListener('resize', resize); resize();
const ease = x=>x<.5?4*x*x*x:1-Math.pow(-2*x+2,3)/2;
let frozen=false; window.__freeze=v=>{frozen=v};
window.__renderOnce=()=>{applyExplode();controls.update();renderer.render(scene,cam);};
renderer.setAnimationLoop(()=>{
  if(frozen) return;
  if(!auto && performance.now()-lastTouch > 25000){ auto = true; t0 = performance.now(); }
  if(auto && parts.length){
    const t = ((performance.now()-t0)/1000) % 16;
    // 0-3 合 · 3-7 展开 · 7-11 保持 · 11-15 收回
    target = t<3?0 : t<7? ease((t-3)/4) : t<11?1 : t<15? 1-ease((t-11)/4) : 0;
    sl.value = target;
    const az = 0.55 + t/16*Math.PI*2*0.5, el = 0.28 + 0.1*Math.sin(t/16*Math.PI*2);
    const r = R*(2.7 + 1.3*target);
    cam.position.set(center.x+r*Math.sin(az)*Math.cos(el), center.y+R*0.12*target+r*Math.sin(el), center.z+r*Math.cos(az)*Math.cos(el));
    controls.target.set(center.x, center.y+R*0.15*target, center.z);
  }
  exploded += (target-exploded)*(auto?1:0.12);
  applyExplode(); controls.update(); renderer.render(scene,cam);
});
