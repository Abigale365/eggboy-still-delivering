# 功能说明格式（导出的 GLB 里）

游戏（three.js 等）读 GLB 就能用，不用另外的配置文件。

## 节点命名
| 名字 | 是什么 |
|---|---|
| `door`（或别的部件名） | 转轴空节点，放在合页轴上；会动的网格是它的子节点 |
| `door_leaf` | 会动的那块网格（从原版切出来的） |
| `*_knuckle` | 合页轴筒这类本来就插在别的部件里的小件，功能检查不算穿模 |
| `socket_*` | 位置点（空节点）：`socket_smoke` 冒烟、`socket_fire` 生火、`socket_bake` 放东西…… |
| `interact_point` | 角色站着互动的位置（在地面上） |
| `COL_*` | 碰撞体，游戏里隐藏 |

## 节点 extras
- 每个网格：`lux3d_origin: true`（从原件改的）/ `false`（新加的，需用户同意）。
- 转轴节点：
  ```json
  {"function": "door",
   "hinge": {"axis": "y", "sign": -1, "axis_blender": "z", "sign_blender": -1,
             "min_deg": 0, "max_deg": 100, "rest_deg": 22,
             "note": "角度 0 = 关；节点静止姿态是 rest_deg；转 deg 度 = 绕 axis 转 sign*deg"}}
  ```
  `axis` / `sign` 按 glTF（Y 朝上，three.js 直接用）；`axis_blender` / `sign_blender` 是 Blender（Z 朝上）里的。
  three.js 里设角度：`door.quaternion.copy(rest0).multiply(new Quaternion().setFromAxisAngle(axisVec, sign * rad))`，其中 `rest0` 是静止姿态再转回 0° 的结果。
- 位置点：`{"function": "smoke"}` 等。
- 场景 extras：`asset_id`、`asset_name`、`height_m`、`functions`（asset.json 里 functions 的 JSON 字符串）。

## 动画
每个转轴两段：`<名>_open`（min→max）、`<名>_close`（max→min），各约 1.2 秒。

检查时分别使用 glTF 的 `axis/sign` 与 Blender 的 `axis_blender/sign_blender`，不要混用。功能结果带输入与检查脚本摘要；改模型、配置或检查器后重新生成结果。

转动检测默认每 ≤2° 采样一次，并在世界坐标中比较网格。`functions` 的转轴项可设置 `collision_step_deg`（大于 0，不超过 10）、`axis_ignore_m`（0–0.1m，默认 0.04）和 `ignore_meshes`（明确允许接触的网格名列表）。只按真实的合页结构设置忽略范围，不用增大范围掩盖穿模。
