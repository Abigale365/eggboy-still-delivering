"""Blender 精修工具箱。每件素材写一个自己的精修脚本（refine/<id>_refine.py），开头：

    import sys; sys.path.insert(0, r"<skill>/scripts"); from refine_lib import *

约定：Z 朝上、正面朝 -Y、单位米、原点在底面中心。底子永远是 Lux3D 原版（见 references/surgery.md）。

【小手术：可以直接用】
  导入整理     import_lux3d / normalize
  看贴图分面   face_samples / rgb_to_hsv / outer_faces / grow_mask / face_mask_to_verts
  切 / 删      split_faces / delete_faces
  补洞抹坑     fill_small_holes / close_recesses / smooth_selected_bumps / box_uv_faces
  改贴图       paint_uv_tris / recolor_texture（只挪一小步）
  功能         hinge / add_socket / add_collider / raycast_surface
  减面烘焙     decimate_bake / decimate_keep_uv（不烘焙的回退，先劈开非流形边）
  清碎片       face_components / remove_small_islands / uv_from_neighbors
  按区域调色   uv_mask / recolor_masked（皮革、黄铜这类色移较大的区域，按面划区域，不按颜色半径硬套）
  分开烘       见 split_bake.py 的 rebake_region（薄壳处整体烘焙出斑时用）
  导出         export_glb
【建模函数：会新建或替换部件，必须先征得用户同意】
  brick_box / arched_slab / arch_band / crescent / stud / path_tube / rounded_slab / rounded_rect /
  bricks_along / dome_from_envelope / radial_envelope / collar / cut_below / place_on_surface /
  tex_noise_color / mat_color / mat_image
  （这些是 v1 反面例子留下的工具，用户同意换件时才用；新部件要标 lux3d_origin=False）
"""
import math
import os
import random

import bmesh
import bpy
import numpy as np
from mathutils import Matrix, Vector
from mathutils.bvhtree import BVHTree


# ---------------------------------------------------------------- 导入整理
def reset_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)


def import_lux3d(path):
    """导入 Lux3D 的 GLB，合成一个网格物体返回（Lux3D 一般只有一个网格）。"""
    bpy.ops.import_scene.gltf(filepath=path)
    meshes = [o for o in bpy.context.scene.objects if o.type == "MESH"]
    for o in meshes:
        o.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    if len(meshes) > 1:
        bpy.ops.object.join()
    ob = bpy.context.view_layer.objects.active
    # 去掉空的父节点，把变换应用掉
    mw = ob.matrix_world.copy()
    ob.parent = None
    ob.matrix_world = mw
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
    for o in list(bpy.context.scene.objects):
        if o.type == "EMPTY":
            bpy.data.objects.remove(o)
    return ob


def normalize(ob, height_m, yaw_deg=0.0):
    """缩放到真实高度、底面中心放到原点。返回缩放倍数。"""
    if yaw_deg:
        ob.data.transform(Matrix.Rotation(math.radians(yaw_deg), 4, "Z"))
    v = np.array([p.co for p in ob.data.vertices])
    lo, hi = v.min(0), v.max(0)
    s = height_m / (hi[2] - lo[2])
    c = Vector(((lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2, lo[2]))
    ob.data.transform(Matrix.Diagonal((s, s, s, 1)) @ Matrix.Translation(-c))
    ob.data.update()
    return s


def mesh_bounds(ob):
    v = np.array([ob.matrix_world @ p.co for p in ob.data.vertices])
    return v.min(0), v.max(0)


# ---------------------------------------------------------------- 看贴图分面
def _image_array(img):
    w, h = img.size
    a = np.empty(w * h * 4, np.float32)
    img.pixels.foreach_get(a)
    return a.reshape(h, w, 4)


def material_images(ob):
    """返回 (底色图, 金属粗糙图) 的 numpy 数组（线性 0–1，底色已转回 sRGB 数值）。"""
    mat = ob.active_material
    base = mr = None
    for n in mat.node_tree.nodes:
        if n.type != "TEX_IMAGE" or not n.image:
            continue
        links = [l.to_socket.name for l in n.outputs["Color"].links]
        cs = n.image.colorspace_settings.name
        if any("Base Color" in s for s in links) or (base is None and cs == "sRGB"):
            base = n.image
        else:
            mr = n.image
    return base, mr


def face_samples(ob):
    """每个面在面中心 UV 处采样贴图：返回 dict(center, normal, rgb(0–255), metal, rough, area)。"""
    me = ob.data
    base, mr = material_images(ob)
    B = _image_array(base) if base else None
    M = _image_array(mr) if mr else None
    uv = me.uv_layers.active.data
    n = len(me.polygons)
    cen = np.zeros((n, 3)); nor = np.zeros((n, 3)); area = np.zeros(n)
    me.polygons.foreach_get("center", cen.ravel())
    me.polygons.foreach_get("normal", nor.ravel())
    me.polygons.foreach_get("area", area)
    loop_uv = np.zeros(len(me.loops) * 2)
    uv.foreach_get("uv", loop_uv)
    loop_uv = loop_uv.reshape(-1, 2)
    starts = np.zeros(n, int); totals = np.zeros(n, int)
    me.polygons.foreach_get("loop_start", starts)
    me.polygons.foreach_get("loop_total", totals)
    fuv = np.array([loop_uv[s:s + t].mean(0) for s, t in zip(starts, totals)])

    def sample(arr):
        h, w = arr.shape[:2]
        x = np.clip((fuv[:, 0] % 1) * w, 0, w - 1).astype(int)
        y = np.clip((fuv[:, 1] % 1) * h, 0, h - 1).astype(int)
        return arr[y, x]
    rgb = sample(B)[:, :3] * 255 if B is not None else np.full((n, 3), 200.0)
    if M is not None:
        m = sample(M)
        metal, rough = m[:, 2], m[:, 1]
    else:
        metal, rough = np.zeros(n), np.full(n, 0.8)
    return {"center": cen, "normal": nor, "rgb": rgb, "metal": metal, "rough": rough, "area": area, "uv": fuv}


def rgb_to_hsv(rgb):
    r, g, b = (rgb / 255.0).T
    mx, mn = np.max([r, g, b], 0), np.min([r, g, b], 0)
    d = mx - mn + 1e-9
    h = np.where(mx == r, ((g - b) / d) % 6, np.where(mx == g, (b - r) / d + 2, (r - g) / d + 4)) * 60
    s = np.where(mx > 0, (mx - mn) / (mx + 1e-9), 0)
    return np.stack([h, s, mx], 1)


def select_faces(ob, mask):
    me = ob.data
    me.polygons.foreach_set("select", np.asarray(mask, bool))
    me.update()


def grow_mask(ob, mask, steps=1):
    """沿相邻面把选择扩一圈（填掉分类时的零星漏选）。"""
    bm = bmesh.new(); bm.from_mesh(ob.data); bm.faces.ensure_lookup_table()
    m = np.asarray(mask, bool).copy()
    for _ in range(steps):
        add = m.copy()
        for f in bm.faces:
            if m[f.index]:
                for e in f.edges:
                    for g in e.link_faces:
                        add[g.index] = True
        m = add
    bm.free()
    return m


def delete_faces(ob, mask):
    bm = bmesh.new(); bm.from_mesh(ob.data); bm.faces.ensure_lookup_table()
    kill = [f for f in bm.faces if mask[f.index]]
    bmesh.ops.delete(bm, geom=kill, context="FACES")
    loose = [v for v in bm.verts if not v.link_faces]
    bmesh.ops.delete(bm, geom=loose, context="VERTS")
    bm.to_mesh(ob.data); bm.free(); ob.data.update()


def split_faces(ob, mask, name):
    """把选中的面分成一个新物体（保留材质和 UV），返回新物体。"""
    new = ob.copy(); new.data = ob.data.copy(); new.name = name; new.data.name = name
    bpy.context.collection.objects.link(new)
    delete_faces(new, ~np.asarray(mask, bool))
    delete_faces(ob, np.asarray(mask, bool))
    return new


# ---------------------------------------------------------------- 局部修形
def smooth_selected_bumps(ob, vert_mask, iters=30, keep=0.0, thresh=None):
    """对选中的顶点做拉普拉斯平滑，用来抹平尖锐小洞和平折面。
    thresh：只改动离平滑位置超过这个距离的点（米），None 表示全部改；keep 是保留原位置的比例。"""
    bm = bmesh.new(); bm.from_mesh(ob.data); bm.verts.ensure_lookup_table()
    co = np.array([v.co for v in bm.verts])
    nbr = [[e.other_vert(v).index for e in v.link_edges] for v in bm.verts]
    sel = np.asarray(vert_mask, bool)
    sm = co.copy()
    for _ in range(iters):
        nxt = sm.copy()
        for i in np.nonzero(sel)[0]:
            if nbr[i]:
                nxt[i] = sm[nbr[i]].mean(0)
        sm = nxt
    d = np.linalg.norm(sm - co, axis=1)
    move = sel if thresh is None else sel & (d > thresh)
    new = co.copy()
    new[move] = co[move] * keep + sm[move] * (1 - keep)
    for i in np.nonzero(move)[0]:
        bm.verts[i].co = new[i]
    bm.to_mesh(ob.data); bm.free(); ob.data.update()
    return int(move.sum())


def close_recesses(ob, center, vmask, max_depth=0.05, bin_deg=2.0, keep_below=0.002, window=7, pct=70):
    """把凹进去的坑、缺口往外推平（形态学“闭运算”）：以 center 为球心，按方位角 / 仰角分格，
    每格取最外的半径，再在 window×window 格里取 pct 分位当“外壳”（坑只占少数格，会被忽略），
    比外壳低 max_depth 以内的点推到外壳上。适合圆顶、圆柱这类鼓起的外壳；
    vmask 只选外表面的点（内腔离外壳远，超过 max_depth 不会被动）。返回推了多少点。"""
    me = ob.data
    co = np.zeros(len(me.vertices) * 3); me.vertices.foreach_get("co", co); co = co.reshape(-1, 3)
    c = np.array(center, float)
    d = co - c
    rho = np.linalg.norm(d, axis=1)
    th = np.degrees(np.arctan2(d[:, 1], d[:, 0])) + 180
    ph = np.degrees(np.arctan2(d[:, 2], np.hypot(d[:, 0], d[:, 1]))) + 90
    nb_t, nb_p = int(360 / bin_deg), int(180 / bin_deg)
    it = np.clip((th / bin_deg).astype(int), 0, nb_t - 1); ip = np.clip((ph / bin_deg).astype(int), 0, nb_p - 1)
    env = np.zeros((nb_p, nb_t))
    sel = np.asarray(vmask, bool)
    np.maximum.at(env, (ip[sel], it[sel]), rho[sel])
    # 空格子用邻格补，再取 3×3 中值去掉孤立尖刺
    from itertools import product
    for _ in range(3):
        z = env == 0
        if not z.any():
            break
        pad = np.pad(env, 1, mode="wrap")
        nbr = np.max([pad[1 + a:nb_p + 1 + a, 1 + b:nb_t + 1 + b] for a, b in product((-1, 0, 1), repeat=2)], axis=0)
        env[z] = nbr[z]
    h = window // 2
    pad = np.pad(env, h, mode="wrap")
    stack = np.array([pad[h + a:nb_p + h + a, h + b:nb_t + h + b] for a, b in product(range(-h, h + 1), repeat=2)])
    stack = np.where(stack > 0, stack, np.nan)
    valid = np.isfinite(stack).any(axis=0)
    env = np.zeros_like(env)
    env[valid] = np.nanpercentile(stack[:, valid], pct, axis=0)
    target = env[ip, it] - keep_below
    move = sel & (rho < target) & (rho > target - max_depth)
    # Lux3D 的外壳常有厚度：内层离外层也只有几厘米。往外打射线，被自己挡住的是内层，不动
    bvh = BVHTree.FromObject(ob, bpy.context.evaluated_depsgraph_get())
    for i in np.nonzero(move)[0]:
        u = Vector(d[i] / rho[i])
        hit = bvh.ray_cast(Vector(co[i]) + u * 0.002, u, float(target[i] - rho[i]) + 0.03)
        if hit[0] is not None:
            move[i] = False
    co[move] = c + d[move] / rho[move, None] * target[move, None]
    me.vertices.foreach_set("co", co.ravel()); me.update()
    return int(move.sum())


def outer_faces(ob, center, tol=0.03, bin_deg=3.0):
    """按“离 center 最远的那层”找外表面的面（不看法线，Lux3D 的法线常有反的）：
    按方位角 / 仰角分格，每格最远的面中心往里 tol 以内算外表面。"""
    me = ob.data
    c = np.zeros(len(me.polygons) * 3); me.polygons.foreach_get("center", c); c = c.reshape(-1, 3)
    d = c - np.array(center, float)
    rho = np.linalg.norm(d, axis=1)
    it = ((np.degrees(np.arctan2(d[:, 1], d[:, 0])) + 180) / bin_deg).astype(int)
    ip = ((np.degrees(np.arctan2(d[:, 2], np.hypot(d[:, 0], d[:, 1]))) + 90) / bin_deg).astype(int)
    env = np.zeros((int(180 / bin_deg) + 1, int(360 / bin_deg) + 1))
    np.maximum.at(env, (ip, it), rho)
    return rho >= env[ip, it] - tol


def radial_envelope(points, center, bin_deg=3.0, window=5, pct=75, blur=1):
    """量“外壳”：以 center 为球心，按方位角 θ / 仰角 φ 分格，每格取最远点的半径，
    再在 window×window 格里取 pct 分位（坑、洞、内层只占少数格，会被忽略），
    没有点的格子（被排除的砖拱、烟囱那块）用周围的值慢慢填满，最后模糊 blur 次。
    返回 dict(grid, bin_deg, center)，配合 envelope_at / dome_from_envelope 用。"""
    from itertools import product
    c = np.array(center, float)
    d = np.asarray(points, float) - c
    rho = np.linalg.norm(d, axis=1)
    nt, npb = int(360 / bin_deg), int(180 / bin_deg)
    it = np.clip(((np.degrees(np.arctan2(d[:, 1], d[:, 0])) + 180) / bin_deg).astype(int), 0, nt - 1)
    ip = np.clip(((np.degrees(np.arctan2(d[:, 2], np.hypot(d[:, 0], d[:, 1]))) + 90) / bin_deg).astype(int), 0, npb - 1)
    g = np.zeros((npb, nt))
    np.maximum.at(g, (ip, it), rho)
    h = window // 2
    pad = np.pad(np.where(g > 0, g, np.nan), ((h, h), (h, h)), mode="wrap")
    st = np.array([pad[h + a:npb + h + a, h + b:nt + h + b] for a, b in product(range(-h, h + 1), repeat=2)])
    with np.errstate(all="ignore"):
        env = np.nanpercentile(st, pct, axis=0)
    known = ~np.isnan(env) & (g > 0)
    env = np.where(known, env, np.nan)
    # 填空格：反复用四邻的平均补（只补本来没数据的格）
    filled = np.nan_to_num(env, nan=np.nanmean(env))
    for _ in range(400):
        p = np.pad(filled, 1, mode="wrap")
        avg = (p[:-2, 1:-1] + p[2:, 1:-1] + p[1:-1, :-2] + p[1:-1, 2:]) / 4
        filled = np.where(known, env, avg)
    for _ in range(blur):
        p = np.pad(filled, 1, mode="wrap")
        filled = (p[1:-1, 1:-1] * 4 + p[:-2, 1:-1] + p[2:, 1:-1] + p[1:-1, :-2] + p[1:-1, 2:]) / 8
    return {"grid": filled, "bin_deg": bin_deg, "center": c, "known": known}


def envelope_at(env, theta_deg, phi_deg):
    """在外壳网格上双线性取半径。theta ∈ [-180,180]，phi ∈ [-90,90]（度）。"""
    g, b = env["grid"], env["bin_deg"]
    npb, nt = g.shape
    x = (np.asarray(theta_deg) + 180) / b - 0.5
    y = np.clip((np.asarray(phi_deg) + 90) / b - 0.5, 0, npb - 1.001)
    x0 = np.floor(x).astype(int); y0 = np.floor(y).astype(int)
    fx, fy = x - x0, y - y0
    x0m, x1m = x0 % nt, (x0 + 1) % nt
    y1 = np.minimum(y0 + 1, npb - 1)
    return (g[y0, x0m] * (1 - fx) + g[y0, x1m] * fx) * (1 - fy) + (g[y1, x0m] * (1 - fx) + g[y1, x1m] * fx) * fy


def dome_from_envelope(name, env, phi_min_deg, z_bury=None, n_theta=128, n_phi=36, mat=None, uv_scale=1.5):
    """按外壳重新铺一张干净的圆顶面（重拓扑）：经纬网格，每个点放在外壳半径上。
    phi_min_deg 是最低一圈的仰角；z_bury 给了就再往下加一圈压到这个高度（埋进台面）。"""
    c = env["center"]
    bm = bmesh.new()
    rings = []
    phis = list(np.linspace(phi_min_deg, 88.0, n_phi))
    for ph in phis:
        th = np.linspace(-180, 180, n_theta, endpoint=False)
        r = envelope_at(env, th, np.full_like(th, ph))
        if ph > 70:     # 靠近顶点的几圈往这一圈的平均半径收，免得极点处起皱
            w = min(1.0, (ph - 70) / 15)
            r = r * (1 - w) + r.mean() * w
        pr, tr = math.radians(ph), np.radians(th)
        pts = np.stack([c[0] + r * math.cos(pr) * np.cos(tr), c[1] + r * math.cos(pr) * np.sin(tr), c[2] + r * math.sin(pr)], 1)
        rings.append([bm.verts.new(p) for p in pts])
    if z_bury is not None:
        rings.insert(0, [bm.verts.new((v.co.x, v.co.y, z_bury)) for v in rings[0]])
    top = bm.verts.new((c[0], c[1], c[2] + float(envelope_at(env, 0.0, 89.9))))
    for a, b_ in zip(rings[:-1], rings[1:]):
        for k in range(n_theta):
            bm.faces.new((a[k], a[(k + 1) % n_theta], b_[(k + 1) % n_theta], b_[k]))
    for k in range(n_theta):
        bm.faces.new((rings[-1][k], rings[-1][(k + 1) % n_theta], top))
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    ob = _obj_from_bm(bm, name, mat)
    for p in ob.data.polygons:
        p.use_smooth = True
    # 经纬 UV：u 沿一圈（按大致周长缩放），v 沿高度；平铺噪点贴图看不出接缝
    me = ob.data
    uv = me.uv_layers.new(name="UVMap").data
    rmean = float(np.mean(env["grid"]))
    for p in me.polygons:
        cu = math.atan2(p.center.y - c[1], p.center.x - c[0])
        for li in p.loop_indices:
            co = me.vertices[me.loops[li].vertex_index].co
            th = math.atan2(co.y - c[1], co.x - c[0])
            if th - cu > math.pi:
                th -= 2 * math.pi
            elif cu - th > math.pi:
                th += 2 * math.pi
            uv[li].uv = (th * rmean * uv_scale, (co.z - c[2]) * uv_scale * 1.3)
    return ob


def face_mask_to_verts(ob, fmask):
    vm = np.zeros(len(ob.data.vertices), bool)
    for p in ob.data.polygons:
        if fmask[p.index]:
            vm[list(p.vertices)] = True
    return vm


# ---------------------------------------------------------------- 改贴图颜色
def _srgb_to_lab(rgb):
    c = rgb / 255.0
    c = np.where(c > 0.04045, ((c + 0.055) / 1.055) ** 2.4, c / 12.92)
    xyz = c @ np.array([[0.4124, 0.3576, 0.1805], [0.2126, 0.7152, 0.0722], [0.0193, 0.1192, 0.9505]]).T
    xyz = xyz / [0.95047, 1.0, 1.08883]
    f = np.where(xyz > 0.008856, np.cbrt(xyz), 7.787 * xyz + 16 / 116)
    return np.stack([116 * f[..., 1] - 16, 500 * (f[..., 0] - f[..., 1]), 200 * (f[..., 1] - f[..., 2])], -1)


def _lab_to_srgb(lab):
    L, a, b = lab[..., 0], lab[..., 1], lab[..., 2]
    fy = (L + 16) / 116; fx = fy + a / 500; fz = fy - b / 200
    f = np.stack([fx, fy, fz], -1)
    xyz = np.where(f ** 3 > 0.008856, f ** 3, (f - 16 / 116) / 7.787) * [0.95047, 1.0, 1.08883]
    m = np.array([[3.2406, -1.5372, -0.4986], [-0.9689, 1.8758, 0.0415], [0.0557, -0.2040, 1.0570]])
    c = xyz @ m.T
    c = np.where(c > 0.0031308, 1.055 * np.clip(c, 0, None) ** (1 / 2.4) - 0.055, 12.92 * c)
    return np.clip(c, 0, 1) * 255


def recolor_texture(image, rules, feather=10.0):
    """按颜色把贴图里的一类颜色整体挪到目标色（Lab 空间平移，保留明暗纹理）。
    rules: [(源颜色 rgb, 目标颜色 rgb, 半径 ΔE), ...]；离源颜色越近挪得越多，半径外不动。"""
    arr = _image_array(image)
    rgb = arr[:, :, :3] * 255
    lab = _srgb_to_lab(rgb.reshape(-1, 3)).reshape(rgb.shape)
    out = lab.copy()
    for src, dst, radius in rules:
        s = _srgb_to_lab(np.array(src, float)); t = _srgb_to_lab(np.array(dst, float))
        d = np.sqrt(((lab - s) ** 2).sum(-1))
        w = np.clip((radius + feather - d) / feather, 0, 1)[..., None]
        out += w * (t - s)
    arr[:, :, :3] = _lab_to_srgb(out.reshape(-1, 3)).reshape(rgb.shape) / 255
    image.pixels.foreach_set(arr.ravel())
    image.update()
    image.pack()   # 不重新打包的话，存 .blend 时改动会丢（GLB 导入的图是打包的）


def paint_uv_tris(ob, image, fmask, color, noise=8.0, seed=0):
    """把选中面在贴图上占的那块 UV 区域涂成指定颜色（加一点噪点），用来抹掉贴图上的脏色块。"""
    arr = _image_array(image)
    h, w = arr.shape[:2]
    me = ob.data
    uv = me.uv_layers.active.data
    rng = np.random.default_rng(seed)
    col = np.array(color, float) / 255
    me.calc_loop_triangles()
    for t in me.loop_triangles:
        if not fmask[t.polygon_index]:
            continue
        p = np.array([uv[l].uv for l in t.loops]) * [w, h]
        x0, y0 = np.floor(p.min(0)).astype(int); x1, y1 = np.ceil(p.max(0)).astype(int)
        x0, y0 = max(x0 - 1, 0), max(y0 - 1, 0); x1, y1 = min(x1 + 1, w - 1), min(y1 + 1, h - 1)
        if x1 < x0 or y1 < y0:
            continue
        xs, ys = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
        a, b, c = p
        def edge(p0, p1):
            return (p1[0] - p0[0]) * (ys - p0[1]) - (p1[1] - p0[1]) * (xs - p0[0])
        e0, e1, e2 = edge(a, b), edge(b, c), edge(c, a)
        inside = ((e0 >= -1) & (e1 >= -1) & (e2 >= -1)) | ((e0 <= 1) & (e1 <= 1) & (e2 <= 1))
        yy, xx = np.nonzero(inside)
        if len(yy) == 0:
            continue
        n = rng.normal(0, noise / 255, (len(yy), 1))
        arr[yy + y0, xx + x0, :3] = np.clip(col + n, 0, 1)
    image.pixels.foreach_set(arr.ravel())
    image.update()
    image.pack()


# ---------------------------------------------------------------- 程序贴图（小尺寸、可平铺）
def _new_image(name, size, arr, srgb=True):
    img = bpy.data.images.new(name, size, size, alpha=False)
    if not srgb:
        img.colorspace_settings.name = "Non-Color"
    rgba = np.ones((size, size, 4), np.float32)
    rgba[:, :, :3] = arr
    img.pixels.foreach_set(rgba.ravel())
    img.pack()
    return img


def _value_noise(size, cells, rng):
    g = rng.random((cells + 1, cells + 1))
    g[-1, :] = g[0, :]; g[:, -1] = g[:, 0]
    x = np.linspace(0, cells, size, endpoint=False)
    i = x.astype(int); f = x - i
    f = f * f * (3 - 2 * f)
    a = g[i][:, i]; b = g[i][:, i + 1]; c = g[i + 1][:, i]; d = g[i + 1][:, i + 1]
    fx = f[None, :]; fy = f[:, None]
    return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy


def tex_noise_color(name, base_rgb, var=0.08, speck_rgb=None, speck=0.0, size=512, seed=1, cells=(6, 24, 96)):
    """带起伏和斑点的平铺颜色图：灰泥、铁、黄铜、木头、砖都用它。"""
    rng = np.random.default_rng(seed)
    n = sum(_value_noise(size, c, rng) * wgt for c, wgt in zip(cells, (0.5, 0.3, 0.2)))
    n = (n - n.mean()) / (n.std() + 1e-9)
    base = np.array(base_rgb, float) / 255
    arr = np.clip(base[None, None] * (1 + var * n[..., None]), 0, 1)
    if speck_rgb is not None and speck > 0:
        s = _value_noise(size, cells[-1], rng)
        m = (s > 1 - speck)[..., None]
        arr = np.where(m, np.array(speck_rgb, float)[None, None] / 255 * (0.9 + 0.2 * rng.random((size, size, 1))), arr)
    return _new_image(name, size, arr.astype(np.float32))


def mat_color(name, rgb, rough=0.8, metal=0.0, emit=None, emit_strength=0.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    p = m.node_tree.nodes["Principled BSDF"]
    p.inputs["Base Color"].default_value = (*srgb_to_linear(rgb), 1)
    p.inputs["Roughness"].default_value = rough
    p.inputs["Metallic"].default_value = metal
    if emit is not None:
        p.inputs["Emission Color"].default_value = (*srgb_to_linear(emit), 1)
        p.inputs["Emission Strength"].default_value = emit_strength
    return m


def mat_image(name, image, rough=0.8, metal=0.0, tint=None):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    p = nt.nodes["Principled BSDF"]
    t = nt.nodes.new("ShaderNodeTexImage"); t.image = image
    nt.links.new(t.outputs["Color"], p.inputs["Base Color"])
    p.inputs["Roughness"].default_value = rough
    p.inputs["Metallic"].default_value = metal
    return m


def srgb_to_linear(rgb):
    c = np.array(rgb, float) / 255
    return tuple(np.where(c > 0.04045, ((c + 0.055) / 1.055) ** 2.4, c / 12.92))


# ---------------------------------------------------------------- 新建部件（都返回物体）
def _obj_from_bm(bm, name, mat=None):
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me); bm.free()
    ob = bpy.data.objects.new(name, me)
    bpy.context.collection.objects.link(ob)
    if mat:
        me.materials.append(mat)
    return ob


def box_uv(ob, scale=1.0):
    """按世界尺寸做方盒投影 UV（平铺贴图用），scale = 每米重复几次。"""
    me = ob.data
    if not me.uv_layers:
        me.uv_layers.new()
    uv = me.uv_layers.active.data
    mw = ob.matrix_world
    for p in me.polygons:
        n = (mw.to_3x3() @ p.normal)
        ax = int(np.argmax(np.abs(n)))
        for li in p.loop_indices:
            co = mw @ me.vertices[me.loops[li].vertex_index].co
            u, v = [(co.y, co.z), (co.x, co.z), (co.x, co.y)][ax]
            uv[li].uv = (u * scale, v * scale)


def brick_box(name, size, bevel=0.012, mat=None, seed=0, jitter=0.0, segments=2):
    """倒圆角的砖块（中心在原点），jitter 让顶点随机偏一点，看起来是手工砖。"""
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    bmesh.ops.scale(bm, vec=Vector(size), verts=bm.verts)
    bmesh.ops.bevel(bm, geom=bm.verts[:] + bm.edges[:], offset=min(bevel, min(size) * 0.45), segments=segments, affect="EDGES", profile=0.5)
    if jitter:
        rng = random.Random(seed)
        for v in bm.verts:
            v.co += Vector((rng.uniform(-1, 1), rng.uniform(-1, 1), rng.uniform(-1, 1))) * jitter
    ob = _obj_from_bm(bm, name, mat)
    return ob


def arch_outline(width, height, n_arc=24):
    """拱形轮廓（下边是直的，上面半圆），返回 XZ 平面上的点（逆时针），底边中点在原点。"""
    r = width / 2
    straight = max(height - r, 0)
    pts = [(-r, 0), (r, 0), (r, straight)]
    for i in range(1, n_arc):
        a = math.pi * i / n_arc
        pts.append((r * math.cos(a), straight + r * math.sin(a)))
    pts.append((-r, straight))
    return pts


def arched_slab(name, width, height, thick, bevel=0.006, mat=None, n_arc=24):
    """拱顶门板：XZ 平面上的拱形，沿 -Y 挤出厚度（前面在 -Y）。"""
    bm = bmesh.new()
    verts = [bm.verts.new((x, 0, z)) for x, z in arch_outline(width, height, n_arc)]
    f = bm.faces.new(verts)
    r = bmesh.ops.extrude_face_region(bm, geom=[f])
    ext = [e for e in r["geom"] if isinstance(e, bmesh.types.BMVert)]
    bmesh.ops.translate(bm, vec=Vector((0, -thick, 0)), verts=ext)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    if bevel:
        bmesh.ops.bevel(bm, geom=bm.edges[:], offset=bevel, segments=2, affect="EDGES", profile=0.5)
    return _obj_from_bm(bm, name, mat)


def arch_band(name, w_out, h_out, w_in, h_in, depth, mat=None, n_arc=24):
    """拱形门框（倒 U 形的一圈带子），在 XZ 平面，沿 -Y 挤出 depth。底边中点在原点。"""
    # 从右下角往上、绕过拱顶、到左下角；内外两条点数一样，逐段连成四边形
    o = arch_outline(w_out, h_out, n_arc)[1:] + [(-w_out / 2, 0)]
    i = arch_outline(w_in, h_in, n_arc)[1:] + [(-w_in / 2, 0)]
    bm = bmesh.new()
    vo = [bm.verts.new((x, 0, z)) for x, z in o]
    vi = [bm.verts.new((x, 0, z)) for x, z in i]
    for k in range(len(vo) - 1):
        bm.faces.new((vo[k], vo[k + 1], vi[k + 1], vi[k]))
    r = bmesh.ops.extrude_face_region(bm, geom=bm.faces[:])
    bmesh.ops.translate(bm, vec=Vector((0, -depth, 0)), verts=[e for e in r["geom"] if isinstance(e, bmesh.types.BMVert)])
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    return _obj_from_bm(bm, name, mat)


def rounded_rect(cx, cy, w, d, r, n=8):
    """XY 平面的圆角矩形（逆时针点列）。"""
    r = min(r, w / 2 - 1e-4, d / 2 - 1e-4)
    pts = []
    for (sx, sy, a0) in ((1, -1, -90), (1, 1, 0), (-1, 1, 90), (-1, -1, 180)):
        ccx, ccy = cx + sx * (w / 2 - r), cy + sy * (d / 2 - r)
        for k in range(n + 1):
            a = math.radians(a0 + 90 * k / n)
            pts.append((ccx + r * math.cos(a), ccy + r * math.sin(a)))
    return pts


def rounded_slab(name, cx, cy, w, d, r, z0, z1, round_edge=0.0, mat=None, n=8):
    """圆角矩形厚板（台面、底座芯），round_edge>0 时上下边做成圆鼓边（牛鼻边）。"""
    if round_edge > 0:
        prof = []
        for k in range(5):           # 下边：从里往外鼓
            a = math.radians(-90 + 90 * k / 4)
            prof.append((round_edge * (1 - math.cos(a)), z0 + round_edge * (1 + math.sin(a))))
        for k in range(5):           # 上边
            a = math.radians(90 * k / 4)
            prof.append((round_edge * (1 - math.cos(a)), z1 - round_edge * (1 - math.sin(a))))
    else:
        prof = [(0, z0), (0, z1)]
    bm = bmesh.new()
    rings = []
    for inset, z in prof:
        rings.append([bm.verts.new((x, y, z)) for x, y in rounded_rect(cx, cy, w - 2 * inset, d - 2 * inset, r - inset, n)])
    m = len(rings[0])
    for a, b in zip(rings[:-1], rings[1:]):
        for k in range(m):
            bm.faces.new((a[k], a[(k + 1) % m], b[(k + 1) % m], b[k]))
    bm.faces.new(rings[-1]); bm.faces.new(rings[0][::-1])
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bmesh.ops.triangulate(bm, faces=[f for f in bm.faces if len(f.verts) > 4])
    ob = _obj_from_bm(bm, name, mat)
    return ob


def polyline_samples(pts, closed=True):
    """把折线按弧长参数化：返回 (总长, 函数 s→(点, 切线))。"""
    P = [Vector((p[0], p[1], p[2] if len(p) > 2 else 0)) for p in pts]
    if closed:
        P = P + [P[0]]
    seg = [(P[i], P[i + 1], (P[i + 1] - P[i]).length) for i in range(len(P) - 1)]
    total = sum(s[2] for s in seg)

    def at(s):
        s = s % total if closed else min(max(s, 0), total)
        for a, b, L in seg:
            if s <= L or (a, b, L) == seg[-1]:
                t = (b - a).normalized() if L > 0 else Vector((1, 0, 0))
                return a + (b - a) * (s / L if L else 0), t
            s -= L
    return total, at


def bricks_along(path_pts, z0, height, length, depth, mat, closed=True, offset=0.0, joint=0.014,
                 normal_fn=None, skip=None, name="brick", seed=0, bevel=0.01, jitter=0.003, uv_scale=2.0):
    """沿一条路径（XY 平面）摆一圈砖：外表面贴着路径、往里 depth。
    skip(中心点) 返回 True 的位置不放（比如门洞）。返回砖物体列表（每块单独物体，最后自己 join）。"""
    total, at = polyline_samples(path_pts, closed)
    n = max(1, round(total / (length + joint)))
    L = total / n
    out = []
    rng = random.Random(seed)
    for i in range(n):
        s0, s1 = offset + i * L, offset + (i + 1) * L
        _, t0 = at(s0 + 1e-4); _, t1 = at(s1 - 1e-4)
        turn = math.degrees(t0.angle(t1)) if t0.length and t1.length else 0
        k = max(1, math.ceil(turn / 15))          # 转角处拆成小块，免得直砖在弯上戳出去
        for j in range(k):
            a, b = s0 + (s1 - s0) * j / k, s0 + (s1 - s0) * (j + 1) / k
            pa, _ = at(a); pb, _ = at(b)
            ch = pb - pa
            if ch.length < 1e-6:
                continue
            t = ch.normalized()
            nrm = Vector((t.y, -t.x, 0))           # 逆时针路径的外法线
            mid = (pa + pb) / 2
            c = Vector((mid.x, mid.y, z0 + height / 2)) - nrm * (depth / 2)
            if skip and skip(c):
                continue
            blen = ch.length - joint
            if blen < 0.02:
                continue
            b_ = brick_box(f"{name}_{i}_{j}", (blen, depth, height), bevel=min(bevel, blen * 0.3), mat=mat,
                           seed=seed * 1000 + i * 10 + j, jitter=jitter, segments=1)
            ang = math.atan2(t.y, t.x)
            b_.matrix_world = Matrix.Translation(c) @ Matrix.Rotation(ang, 4, "Z") @ Matrix.Rotation(rng.uniform(-0.015, 0.015), 4, "X")
            out.append(b_)
    for b_ in out:
        box_uv(b_, uv_scale)
        _shift_uv(b_, rng.random(), rng.random())
    return out

def _shift_uv(ob, du, dv):
    for l in ob.data.uv_layers.active.data:
        l.uv = (l.uv[0] + du, l.uv[1] + dv)


def cut_below(ob, z_cut, z_to, keep=None):
    """沿水平面整齐切掉 z_cut 以下，再把切口往下拉一圈裙边到 z_to（埋进新做的台面里）。
    比直接删面 + 压边干净：Lux3D 的底边常是锯齿状的。keep(面中心) 为 True 的面不参与（比如砖拱的脚）。"""
    bm = bmesh.new(); bm.from_mesh(ob.data)
    if keep:
        faces = [f for f in bm.faces if not keep(f.calc_center_median())]
        geom = list({v for f in faces for v in f.verts}) + list({e for f in faces for e in f.edges}) + faces
    else:
        geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
    bmesh.ops.bisect_plane(bm, geom=geom, dist=1e-5, plane_co=(0, 0, z_cut), plane_no=(0, 0, 1), clear_inner=True)
    edges = [e for e in bm.edges if e.is_boundary and all(abs(v.co.z - z_cut) < 1e-4 for v in e.verts)]
    r = bmesh.ops.extrude_edge_only(bm, edges=edges)
    for v in [g for g in r["geom"] if isinstance(g, bmesh.types.BMVert)]:
        v.co.z = z_to
    bm.to_mesh(ob.data); bm.free(); ob.data.update()
    return len(edges)


def boundary_loops(bm):
    """把开口边串成一个个环，返回 [边列表]。"""
    left = {e for e in bm.edges if e.is_boundary}
    loops = []
    while left:
        e0 = left.pop(); loop = [e0]; stack = list(e0.verts)
        while stack:
            v = stack.pop()
            for e in v.link_edges:
                if e in left:
                    left.discard(e); loop.append(e); stack += list(e.verts)
        loops.append(loop)
    return loops


def fill_small_holes(ob, max_size, skip=None, mat_index=None, smooth_iters=25):
    """补小洞：外框对角线小于 max_size（米）的开口环补上面、细分、抹圆。skip(中心点, 尺寸) 返回 True 的环不补。
    mat_index 给了就把补上的面换成这个材质槽（Lux3D 贴图在补丁处没有内容，用平铺灰泥贴图代替）。返回补了几个洞。"""
    bm = bmesh.new(); bm.from_mesh(ob.data)
    n = 0; new_faces = []
    for loop in boundary_loops(bm):
        P = np.array([v.co for e in loop for v in e.verts])
        size = np.linalg.norm(P.max(0) - P.min(0))
        c = Vector(P.mean(0))
        if size > max_size or (skip and skip(c, size)):
            continue
        r = bmesh.ops.holes_fill(bm, edges=loop, sides=len(loop) + 2)
        fs = r["faces"]
        if not fs:
            continue
        t = bmesh.ops.triangulate(bm, faces=fs, quad_method="BEAUTY", ngon_method="BEAUTY")
        fs = t["faces"]
        inner = list({e for f in fs for e in f.edges if not e.is_boundary and all(g in fs for g in e.link_faces)})
        if inner:
            s = bmesh.ops.subdivide_edges(bm, edges=inner, cuts=1, use_grid_fill=False)
            fs = list({f for f in bm.faces if any(v in s["geom_inner"] for v in f.verts)} | set(f for f in fs if f.is_valid))
        new_faces += [f for f in fs if f.is_valid]
        n += 1
    # 补丁内部点平滑（边上的点不动）
    patch_verts = {v for f in new_faces for v in f.verts}
    rim = {v for v in patch_verts if any(g not in new_faces for g in v.link_faces)}
    movable = [v for v in patch_verts if v not in rim]
    for _ in range(smooth_iters):
        pos = {v: sum((e.other_vert(v).co for e in v.link_edges), Vector()) / len(v.link_edges) for v in movable}
        for v, p in pos.items():
            v.co = p
    if mat_index is not None:
        for f in new_faces:
            f.material_index = mat_index
    bm.to_mesh(ob.data); bm.free(); ob.data.update()
    return n


def box_uv_faces(ob, fmask, scale=1.0):
    """只给选中的面做方盒投影 UV（补丁换平铺材质时用）。"""
    me = ob.data
    uv = me.uv_layers.active.data
    for p in me.polygons:
        if not fmask[p.index]:
            continue
        ax = int(np.argmax(np.abs(p.normal)))
        for li in p.loop_indices:
            co = me.vertices[me.loops[li].vertex_index].co
            uv[li].uv = [(co.y, co.z), (co.x, co.z), (co.x, co.y)][ax][0] * scale, [(co.y, co.z), (co.x, co.z), (co.x, co.y)][ax][1] * scale


def snap_boundary(ob, zmax, z_to):
    """把开口边（只连一个面的边）上 z<zmax 的点压到 z_to：切掉底部后让边缘埋进新台面。"""
    bm = bmesh.new(); bm.from_mesh(ob.data)
    n = 0
    for e in bm.edges:
        if e.is_boundary:
            for v in e.verts:
                if v.co.z < zmax and v.co.z != z_to:
                    v.co.z = z_to; n += 1
    bm.to_mesh(ob.data); bm.free(); ob.data.update()
    return n


def path_tube(name, pts, radius, mat=None, sides=8, closed=False):
    """沿折线扫一根圆管（铆钉包边、铁框、插销杆）。pts 是世界坐标点列。"""
    bm = bmesh.new()
    rings = []
    P = [Vector(p) for p in pts]
    for i, p in enumerate(P):
        a = P[i - 1] if (i > 0 or closed) else P[i]
        b = P[(i + 1) % len(P)] if (i < len(P) - 1 or closed) else P[i]
        t = (b - a).normalized()
        up = Vector((0, 0, 1)) if abs(t.z) < 0.9 else Vector((1, 0, 0))
        u = t.cross(up).normalized(); w = t.cross(u).normalized()
        rings.append([bm.verts.new(p + (u * math.cos(k * 2 * math.pi / sides) + w * math.sin(k * 2 * math.pi / sides)) * radius) for k in range(sides)])
    n = len(rings) if closed else len(rings) - 1
    for i in range(n):
        r0, r1 = rings[i], rings[(i + 1) % len(rings)]
        for k in range(sides):
            bm.faces.new((r0[k], r0[(k + 1) % sides], r1[(k + 1) % sides], r1[k]))
    if not closed:
        bm.faces.new(rings[0][::-1]); bm.faces.new(rings[-1])
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    ob = _obj_from_bm(bm, name, mat)
    for p in ob.data.polygons:
        p.use_smooth = True
    return ob


def stud(name, radius, height=None, mat=None, seg=16):
    """半球形铆钉 / 圆钉（底面在原点，朝 +Z 鼓起）。"""
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=seg, v_segments=seg // 2, radius=radius)
    for v in list(bm.verts):
        if v.co.z < -1e-6:
            v.co.z = 0
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-5)
    if height:
        for v in bm.verts:
            v.co.z *= height / radius
    ob = _obj_from_bm(bm, name, mat)
    for p in ob.data.polygons:
        p.use_smooth = True
    return ob


def crescent(name, outer_r, inner_r, offset, thick, bevel=0.003, mat=None, seg=48):
    """月牙（XZ 平面，朝 -Y 挤出）：大圆减去往右上偏移的小圆。"""
    # 外圆上没被小圆盖住的那段弧 + 小圆在大圆里面的那段弧
    keep =[(outer_r * math.cos(2 * math.pi * i / (seg * 4)), outer_r * math.sin(2 * math.pi * i / (seg * 4))) for i in range(seg * 4)]
    inside = [(Vector(k) - Vector(offset)).length < inner_r for k in keep]
    start = next(i for i in range(len(keep)) if inside[i] and not inside[i - 1])   # 进入切口
    end = next(i for i in range(len(keep)) if not inside[i] and inside[i - 1])      # 离开切口
    outer = [keep[(end + j) % len(keep)] for j in range((start - end) % len(keep))]
    a0 = math.atan2(outer[-1][1] - offset[1], outer[-1][0] - offset[0])
    a1 = math.atan2(outer[0][1] - offset[1], outer[0][0] - offset[0])
    while a1 > a0:
        a1 -= 2 * math.pi
    inner = [(offset[0] + inner_r * math.cos(a0 + (a1 - a0) * t / seg), offset[1] + inner_r * math.sin(a0 + (a1 - a0) * t / seg)) for t in range(1, seg)]
    poly = outer + inner
    bm = bmesh.new()
    vs = [bm.verts.new((x, 0, z)) for x, z in poly]
    f = bm.faces.new(vs)
    r = bmesh.ops.extrude_face_region(bm, geom=[f])
    bmesh.ops.translate(bm, vec=Vector((0, -thick, 0)), verts=[e for e in r["geom"] if isinstance(e, bmesh.types.BMVert)])
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bmesh.ops.triangulate(bm, faces=[f for f in bm.faces if len(f.verts) > 4])
    if bevel:
        bmesh.ops.bevel(bm, geom=[e for e in bm.edges if e.calc_face_angle(0) > 0.6], offset=bevel, segments=2, affect="EDGES", profile=0.5)
    return _obj_from_bm(bm, name, mat)


def raycast_surface(target, origin, direction):
    """从 origin 沿 direction 打到 target 网格，返回 (点, 法线) 或 None。"""
    bvh = BVHTree.FromObject(target, bpy.context.evaluated_depsgraph_get())
    mw = target.matrix_world; mi = mw.inverted()
    loc, nor, _, _ = bvh.ray_cast(mi @ Vector(origin), (mi.to_3x3() @ Vector(direction)).normalized())
    if loc is None:
        return None
    return mw @ loc, (mw.to_3x3() @ nor).normalized()


def place_on_surface(ob, target, origin, direction, sink=0.0, up=(0, 0, 1)):
    """把部件贴到表面上：部件的 -Y（正面）对齐表面法线，往里沉 sink 米。"""
    hit = raycast_surface(target, origin, direction)
    if hit is None:
        raise RuntimeError(f"{ob.name}: 打不到表面 {origin}")
    p, n = hit
    if n.dot(Vector(direction)) > 0:   # Lux3D 的面朝向不可靠，按射线方向把法线翻到朝外
        n = -n
    q = (-n).to_track_quat("Y", "Z")   # 物体 +Y 朝里
    ob.matrix_world = Matrix.Translation(p - n * sink) @ q.to_matrix().to_4x4()
    return p, n


def join(objs, name):
    bpy.ops.object.select_all(action="DESELECT")
    for o in objs:
        o.select_set(True)
    bpy.context.view_layer.objects.active = objs[0]
    bpy.ops.object.join()
    ob = bpy.context.view_layer.objects.active
    ob.name = name; ob.data.name = name
    return ob


def shade_auto(ob, angle_deg=35):
    """平滑着色 + 按角度保留硬边（圆柱侧面平滑、顶面和侧面之间是硬边），导出 GLB 时法线会照着分开。"""
    bpy.ops.object.select_all(action="DESELECT")
    ob.select_set(True); bpy.context.view_layer.objects.active = ob
    bpy.ops.object.shade_smooth_by_angle(angle=math.radians(angle_deg))


def collar(name, target, cx, cy, r_in, r_out, mat=None, seg=48, lift=0.05, rings=6):
    """烟囱、柱子和圆顶之间的过渡圈：外圈贴着 target 表面（从上往下打射线），往里慢慢抬起贴到柱子上。
    能盖住柱脚的破边，也像真的抹灰圆角。"""
    bvh = BVHTree.FromObject(target, bpy.context.evaluated_depsgraph_get())
    mi = target.matrix_world.inverted(); mw = target.matrix_world

    def ground(x, y):
        loc, *_ = bvh.ray_cast(mi @ Vector((x, y, 50)), (mi.to_3x3() @ Vector((0, 0, -1))).normalized())
        return (mw @ loc).z if loc is not None else None
    bm = bmesh.new()
    grid = []
    for k in range(seg):
        a = 2 * math.pi * k / seg
        ca, sa = math.cos(a), math.sin(a)
        z_o = ground(cx + r_out * ca, cy + r_out * sa)
        z_o2 = ground(cx + (r_out + 0.04) * ca, cy + (r_out + 0.04) * sa)
        if z_o is None:
            z_o = z_o2 if z_o2 is not None else 0.0
        slope = (z_o - z_o2) / 0.04 if z_o2 is not None else 0.0
        row = []
        for j in range(rings + 1):
            t = j / rings                      # 0 = 外圈，1 = 贴柱子
            r = r_out + (r_in - r_out) * t
            z = z_o + slope * (r_out - r) + lift * t * t + 0.002
            row.append(bm.verts.new((cx + r * ca, cy + r * sa, z)))
        grid.append(row)
    for k in range(seg):
        a_, b_ = grid[k], grid[(k + 1) % seg]
        for j in range(rings):
            bm.faces.new((a_[j], b_[j], b_[j + 1], a_[j + 1]))
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    ob = _obj_from_bm(bm, name, mat)
    for p in ob.data.polygons:
        p.use_smooth = True
    return ob


def apply_transform(ob):
    bpy.ops.object.select_all(action="DESELECT")
    ob.select_set(True); bpy.context.view_layer.objects.active = ob
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)


# ---------------------------------------------------------------- 功能
def add_socket(name, location, parent=None, extras=None):
    e = bpy.data.objects.new(name, None)
    e.empty_display_type = "ARROWS"; e.empty_display_size = 0.1
    bpy.context.collection.objects.link(e)
    e.location = location
    if parent:
        e.parent = parent
        e.matrix_parent_inverse = parent.matrix_world.inverted()
    for k, v in (extras or {}).items():
        e[k] = v
    return e


def hinge(part, pivot, axis="Z", rest_deg=0.0, min_deg=0.0, max_deg=90.0, name=None, clips=True, sign=1, fps=24,
          part_is_at_rest=False):
    """给会动的部件装转轴：建一个空物体放在合页轴上，部件挂上去，转空物体就开关。
    rest_deg 是导出时的姿态；clips=True 时生成 <名>_open / <名>_close 两段动画。返回轴物体。
    part_is_at_rest=True：部件网格现在就摆在 rest_deg 的位置（比如从原版切下来的半开的门），
    先把网格转回 0°（关闭），再由轴转到 rest_deg——不然会转两遍。"""
    name = name or part.name
    if part_is_at_rest and rest_deg:
        R = Matrix.Rotation(-math.radians(rest_deg) * sign, 4, axis.upper())
        part.data.transform(part.matrix_world.inverted() @ Matrix.Translation(Vector(pivot)) @ R
                            @ Matrix.Translation(-Vector(pivot)) @ part.matrix_world)
        part.data.update()
    piv = bpy.data.objects.new(name, None)
    piv.empty_display_type = "SINGLE_ARROW"; piv.empty_display_size = 0.2
    bpy.context.collection.objects.link(piv)
    piv.location = pivot
    piv.rotation_mode = "XYZ"
    part.parent = piv
    part.matrix_parent_inverse = Matrix.Translation(Vector(pivot)).inverted()
    ax = "XYZ".index(axis.upper())
    # 说明里的 axis / sign 按 glTF（Y 朝上，three.js 直接用）：Blender X→x，Y→-z，Z→y
    gl_axis, gl_sign = {"X": ("x", sign), "Y": ("z", -sign), "Z": ("y", sign)}[axis.upper()]
    piv["hinge"] = {"axis": gl_axis, "sign": gl_sign, "axis_blender": axis.lower(), "sign_blender": sign,
                    "min_deg": min_deg, "max_deg": max_deg, "rest_deg": rest_deg,
                    "note": "角度 0 = 关；节点静止姿态是 rest_deg；转 deg 度 = 绕 axis 转 sign*deg"}

    def set_angle(deg):
        r = [0.0, 0.0, 0.0]; r[ax] = math.radians(deg) * sign
        piv.rotation_euler = r

    if clips:
        piv.animation_data_create()
        for clip, a, b in ((f"{name}_open", min_deg, max_deg), (f"{name}_close", max_deg, min_deg)):
            act = bpy.data.actions.new(clip)
            act.use_fake_user = True
            piv.animation_data.action = act
            for frame, deg in ((1, a), (int(fps * 1.2), b)):
                set_angle(deg)
                piv.keyframe_insert("rotation_euler", frame=frame)
            tr = piv.animation_data.nla_tracks.new(); tr.name = clip
            tr.strips.new(clip, 1, act)
            tr.mute = True      # 静音也照样导出成动画片段；不静音的话导出的静止姿态会被片段覆盖
        piv.animation_data.action = None
    set_angle(rest_deg)
    return piv


def add_collider(name, objs, mode="hull"):
    """碰撞体：用几个物体的点算凸包（或包围盒），名字以 COL_ 开头，游戏里隐藏。"""
    pts = []
    for o in objs:
        pts += [o.matrix_world @ v.co for v in o.data.vertices]
    bm = bmesh.new()
    if mode == "box":
        P = np.array(pts); lo, hi = P.min(0), P.max(0)
        bmesh.ops.create_cube(bm, size=1.0)
        bmesh.ops.scale(bm, vec=Vector(hi - lo), verts=bm.verts)
        bmesh.ops.translate(bm, vec=Vector((lo + hi) / 2), verts=bm.verts)
    else:
        idx = np.random.default_rng(0).choice(len(pts), min(len(pts), 6000), replace=False)
        for i in idx:
            bm.verts.new(pts[i])
        bmesh.ops.convex_hull(bm, input=bm.verts)
        bmesh.ops.delete(bm, geom=[v for v in bm.verts if not v.link_faces], context="VERTS")
        bmesh.ops.dissolve_limit(bm, angle_limit=math.radians(8), verts=bm.verts, edges=bm.edges)
    ob = _obj_from_bm(bm, name)
    ob["collider"] = True
    ob.display_type = "WIRE"
    ob.hide_render = True
    # Viewport wire display is not a glTF visibility flag. An alpha-zero
    # material keeps collision geometry/extras available without covering the
    # asset in generic glTF viewers. Engines should still disable its draw call.
    invisible = bpy.data.materials.new(name + "_invisible")
    invisible.use_nodes = True
    invisible.node_tree.nodes["Principled BSDF"].inputs["Alpha"].default_value = 0
    invisible.diffuse_color = (1, 1, 1, 0)
    ob.data.materials.append(invisible)
    return ob


# ---------------------------------------------------------------- 减面 + 烘法线
def decimate_bake(high, target_tris, size=2048, cage=0.05, rough=None):
    """减面并转移底色、法线、金属度、粗糙度；必要时保留透明与发光。

    默认保留原材质；rough 仅在用户明确要求覆盖粗糙度时传数值。
    原模型及其材质保留，返回低模；导出前由调用方移除高模。
    """
    from pbr_bake import decimate_bake_pbr
    return decimate_bake_pbr(high, target_tris, size=size, cage=cage, rough=rough)


# ---------------------------------------------------------------- 导出
def export_glb(path, scene_extras=None, jpeg_quality=None):
    """导出 GLB：带自定义属性（功能说明）、动画（每段 NLA 一个片段）。
    jpeg_quality 只设置 JPEG 质量；数据贴图保留 PNG，不将法线和金属粗糙度转为有损格式。"""
    if scene_extras:
        for k, v in scene_extras.items():
            bpy.context.scene[k] = v
    kw = dict(filepath=path, export_format="GLB", export_extras=True, export_apply=True,
              export_animations=True, export_animation_mode="NLA_TRACKS", export_yup=True)
    if jpeg_quality:
        kw.update(export_image_format="AUTO", export_image_quality=jpeg_quality)
    bpy.ops.export_scene.gltf(**kw)
    return path


# ---------------------------------------------------------------- 船长帽一趟里沉淀下来的通用小手术工具
def face_components(ob, fmask=None):
    """面的连通块号（经由共用的边）。fmask 给了就只在选中的面里找，没选中的是 -1。"""
    bm = bmesh.new()
    bm.from_mesh(ob.data)
    bm.faces.ensure_lookup_table()
    n = len(bm.faces)
    ok = np.ones(n, bool) if fmask is None else np.asarray(fmask, bool)
    lab = np.full(n, -1)
    cur = 0
    for f in bm.faces:
        if not ok[f.index] or lab[f.index] >= 0:
            continue
        stack = [f]
        lab[f.index] = cur
        while stack:
            g = stack.pop()
            for e in g.edges:
                for h in e.link_faces:
                    if ok[h.index] and lab[h.index] < 0:
                        lab[h.index] = cur
                        stack.append(h)
        cur += 1
    bm.free()
    return lab


def remove_small_islands(ob, max_faces):
    """删掉面数少于 max_faces 的独立小块（漂浮碎片）。返回 (删掉的面数, 块数)。
    先要合并重复点（remove_doubles），否则按 UV 拆开的网格会被当成一堆碎片。"""
    lab = face_components(ob)
    cnt = np.bincount(lab)
    small = cnt[lab] < max_faces
    delete_faces(ob, small)
    return int(small.sum()), int((cnt < max_faces).sum())


def uv_from_neighbors(ob):
    """新加的面（比如补洞）没有像样的 UV：每个点取离它最近的原有点的 UV。返回补了几个面。"""
    from mathutils.kdtree import KDTree
    me = ob.data
    uv = me.uv_layers.active.data
    bad = [p for p in me.polygons if len({tuple(uv[li].uv) for li in p.loop_indices}) == 1]
    if not bad:
        return 0
    bad_idx = {p.index for p in bad}
    good = [li for p in me.polygons if p.index not in bad_idx for li in p.loop_indices]
    kd = KDTree(len(good))
    for i, li in enumerate(good):
        kd.insert(me.vertices[me.loops[li].vertex_index].co, i)
    kd.balance()
    for p in bad:
        for li in p.loop_indices:
            _, i, _ = kd.find(me.vertices[me.loops[li].vertex_index].co)
            uv[li].uv = uv[good[i]].uv
    return len(bad)


def uv_mask(ob, fmask, size, grow=2):
    """选中的面在贴图（size×size）上占的像素（逐个三角形光栅化），外扩 grow px 盖住接缝边。"""
    me = ob.data
    uv = me.uv_layers.active.data
    mask = np.zeros((size, size), bool)
    me.calc_loop_triangles()
    for t in me.loop_triangles:
        if not fmask[t.polygon_index]:
            continue
        p = np.array([uv[l].uv for l in t.loops]) * size
        x0, y0 = np.floor(p.min(0)).astype(int) - 1
        x1, y1 = np.ceil(p.max(0)).astype(int) + 1
        x0, y0, x1, y1 = max(x0, 0), max(y0, 0), min(x1, size - 1), min(y1, size - 1)
        if x1 < x0 or y1 < y0:
            continue
        xs, ys = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
        a, b, c = p

        def edge(p0, p1):
            return (p1[0] - p0[0]) * (ys - p0[1]) - (p1[1] - p0[1]) * (xs - p0[0])
        e0, e1, e2 = edge(a, b), edge(b, c), edge(c, a)
        inside = ((e0 >= -1) & (e1 >= -1) & (e2 >= -1)) | ((e0 <= 1) & (e1 <= 1) & (e2 <= 1))
        mask[y0:y1 + 1, x0:x1 + 1] |= inside
    for _ in range(grow):
        m2 = mask.copy()
        m2[1:] |= mask[:-1]
        m2[:-1] |= mask[1:]
        m2[:, 1:] |= mask[:, :-1]
        m2[:, :-1] |= mask[:, 1:]
        mask = m2
    return mask


def recolor_masked(image, mask, src_rgb, dst_rgb, radius=30.0, feather=10.0):
    """只在 mask 里挪色：Lab 空间整体平移 (dst - src)，离 src 越近挪得越多、radius+feather 外不动。返回实际挪了的像素数。
    比 recolor_texture 稳：颜色半径只管“同一区域里的深浅变化”，区域本身由面（uv_mask）划定，
    所以不会把相近的别的颜色（深色在 Lab 里挤得很近）一起带偏。"""
    arr = _image_array(image)
    px = arr[mask][:, :3] * 255
    lab = _srgb_to_lab(px)
    s, t = _srgb_to_lab(np.array(src_rgb, float)), _srgb_to_lab(np.array(dst_rgb, float))
    w = np.clip((radius + feather - np.linalg.norm(lab - s, axis=1)) / feather, 0, 1)[:, None]
    new = _lab_to_srgb(lab + w * (t - s)) / 255
    sub = arr[mask]
    sub[:, :3] = new
    arr[mask] = sub
    image.pixels.foreach_set(arr.ravel())
    image.update()
    image.pack()
    return int((w[:, 0] > 0).sum())


def decimate_keep_uv(ob, target_tris, weld=1e-4):
    """减面烘焙的回退：不烘焙，在原件副本上直接减面，保留原 UV 和原贴图。返回低模，原件不动。
    先把非流形边劈开（否则减面卡死、形状碎掉）。代价：没有法线贴图来补细节，面数低时棱角分明（船长帽 1.9 万面实测）。"""
    low = ob.copy()
    low.data = ob.data.copy()
    low.name = ob.name + "_low"
    bpy.context.collection.objects.link(low)
    bm = bmesh.new()
    bm.from_mesh(low.data)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=weld)
    bad = [e for e in bm.edges if len(e.link_faces) > 2]
    if bad:
        bmesh.ops.split_edges(bm, edges=bad)
    low["split_nonmanifold_edges"] = len(bad)
    bm.to_mesh(low.data)
    bm.free()
    tris = sum(len(p.vertices) - 2 for p in low.data.polygons)
    mod = low.modifiers.new("dec", "DECIMATE")
    mod.ratio = min(1.0, target_tris / max(tris, 1))
    mod.use_collapse_triangulate = True
    bpy.ops.object.select_all(action="DESELECT")
    low.select_set(True)
    bpy.context.view_layer.objects.active = low
    bpy.ops.object.modifier_apply(modifier=mod.name)
    low.data.validate(clean_customdata=False)
    bm = bmesh.new()
    bm.from_mesh(low.data)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(low.data)
    bm.free()
    for p in low.data.polygons:
        p.use_smooth = True
    return low
