"""烤炉精修 v2：只在 Lux3D 原版上做小手术（不新建部件）。

blender -b --factory-startup -P oven_v2.py -- surgery   原件：定尺寸、切出炉门、去炉膛碎石和碎片、补洞、小幅调色 → out/oven_surgery.blend
blender -b --factory-startup -P oven_v2.py -- export    减面烘焙、装功能（转轴 / 动画 / 位置点 / 碰撞体）、导出 GLB

做了什么、没做什么，见同目录 精修记录.md。
"""
import argparse
import json
import math
import sys
from pathlib import Path

parser = argparse.ArgumentParser(description="烤炉定位示例；其他模型需要重写选区和转轴，不可直接套用")
parser.add_argument("stage", choices=("surgery", "export"))
parser.add_argument("workdir", type=Path)
parser.add_argument("--skill", type=Path, default=Path(__file__).resolve().parents[1])
options = parser.parse_args(sys.argv[sys.argv.index("--") + 1:])
skill_path = options.skill.resolve()
sys.path.insert(0, str(skill_path / "scripts"))
from refine_lib import *  # noqa: E402,F401
from common import load_asset
import bmesh  # noqa: E402
import bpy  # noqa: E402
import numpy as np  # noqa: E402
from mathutils import Vector  # noqa: E402

HERE = options.workdir.resolve()
ASSET = load_asset(HERE)
SRC = ASSET["generated"]
STAGE = options.stage
OUT = HERE / "out"; OUT.mkdir(exist_ok=True)

# 从 inspect_door.py 量的（按 2.0 m 总高）
HINGE = (-0.413, -0.677)          # 炉门合页轴（左边那根铜柱）
DOOR_OPEN_DEG = 22.0              # 原版炉门的开度
DOOR_X = (-0.47, 0.17)            # 炉门在 x 方向的范围（含插销把手）
DOOR_Z = (0.57, 1.10)


CHIM = (-0.462, 0.458)            # 烟囱轴


def portal(x, y, z, R=0.66):
    """砖拱门脸（正面拱形那一圈）：抹坑、涂色都不碰这里。"""
    return (y < -0.42) & (((z < 0.72) & (np.abs(x) < R)) | (np.hypot(x, z - 0.72) < R))


def door_back_y(x):
    """原版炉门背面所在的竖直平面：过合页轴、和正面成 DOOR_OPEN_DEG。"""
    return HINGE[1] - math.tan(math.radians(DOOR_OPEN_DEG)) * (x - HINGE[0])


def components(ob, mask):
    """在 mask 选中的面里找相连的块，返回每个面的块号（没选中的是 -1）。"""
    bm = bmesh.new(); bm.from_mesh(ob.data); bm.faces.ensure_lookup_table()
    lab = np.full(len(bm.faces), -1); cur = 0
    for f in bm.faces:
        if not mask[f.index] or lab[f.index] >= 0:
            continue
        st = [f]; lab[f.index] = cur
        while st:
            g = st.pop()
            for e in g.edges:
                for h in e.link_faces:
                    if mask[h.index] and lab[h.index] < 0:
                        lab[h.index] = cur; st.append(h)
        cur += 1
    bm.free()
    return lab


def stage_surgery():
    reset_scene()
    ob = import_lux3d(SRC)
    ob.name = "oven"
    s = normalize(ob, ASSET["height_m"])
    print("scale", s)
    bm = bmesh.new(); bm.from_mesh(ob.data)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-3)   # 导入时按 UV 拆开的点合回来（UV 不变），补洞要用
    bm.to_mesh(ob.data); bm.free()

    fs = face_samples(ob)
    c, rgb, metal = fs["center"], fs["rgb"], fs["metal"]
    hsv = rgb_to_hsv(rgb)
    x, y, z = c.T

    # 1) 切出炉门：炉门所在那片薄板（背面平面往前 0–11 cm）里的铁色 / 金属面 + 左边合页铜柱
    d = door_back_y(x) - y                                   # 在背面平面前面多远
    iron = (hsv[:, 2] < 0.45) | (metal > 0.4)
    door = (x > DOOR_X[0]) & (x < DOOR_X[1]) & (z > DOOR_Z[0]) & (z < DOOR_Z[1]) & (d > -0.012) & (d < 0.11) & iron
    hinge_pin = (metal > 0.4) & (np.hypot(x - HINGE[0], y - HINGE[1]) < 0.06) & (z > 0.58) & (z < 0.92)
    door |= hinge_pin
    lab = components(ob, door)                               # 只留最大的几块，零星误选的面不要
    cnt = np.bincount(lab[lab >= 0])
    keep = np.isin(lab, np.nonzero(cnt >= 40)[0])
    door = door & keep
    print("door faces", door.sum(), "blocks", (cnt >= 40).sum())
    leaf = split_faces(ob, door, "door_leaf")

    # 2) 炉膛里那堆灰白碎石（参考图是一小堆炭）：去掉；碎石下面就是原来的炉膛底
    fs = face_samples(ob)
    c, rgb = fs["center"], fs["rgb"]; hsv = rgb_to_hsv(rgb); x, y, z = c.T
    # 只删“整块是灰白色的独立小碎块”（碎石是一颗颗分开的），炉膛底和墙不动
    gray = (hsv[:, 1] < 0.16) & (hsv[:, 2] > 0.33)
    lab = components(ob, np.ones(len(c), bool))
    nb = lab.max() + 1
    size = np.bincount(lab, minlength=nb)
    gshare = np.bincount(lab, weights=gray.astype(float), minlength=nb) / np.maximum(size, 1)
    cz = np.bincount(lab, weights=z, minlength=nb) / np.maximum(size, 1)
    cx = np.bincount(lab, weights=x, minlength=nb) / np.maximum(size, 1)
    cy = np.bincount(lab, weights=y, minlength=nb) / np.maximum(size, 1)
    isl = (size <= 3000) & (gshare > 0.6) & (cz < 0.80) & (np.abs(cx) < 0.5) & (cy > -0.65) & (cy < 0.30)
    rubble = isl[lab]
    delete_faces(ob, rubble)
    print("rubble faces", int(rubble.sum()), "pieces", int(isl.sum()))

    # 3) 漂浮的小碎片
    remove_islands(ob, 30)
    remove_islands(leaf, 30)

    # 4) 补洞（圆顶上原来就有的穿透小洞、切门留下的小缝）；门洞、炉口这些大开口不补
    def skip(cpt, size):
        return size > 0.30 or cpt.z < 0.05
    for o in (ob, leaf):
        n = fill_small_holes(o, 0.30, skip=skip, smooth_iters=15)
        uv_from_neighbors(o)
        print(o.name, "holes filled", n)

    # 5) 圆顶上的小坑：只把从外面看得见、凹进去 7 cm 以内的点（外壳厚 4–6 cm，坑底就是内层）推平到圆顶外壳上（砖拱门脸、烟囱不动）
    V = np.zeros(len(ob.data.vertices) * 3); ob.data.vertices.foreach_get("co", V); V = V.reshape(-1, 3)
    vx, vy, vz = V.T
    vzone = (vz > 0.62) & ~portal(vx, vy, vz) & ~((np.hypot(vx - CHIM[0], vy - CHIM[1]) < 0.32) & (vz > 1.1)) \
        & ~((vy < -0.3) & (np.abs(vx) < 0.55) & (vz < 1.2))          # 炉口里面（炉膛内壁）不动
    before = V.copy()
    print("pit verts closed", close_recesses(ob, (0, 0.02, 0.62), vzone, max_depth=0.07))
    V2 = np.zeros(len(V) * 3); ob.data.vertices.foreach_get("co", V2); V2 = V2.reshape(-1, 3)
    moved = np.linalg.norm(V2 - before, axis=1) > 1e-4

    # 6) 贴图小修（只涂颜色，不动形状）：抹平的坑里原来的深褐色涂回灰泥；炉膛里那堆灰白碎石涂成炭黑
    base, _ = material_images(ob)
    fs = face_samples(ob)
    c, rgb = fs["center"], fs["rgb"]; hsv = rgb_to_hsv(rgb); x, y, z = c.T
    fmoved = np.array([moved[list(p.vertices)].any() for p in ob.data.polygons])
    pit_dark = fmoved & (hsv[:, 2] < 0.45)
    paint_uv_tris(ob, base, grow_mask(ob, pit_dark, 1) & ~portal(x, y, z), (203, 162, 111), noise=5)
    coal = (hsv[:, 1] < 0.16) & (hsv[:, 2] > 0.30) & (z < 0.80) & (np.abs(x) < 0.5) & (y > -0.65) & (y < 0.30)
    paint_uv_tris(ob, base, coal, (60, 56, 54), noise=12, seed=3)
    print("painted pits", int(pit_dark.sum()), "coal", int(coal.sum()))

    # 7) 小幅调色：只把颜色往参考图挪一小步（色相 / 彩度挪 40%，亮度略提），保住原来的暖色
    ref_plaster, orig_plaster = (236, 205, 178), (203, 162, 111)
    ref_brick, orig_brick = (214, 113, 70), (154, 94, 49)
    # Brick regions share several reference shades: keep the adjustment smaller
    # than the plaster step, then validate all palette clusters, including darks.
    rules = [(orig_plaster, partial_toward(orig_plaster, ref_plaster, 0.4, dL=4), 16),
             (orig_brick, partial_toward(orig_brick, ref_brick, 0.15, dL=0), 12),
             ((46, 37, 34), partial_toward((46, 37, 34), (68, 42, 31), 0.25, dL=1.5), 6)]
    print("recolor", rules)
    recolor_texture(base, rules, feather=8)
    leaf.data.materials.clear(); leaf.data.materials.append(ob.data.materials[0])   # 同一张贴图
    bpy.ops.wm.save_as_mainfile(filepath=str(OUT / "oven_surgery.blend"))


def remove_islands(ob, max_faces):
    lab = components(ob, np.ones(len(ob.data.polygons), bool))
    cnt = np.bincount(lab)
    small = cnt[lab] <= max_faces
    delete_faces(ob, small)
    print(ob.name, "small islands removed faces", int(small.sum()))


def uv_from_neighbors(ob):
    """补洞新加的面没有像样的 UV：每个点用离它最近的原有点的 UV（补丁处取周围的颜色）。"""
    me = ob.data
    uv = me.uv_layers.active.data
    bad = [p for p in me.polygons if all(abs(uv[li].uv[0]) < 1e-9 and abs(uv[li].uv[1]) < 1e-9 for li in p.loop_indices)
           or len({tuple(uv[li].uv) for li in p.loop_indices}) == 1]
    if not bad:
        return
    from mathutils.kdtree import KDTree
    good_loops = [li for p in me.polygons if p not in bad for li in p.loop_indices]
    kd = KDTree(len(good_loops))
    for i, li in enumerate(good_loops):
        kd.insert(me.vertices[me.loops[li].vertex_index].co, i)
    kd.balance()
    for p in bad:
        for li in p.loop_indices:
            _, i, _ = kd.find(me.vertices[me.loops[li].vertex_index].co)
            uv[li].uv = uv[good_loops[i]].uv


def partial_toward(src, ref, t, dL=0.0):
    """Lab 空间里把 src 往 ref 挪 t（只挪色相 / 彩度，亮度另加 dL），返回 sRGB 0–255。"""
    from refine_lib import _srgb_to_lab, _lab_to_srgb
    a, b = _srgb_to_lab(np.array(src, float)), _srgb_to_lab(np.array(ref, float))
    out = a.copy()
    out[1:] = a[1:] + t * (b[1:] - a[1:])
    out[0] = a[0] + dL
    return tuple(int(round(v)) for v in _lab_to_srgb(out))


# ======================================================================= export
def stage_export():
    bpy.ops.wm.open_mainfile(filepath=str(OUT / "oven_surgery.blend"))
    ob, leaf = bpy.data.objects["oven"], bpy.data.objects["door_leaf"]
    # This repaired shell needs the wider cage: shorter rays miss moved surfaces.
    body = decimate_bake(ob, ASSET.get("body_tris", 40000), size=2048, cage=0.05)
    door = decimate_bake(leaf, ASSET.get("door_tris", 6000), size=1024, cage=0.015)
    bpy.data.objects.remove(ob); bpy.data.objects.remove(leaf)
    body.name = body.data.name = "oven_body"; door.name = door.data.name = "door_leaf"
    for o in (body, door):
        o["lux3d_origin"] = True                             # 原件（验收算“改动量”用）
    fn = next(f for f in ASSET["functions"] if f["id"] == "door")
    piv = hinge(door, (HINGE[0], HINGE[1], 0.0), "Z", rest_deg=DOOR_OPEN_DEG, min_deg=fn["min_deg"],
                max_deg=fn["max_deg"], name="door", sign=-1, part_is_at_rest=True)
    piv["function"] = "door"
    # 位置点（量原版：炉膛底 z≈0.58，烟囱顶中心，储物口）
    v = np.array([p.co for p in body.data.vertices])
    top = v[v[:, 2] > 1.9]
    add_socket("socket_fire", (0.0, -0.15, 0.62), extras={"function": "fire"})
    add_socket("socket_bake", (0.0, -0.30, 0.60), extras={"function": "bake"})
    add_socket("socket_smoke", (float(top[:, 0].mean()), float(top[:, 1].mean()), float(v[:, 2].max()) + 0.02),
               extras={"function": "smoke"})
    add_socket("socket_store", (0.0, -0.45, 0.07), extras={"function": "store"})
    add_socket("interact_point", (0.0, -1.55, 0.0), extras={"function": "interact"})
    add_collider("COL_body", [body], mode="hull")
    scene_extras = {"asset_id": ASSET["id"], "asset_name": ASSET["name"], "height_m": ASSET["height_m"],
                    "functions": json.dumps(ASSET["functions"], ensure_ascii=False)}
    bpy.context.scene.render.engine = "BLENDER_EEVEE"
    bpy.ops.wm.save_as_mainfile(filepath=str(OUT / "oven_v2_final.blend"))
    export_glb(str(OUT / "brick-oven-v2.glb"), scene_extras, jpeg_quality=90)
    print("EXPORTED")


{"surgery": stage_surgery, "export": stage_export}[STAGE]()
