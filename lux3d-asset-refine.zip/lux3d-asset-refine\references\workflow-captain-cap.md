# 完整流程实例：船长帽（2026-11-04）

从一张四视图概念图，到 Lux3D 生成、精修、验收，**正确**的做法和每一步的实测数字。命令里 `<skill>` 是 skill 目录，`<dir>` 是素材工作目录（这件是 `outputs/lux3d-captain-cap-20261104/`）。
走弯路的部分在 `lessons.md`；这里只写“照着做会走通”的版本。

## 0. 准备输入（不花积分）

1. 概念图是一张 2×2 的四视图（左上正面、右上左侧、左下背面、右下右侧），**本来就带透明通道**。先确认：读 alpha，别以为是白底去抠。
2. 用 alpha 找连通块拆成四张，**同一个画布边长（700）、不缩放**，保持四张的相对大小；透明处的 RGB 清零（看透明图会显出藏在里面的颜色）。命名 `01_front.png`、`02_side_a.png`（左侧，画面右边是正面）、`03_back.png`、`04_side_b.png`（右侧，画面左边是正面）。
3. 写 `asset.json`（格式见 `asset-json.md`）：真实高度（按真实船长帽约 29 cm 宽估算 → 0.18 m）、四视图路径、关键部件清单、功能清单（船长帽没有会动的部件：戴头锚点、捡起点、碰撞体）、局部放大框、`color_regions`（调色取样区）。
4. `python <skill>/scripts/prep_check.py <dir>`：这件的结论是“可以生成”，三条提示不拦路（左右 3/4 视角宽高比差 5.6%、光影烤进了图、物体占比不一）。

## 1. 生成（花积分，要用户这一次的明确同意）

1. 先写**生成单**给用户看：几张图、G1 还是 G1-Turbo、面数、预计几次调用、预计积分（这里查不到报价接口，只能说“约 1 积分，依据是烤炉那次同参数的报价”，要写明是估计）。
2. 验 key：`node <skill>/scripts/lux3d.mjs check --env=<.env>`（不花积分）。**不加 `--confirm` 时试一次下单**，确认会被拦住。
3. 用户同意后：
   `node <skill>/scripts/lux3d.mjs img3d <dir> captain-cap <四张图> --turbo --faces=300000 --env=<.env> --confirm`
   54 秒出结果，1 次调用；29.4 万面，2 张 2048 PNG，没有法线贴图。结果下载到 `<dir>/gen/captain-cap.glb`，记录在 `lux3d-log.json`。

## 2. 体检原版（baseline）

```
python <skill>/scripts/audit.py <dir> <dir>/gen/captain-cap.glb v0 --baseline
```
读 `audit-v0/report.html` 和 `view_*.jpg`、`detail_*.jpg`，**看图**把 `verdicts.json` 里每个部件和“破损”填上，再 `--no-render` 重跑合进结论。再用一个 Blender 脚本量原版本身：
- 孤立块数和大小（这件：79 个 < 200 面的漂浮碎片）；
- 开口环大小（241 个，最大 7 mm，**1–2 条边的细缝，不是洞**）；
- **非流形边数**（3,551 条，后面减面的关键）；
- 按真实高度缩放后的包围盒、顶部小圆扣的位置、帽内顶高度（从底面中心往上打射线）。

## 3. 分诊（给用户看了再动手）

每一条都用数据核过再写：
- 小手术能修：缩放和原点、删碎片、**小步**调色、减面（先劈非流形边）、装位置点和碰撞体；
- 修不了：锚徽形状（弯月爪 vs 箭头爪）、对预览图的左侧 / 背面轮廓偏差、缝线和锈斑（属于纹理加强，不在清单里）；
- 先别动：开口环（细缝）、帽身颜色（量下来已经对上）。

## 4. 量颜色，不凭眼睛

```
python <skill>/scripts/calibrate_colors.py <dir>      # 写 colors.json
```
每个区域：预览图和原版打光渲染的中位色 → 想要的贴图色 → 按“每步最多 ΔE 10、色相 ≤ 10°”截断。这件的结果：皮革想要 ΔE 23，只挪 ΔE 10；黄铜想要 ΔE 23，只挪 ΔE 6.5（色相上限卡住）；**帽身 ΔE 2.4，标“不需要挪”**——差的是亮度和布纹对比，不是颜色。

## 5. 精修脚本（示例 `examples/cap_refine.py`）

```
blender -b --factory-startup -P <skill>/examples/cap_refine.py -- surgery <dir>
blender -b --factory-startup -P <skill>/examples/cap_refine.py -- export <dir> tag=v2 cage=0.0025 ratio=0.97 budget=20000
blender -b --factory-startup -P <skill>/examples/cap_refine.py -- rebake <dir> from=v2 tag=v8
```
- **surgery**：缩放到 0.18 m；`remove_doubles` 1e-4；`remove_small_islands(<200 面)`；皮革、黄铜按面区域调色（`uv_mask` + `recolor_masked`）。开口环只统计，不动。
- **export**：`decimate_bake`（内置劈开非流形边，29 万面 → 1.9 万面，新点离原版平均 0.42 mm）；装 `socket_wear`、`socket_pickup`、`COL_body`；每个网格标 `lux3d_origin=true`。笼子按 0.18 m 的尺度取 2.5–5 mm（烤炉的 5 cm 是 2 m 尺度，不能照搬）。
- **rebake（分开烘）**：这件帽檐上有一块斑（整体烘焙时射线打到了帽身的布）。低模不动，只对皮革区域重烘颜色：区域高模 = 皮革色面 ∪ 低处黄铜面，**并且 z < 0.075 m**；只换颜色，不换法线；低模面中心离区域高模 4 mm 内才换；新烘的颜色必须是暖色。

> 整体烘焙不出斑的素材，到 export 就够了，不需要 rebake。出斑才用。

## 6. 功能检查 + 验收

```
blender -b --factory-startup -P <skill>/scripts/function_check.py -- <新.glb> <dir>/asset.json <dir>/audit-v8/function-check.json
python <skill>/scripts/audit.py <dir> <新.glb> v8 --before=v0 --orig=v0
```
再看图，填 `verdicts.json`，`--no-render` 重跑。这件 v8 的结果：形状、改动量（外形偏差 ≤ 0.3%、表面 100% 贴着原版）、体量（19,363 面、8.3 MB）、功能全过；对预览图的左侧 / 背面轮廓偏差和锚徽形状**只记录**。颜色：旧的按颜色配对会把一行判成不过（配对错），改成按位置配对后，**不提亮帽身**也三行全过（和原版差 ΔE 0.9 / 0.8 / 10.4，离预览图都没变远）。**不要提亮帽身**：按第 4 步的结论它不需要挪。

## 7. 记录和交付

`精修记录.md`：做了什么、没做什么（为什么、下次生成怎么改输入）、版本表（每个版本的毛病）、需要用户决定的事。交付 `captain-cap-v8.glb` + 精修记录 + `audit-v8/report.html`。打开给用户看：Blender 里导入 GLB，隐藏 `COL_*`，切到材质预览。

## 用时

| 步骤 | 用时 |
|---|---|
| Lux3D 生成 | 54 秒 |
| 体检（4 方向 × 3 种渲染） | 约 1–2 分钟 |
| surgery | 约 1–2 分钟 |
| export（减面 + 烘 3 张 2048） | 约 5 分钟 |
| rebake | 约 5 分钟 |
| 功能检查 + 验收 | 约 2 分钟 |
