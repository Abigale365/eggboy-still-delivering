"""生成前检查参考图（不花积分）。

    python prep_check.py <工作目录> [--clean]

读 asset.json 里 reference 的四张图（front / left / back / right），检查：
  - 是不是透明背景；分辨率够不够；物体有没有被裁到边
  - 四张图之间是否一致：高度、前后宽度、左右宽度（差超过 3% 就提示）
  - 有没有零星杂点（主体以外的小色块）
  - 光影是不是烤得太重（物体左右两半亮度差很大）
--clean：把透明处的 RGB 清零、去掉杂点，存到 <工作目录>/inputs/cleaned/，生成时用这一套。
结果写到 <工作目录>/prep-check.json。
"""
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

sys.path.insert(0, str(Path(__file__).parent))
from common import load_asset  # noqa: E402


def components(mask):
    """简单的 4 邻接连通块，返回 (标签图, 每块大小)。"""
    h, w = mask.shape
    lab = np.zeros((h, w), np.int32)
    sizes = [0]
    cur = 0
    for y0, x0 in zip(*np.nonzero(mask)):
        if lab[y0, x0]:
            continue
        cur += 1
        stack = [(y0, x0)]
        lab[y0, x0] = cur
        n = 0
        while stack:
            y, x = stack.pop()
            n += 1
            for yy, xx in ((y + 1, x), (y - 1, x), (y, x + 1), (y, x - 1)):
                if 0 <= yy < h and 0 <= xx < w and mask[yy, xx] and not lab[yy, xx]:
                    lab[yy, xx] = cur
                    stack.append((yy, xx))
        sizes.append(n)
    return lab, sizes


def analyse(path):
    im = Image.open(path)
    res = {"file": path, "size": im.size, "warnings": []}
    rgba = np.array(im.convert("RGBA"))
    a = rgba[:, :, 3]
    if (a < 250).mean() < 0.01:
        res["warnings"].append("没有透明背景：先抠图，背景会被当成物体的一部分")
        corner = rgba[:8, :8, :3].reshape(-1, 3).mean(0)
        mask = np.abs(rgba[:, :, :3].astype(int) - corner).sum(2) > 40
    else:
        mask = a > 20
    if not mask.any():
        res.update({"bbox": None, "obj_w": 0, "obj_h": 0, "light_lr": None,
                    "_mask": mask, "_lab": (np.zeros(mask.shape, np.int32), 0)})
        res["warnings"].append("图片没有有效主体（全透明或空白），不能用于生成")
        return res
    if min(im.size) < 512:
        res["warnings"].append(f"分辨率偏低 {im.size}，建议 ≥1024")
    small = np.array(Image.fromarray(mask.astype(np.uint8) * 255).resize((256, round(256 * mask.shape[0] / mask.shape[1])), Image.NEAREST)) > 127
    lab, sizes = components(small)
    main = int(np.argmax(sizes))
    specks = [s for i, s in enumerate(sizes) if i and i != main and s >= 2]
    if specks:
        res["warnings"].append(f"主体外有 {len(specks)} 个杂点块（--clean 会去掉）")
    ys, xs = np.nonzero(mask)
    h, w = mask.shape
    box = [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]
    res["bbox"] = box
    res["obj_w"], res["obj_h"] = (box[2] - box[0] + 1) / w, (box[3] - box[1] + 1) / h
    margin = min(box[0], box[1], w - 1 - box[2], h - 1 - box[3])
    if margin <= 1:
        res["warnings"].append("物体碰到画面边缘，可能被裁掉了")
    semi = ((a > 20) & (a < 235)).sum() / max(mask.sum(), 1)
    if semi > 0.08:
        res["warnings"].append(f"半透明边缘偏多（{semi:.0%}），抠图边可能有光晕")
    lum = rgba[:, :, :3].astype(float) @ [0.299, 0.587, 0.114]
    cx = (box[0] + box[2]) // 2
    # 用每半边较亮的那部分像素（75 分位）比，避免深色部件（门、窗）本身把一边拉暗
    lp, rp = lum[:, :cx][mask[:, :cx]], lum[:, cx:][mask[:, cx:]]
    left, right = (np.percentile(p, 75) if len(p) else 0 for p in (lp, rp))
    res["light_lr"] = round(float((left + 1e-6) / (right + 1e-6)), 3)
    if not 0.8 < res["light_lr"] < 1.25:
        res["warnings"].append(f"左右两半亮度差很大（{res['light_lr']}），可能把光影烤进了图")
    res["_mask"] = mask
    res["_lab"] = (lab, main)
    return res


def main():
    workdir = sys.argv[1]
    clean = "--clean" in sys.argv
    asset = load_asset(workdir)
    refs = asset["reference"]
    out = {"views": {}, "consistency": [], "ok": True}
    data = {}
    for v in ("front", "left", "back", "right"):
        if v not in refs:
            out["consistency"].append(f"缺 {v} 视图")
            out["ok"] = False
            continue
        try:
            data[v] = analyse(refs[v])
        except (OSError, ValueError) as exc:
            out["ok"] = False
            out["views"][v] = {"file": refs[v], "warnings": [f"图片不能读取：{exc}"]}
    # 一致性：四张图的物体高度（相对画面）、前后宽度、左右宽度；按“宽/高”比较，不受画面大小影响
    asp = {v: d["obj_w"] * d["size"][0] / (d["obj_h"] * d["size"][1])
           for v, d in data.items() if d["obj_h"] > 0}
    for a, b in (("front", "back"), ("left", "right")):
        if a in asp and b in asp:
            diff = abs(asp[a] - asp[b]) / max(asp[a], asp[b])
            out["consistency"].append(f"{a}/{b} 宽高比 {asp[a]:.3f} / {asp[b]:.3f}，差 {diff:.1%}" + ("  ← 超过 3%" if diff > 0.03 else ""))
            if diff > 0.03:
                out["ok"] = False
    hs = [d["obj_h"] for d in data.values()]
    if hs and max(hs) > 0 and (max(hs) - min(hs)) / max(hs) > 0.03:
        out["consistency"].append(f"四张图里物体占画面高度不一致：{[round(x, 3) for x in hs]}（生成时会按同一比例理解）")
        out["ok"] = False
    for v, d in data.items():
        if d["warnings"]:
            out["ok"] = False
        out["views"][v] = {k: d[k] for k in ("file", "size", "bbox", "light_lr", "warnings")}
        if clean and d["bbox"] is not None:
            im = np.array(Image.open(d["file"]).convert("RGBA"))
            lab, main = d["_lab"]
            keep = np.array(Image.fromarray((lab == main).astype(np.uint8) * 255).resize(im.shape[1::-1], Image.NEAREST)) > 0
            keep = np.array(Image.fromarray(keep.astype(np.uint8) * 255).filter(ImageFilter.MaxFilter(9))) > 0
            im[~keep, 3] = 0
            im[im[:, :, 3] == 0, :3] = 0
            dst = Path(workdir) / "inputs" / "cleaned" / (v + ".png")
            dst.parent.mkdir(parents=True, exist_ok=True)
            Image.fromarray(im).save(dst)
            out["views"][v]["cleaned"] = str(dst)
    Path(workdir, "prep-check.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    for line in out["consistency"]:
        print(line)
    for v, d in out["views"].items():
        print(v, d.get("size", "无法读取"), "；".join(d["warnings"]) or "没问题")
    print("结论：", "可以生成" if out["ok"] else "有问题，先看上面的提示")


if __name__ == "__main__":
    main()
