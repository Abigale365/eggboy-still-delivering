"""系统 Python 这一侧的公用小工具：找 Blender、读 asset.json、跑 Blender 脚本。"""
import json
import hashlib
import os
import shutil
import subprocess
import sys
import struct
from pathlib import Path

SKILL = Path(__file__).resolve().parent.parent
SCRIPTS = SKILL / "scripts"

BLENDER_CANDIDATES = [
    r"G:\1 business\the second brain\项目工作区\2026.09.05 AI赛事\.tools\blender-4.5.0-windows-x64\blender.exe",
    r"D:\Program Files (x86)\Steam\steamapps\common\Blender\blender.exe",
    r"C:\Program Files\Blender Foundation\Blender 5.2\blender.exe",
    r"C:\Program Files\Blender Foundation\Blender 4.5\blender.exe",
    "/Applications/Blender.app/Contents/MacOS/Blender",
]

# 四个标准视角：相机所在方向（物体坐标，Z 朝上，正面朝 -Y）
VIEWS = {"front": (0, -1), "left": (-1, 0), "back": (0, 1), "right": (1, 0)}


def find_blender():
    env = os.environ.get("BLENDER_EXE")
    if env and Path(env).exists():
        return env
    for c in BLENDER_CANDIDATES:
        if Path(c).exists():
            return c
    w = shutil.which("blender")
    if w:
        return w
    sys.exit("找不到 Blender：请设置环境变量 BLENDER_EXE")


def run_blender(script, *args, blend=None, quiet=True):
    cmd = [find_blender(), "-b"]
    if blend:
        cmd.append(str(blend))
    else:
        cmd.append("--factory-startup")
    cmd += ["--python-exit-code", "1", "-P", str(script), "--", *map(str, args)]
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", env=env)
    out = p.stdout + p.stderr
    if p.returncode != 0 or "Traceback" in out:
        print(out[-4000:])
        sys.exit(f"Blender 脚本出错：{Path(script).name}")
    if not quiet:
        print(out)
    return out


def load_asset(workdir):
    workdir = Path(workdir).resolve()
    f = workdir / "asset.json"
    if not f.exists():
        sys.exit(f"{f} 不存在：先按 references/asset-json.md 写好")
    a = json.loads(f.read_text(encoding="utf-8-sig"))
    if not isinstance(a, dict) or not isinstance(a.get("reference", {}), dict):
        raise ValueError("asset.json 必须是对象，reference 必须是视图到图片路径的对象")
    a["_dir"] = str(workdir)
    for k, v in a.get("reference", {}).items():
        if not isinstance(v, str) or not v.strip():
            raise ValueError(f"reference.{k} 必须是非空图片路径")
        p = Path(v)
        a["reference"][k] = str(p if p.is_absolute() else workdir / p)
    if a.get("generated"):
        p = Path(a["generated"])
        a["generated"] = str((p if p.is_absolute() else workdir / p).resolve())
    functions = a.get("functions", [])
    if not isinstance(functions, list):
        raise ValueError("functions 必须是列表")
    seen = set()
    for fn in functions:
        if not isinstance(fn, dict) or not isinstance(fn.get("id"), str) or not fn["id"]:
            raise ValueError("每个功能都要有非空 id")
        if fn["id"] in seen:
            raise ValueError(f"功能 id 重复：{fn['id']}")
        seen.add(fn["id"])
        if fn.get("type") not in FUNCTION_KINDS:
            raise ValueError(f"不支持的功能类型：{fn.get('type')}")
    return a


def budget_for(asset):
    b = {"large": 50000, "small": 10000}
    return asset.get("tri_budget") or b.get(asset.get("category", "large"), 50000)


FUNCTION_KINDS = {"hinge": ("node", "hinge", "animation", "collision"),
                  "socket": ("node", "socket"), "emissive": ("node", "emissive"),
                  "collider": ("node", "collider")}


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def scripts_signature(*names):
    h = hashlib.sha256()
    for name in names:
        h.update(name.encode("utf-8"))
        h.update((SCRIPTS / name).read_bytes())
    return h.hexdigest()


def function_inputs(glb, asset_path):
    return {"glb_sha256": sha256_file(glb), "asset_sha256": sha256_file(asset_path),
            "checker_sha256": scripts_signature("function_check.py", "bl_common.py", "common.py")}


def render_inputs(glb, elevation, resolution, yaw):
    return {"glb_sha256": sha256_file(glb), "elevation_deg": round(float(elevation), 8),
            "resolution": int(resolution), "yaw_fix_deg": round(float(yaw), 8),
            "renderer_sha256": scripts_signature("render_views.py", "bl_common.py", "common.py")}


def read_glb_chunks(path):
    data = Path(path).read_bytes()
    if len(data) < 20:
        raise ValueError("GLB 文件太短")
    magic, version, length = struct.unpack_from("<4sII", data)
    if magic != b"glTF" or version != 2 or length != len(data):
        raise ValueError("不是有效的 glTF 2.0 GLB，或文件不完整")
    document, binary, offset = None, b"", 12
    while offset + 8 <= len(data):
        size, kind = struct.unpack_from("<I4s", data, offset)
        offset += 8
        if offset + size > len(data):
            raise ValueError("GLB 数据块不完整")
        chunk = data[offset:offset + size]
        if kind == b"JSON":
            document = json.loads(chunk.decode("utf-8").rstrip(" \0"))
        elif kind == b"BIN\0":
            binary = chunk
        offset += size
    if document is None:
        raise ValueError("GLB 缺少 JSON 数据块")
    return document, binary


def read_accessor(document, binary, index):
    accessor = document["accessors"][index]
    if "sparse" in accessor or "bufferView" not in accessor:
        raise ValueError("此检查不支持稀疏或无 bufferView 的动画 accessor")
    view = document["bufferViews"][accessor["bufferView"]]
    if view.get("buffer", 0) != 0:
        raise ValueError("检查需要内嵌的 GLB buffer")
    types = {5120: "b", 5121: "B", 5122: "h", 5123: "H", 5125: "I", 5126: "f"}
    counts = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}
    fmt = "<" + types[accessor["componentType"]] * counts[accessor["type"]]
    size = struct.calcsize(fmt)
    stride = view.get("byteStride", size)
    start = view.get("byteOffset", 0) + accessor.get("byteOffset", 0)
    return [struct.unpack_from(fmt, binary, start + i * stride) for i in range(accessor["count"])]
