"""分开烘：低模不动，只对某个区域重烘底色（可选法线），这一遍的高模只用这个区域的面。

解决什么：薄壳处（帽檐和帽身重叠、袖口和衣身重叠）整体烘焙时，射线会打到旁边那一层，把别处的颜色烘上来，
出现一块灰白斑 / 黑灰斑。调笼子、放宽面数、不烘焙都不能彻底解决（船长帽实测，见 references/lessons.md）。

做法（v8 验证过）：
  1. 从原版高模里只挑出区域的面（region_mask：按颜色 + **必须加位置范围**），复制成“区域高模”；
  2. 对低模烘三遍：命中图（纯白自发光，白 = 射线打到了区域高模）、底色、（可选）法线；
  3. 替换范围 = 命中 ∧ 低模面级限定（面中心离区域高模 face_dist 以内）∧ low_face_ok ∧ 颜色过滤（accept）；
  4. 只在替换范围里把新烘的颜色写进低模现有的贴图，其余原样保留。所以没有接缝。

踩过的坑（都写进了 references/lessons.md）：
  - 区域高模只按颜色挑，会把锚徽侧面、帽身上颜色相近的磨损斑也算进去（锚徽周围烘出光晕）→ 一定加位置范围；
  - 连法线一起换，交界处射线以很斜的角度打到，法线是乱的，渲染出亮斑 → 默认只换颜色；
  - 按像素命中替换，交界处会散落地换（布料下沿冒出橙棕方块）→ 一定要加面级限定。

只在 Blender 里用。用法见 examples/cap_refine.py 的 rebake 阶段。
"""
import bpy
import numpy as np

from refine_lib import _image_array, _srgb_to_lab, delete_faces, uv_mask


def _emit_material(src, mode):
    """高模的临时材质（只用于烘焙）：mode='color' 把底色接到自发光；mode='hit' 纯白自发光（量“射线有没有打到”）。"""
    if mode == "hit":
        m = bpy.data.materials.new("tmp_hit")
        m.use_nodes = True
        nt = m.node_tree
        for n in list(nt.nodes):
            nt.nodes.remove(n)
        em = nt.nodes.new("ShaderNodeEmission")
        em.inputs["Color"].default_value = (1, 1, 1, 1)
        out = nt.nodes.new("ShaderNodeOutputMaterial")
        nt.links.new(em.outputs[0], out.inputs["Surface"])
        return m
    m = src.copy()
    nt = m.node_tree
    p = next(n for n in nt.nodes if n.type == "BSDF_PRINCIPLED")
    out = next(n for n in nt.nodes if n.type == "OUTPUT_MATERIAL")
    em = nt.nodes.new("ShaderNodeEmission")
    bc = p.inputs["Base Color"]
    if bc.is_linked:
        nt.links.new(bc.links[0].from_socket, em.inputs["Color"])
    else:
        em.inputs["Color"].default_value = bc.default_value
    nt.links.new(em.outputs[0], out.inputs["Surface"])
    return m


def bake_pass(high, low, image, mode, cage, max_dist, margin=8):
    """把 high（只选了的这一部分高模）烘到 low 的 UV 上，写进 image。mode: color / hit / normal。"""
    scene = bpy.context.scene
    keep = (scene.render.engine, scene.cycles.samples, scene.cycles.device)
    bk = scene.render.bake
    saved = {k: getattr(bk, k) for k in ("use_selected_to_active", "cage_extrusion", "max_ray_distance", "margin",
                                          "use_pass_direct", "use_pass_indirect", "use_pass_color")}
    low_mats, high_mats = list(low.data.materials), list(high.data.materials)
    tmp = []
    try:
        lm = bpy.data.materials.new("tmp_low")
        lm.use_nodes = True
        tn = lm.node_tree.nodes.new("ShaderNodeTexImage")
        tn.image = image
        lm.node_tree.nodes.active = tn
        tmp.append(lm)
        low.data.materials.clear()
        low.data.materials.append(lm)
        if mode != "normal":
            high.data.materials.clear()
            if mode == "hit":
                hm = _emit_material(None, "hit")
                tmp.append(hm)
                high.data.materials.append(hm)
            else:
                for src in high_mats:
                    hm = _emit_material(src, "color")
                    tmp.append(hm)
                    high.data.materials.append(hm)
        scene.render.engine = "CYCLES"
        scene.cycles.samples = 1
        scene.cycles.device = "CPU"
        bk.use_selected_to_active = True
        bk.cage_extrusion = cage
        bk.max_ray_distance = max_dist
        bk.margin = margin
        bpy.ops.object.select_all(action="DESELECT")
        high.select_set(True)
        low.select_set(True)
        bpy.context.view_layer.objects.active = low
        if mode == "normal":
            bpy.ops.object.bake(type="NORMAL", normal_space="TANGENT")
        else:
            bpy.ops.object.bake(type="EMIT")
    finally:
        low.data.materials.clear()
        for m in low_mats:
            low.data.materials.append(m)
        high.data.materials.clear()
        for m in high_mats:
            high.data.materials.append(m)
        for m in tmp:
            bpy.data.materials.remove(m)
        scene.render.engine, scene.cycles.samples, scene.cycles.device = keep
        for k, v in saved.items():
            setattr(bk, k, v)
    return image


def rebake_region(low, high_all, region_mask, color_image, normal_image=None, cage=0.004, face_dist=0.004,
                  low_face_ok=None, accept=None, log=print):
    """对 low 的一个区域重烘贴图。返回 dict 统计。

    low            已经减好面、有 UV 和烘好贴图的低模
    high_all       原版高模（整件）；这个函数会复制一份只留区域的面，不改它
    region_mask    高模的面里哪些属于区域（bool 数组，长度 = 高模面数）；**要同时按颜色和位置挑**
    color_image    低模现有的底色贴图（会被改写、重新打包）
    normal_image   给了才会重烘法线；默认 None = 只换颜色（法线在交界处会烘乱）
    cage           烘焙笼子（米）；射线最远 cage × 3。薄壳的两层靠得近就取小一点（船长帽用 4 mm）
    face_dist      低模面中心离区域高模多近（米）才允许换；不要用像素命中代替它
    low_face_ok    可选，低模面的额外限定（bool 数组），比如“只有帽檐和皮带高度的面”
    accept         可选，函数 lab(N,3) -> bool(N)：新烘的颜色合格才换（比如“必须是暖色”）
    """
    from mathutils.kdtree import KDTree

    region_mask = np.asarray(region_mask, bool)
    high = high_all.copy()
    high.data = high_all.data.copy()
    high.name = "region_only"
    bpy.context.collection.objects.link(high)
    delete_faces(high, ~region_mask)
    size = color_image.size[0]
    new = {}
    modes = ["hit", "color"] + (["normal"] if normal_image is not None else [])
    for mode in modes:
        img = bpy.data.images.new("tmp_" + mode, size, size, alpha=False)
        if mode != "color":
            img.colorspace_settings.name = "Non-Color"
        bake_pass(high, low, img, mode, cage, cage * 3)
        new[mode] = _image_array(img)[:, :, :3].copy()
        bpy.data.images.remove(img)
        log("BAKED", mode)
    hit = new["hit"].mean(axis=2) > 0.5
    n_hit = int(hit.sum())

    kd = KDTree(len(high.data.polygons))
    for p in high.data.polygons:
        kd.insert(p.center, p.index)
    kd.balance()
    near = np.array([kd.find(p.center)[2] <= face_dist for p in low.data.polygons])
    if low_face_ok is not None:
        near &= np.asarray(low_face_ok, bool)
    hit &= uv_mask(low, near, size)
    stats = {"hit_px": n_hit, "low_faces": len(near), "low_faces_allowed": int(near.sum())}

    if accept is not None and hit.any():
        keep_px = accept(_srgb_to_lab(new["color"][hit] * 255))
        stats["rejected_px"] = int((~keep_px).sum())
        idx = np.nonzero(hit)
        hit = np.zeros_like(hit)
        hit[(idx[0][keep_px], idx[1][keep_px])] = True
    stats["replaced_px"] = int(hit.sum())

    for img, key in ((color_image, "color"), (normal_image, "normal")):
        if img is None or key not in new:
            continue
        arr = _image_array(img)
        arr[hit, :3] = new[key][hit]
        img.pixels.foreach_set(arr.ravel())
        img.update()
        img.pack()
    bpy.data.objects.remove(high)
    log("REBAKE", stats)
    return stats
