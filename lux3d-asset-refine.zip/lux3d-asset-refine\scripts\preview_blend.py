﻿"""精修过程中快速看一眼：打开 .blend，四个方向各渲一张（贴图 + 棚灯，Workbench，几秒钟），拼成一张图。

blender -b <文件.blend> -P preview_blend.py -- <输出.png> [仰角=12] [只看的物体名,逗号分隔；- 表示全部] [灰模=0]
"""
import math
import os
import sys

import bpy
from mathutils import Vector

argv = sys.argv[sys.argv.index("--") + 1:]
out = argv[0]
elev = math.radians(float(argv[1]) if len(argv) > 1 else 12)
only = [s for s in (argv[2].split(",") if len(argv) > 2 and argv[2] not in ("", "-") else [])]
solid = len(argv) > 3 and argv[3] == "1"
scene = bpy.context.scene
for o in scene.objects:
    if o.type == "MESH":
        o.hide_render = bool(only) and o.name not in only or o.name.startswith("COL_")
meshes = [o for o in scene.objects if o.type == "MESH" and not o.hide_render]
pts = [o.matrix_world @ Vector(c) for o in meshes for c in o.bound_box]
lo = Vector([min(p[i] for p in pts) for i in range(3)]); hi = Vector([max(p[i] for p in pts) for i in range(3)])
center, ext = (lo + hi) / 2, max(hi - lo)
cam = bpy.data.objects.new("pcam", bpy.data.cameras.new("pcam"))
scene.collection.objects.link(cam); scene.camera = cam
cam.data.type = "ORTHO"; cam.data.ortho_scale = ext * 1.15; cam.data.clip_end = ext * 20
scene.render.engine = "BLENDER_WORKBENCH"
sh = scene.display.shading
sh.light = "STUDIO"; sh.color_type = "SINGLE" if solid else "TEXTURE"; sh.single_color = (0.8, 0.8, 0.8)
sh.show_cavity = True; sh.cavity_type = "BOTH"; sh.show_shadows = False
scene.render.film_transparent = False
if scene.world is None:
    scene.world = bpy.data.worlds.new("w")
scene.world.color = (0.92, 0.92, 0.92)
scene.render.resolution_x = scene.render.resolution_y = 900
scene.view_settings.view_transform = "Standard"
files = []
for i, (x, y) in enumerate(((0, -1), (-1, 0), (0, 1), (1, 0))):
    d = Vector((x * math.cos(elev), y * math.cos(elev), math.sin(elev)))
    cam.location = center + d * ext * 4
    cam.rotation_euler = (-d).to_track_quat("-Z", "Y").to_euler()
    f = out.replace(".png", f"_{i}.png")
    scene.render.filepath = f
    bpy.ops.render.render(write_still=True)
    files.append(f)
# 拼图：用 Blender 自己的图片读写，不依赖 PIL
imgs = [bpy.data.images.load(f) for f in files]
W = H = 900
grid = bpy.data.images.new("grid", W * 2, H * 2)
import numpy as np
G = np.zeros((H * 2, W * 2, 4), np.float32)
for i, im in enumerate(imgs):
    a = np.empty(W * H * 4, np.float32); im.pixels.foreach_get(a); a = a.reshape(H, W, 4)
    r, c = 1 - i // 2, i % 2
    G[r * H:(r + 1) * H, c * W:(c + 1) * W] = a
grid.pixels.foreach_set(G.ravel())
grid.filepath_raw = out; grid.file_format = "PNG"; grid.save()
for f in files:
    os.remove(f)
print("PREVIEW", out)
