import * as THREE from 'three';
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js';
import {OrbitControls} from 'three/examples/jsm/controls/OrbitControls.js';
import {RoomEnvironment} from 'three/examples/jsm/environments/RoomEnvironment.js';

const status = document.getElementById('status');
const say = t => { status.textContent = t; };
const canvas = document.getElementById('c');
let renderer;
try {
  renderer = new THREE.WebGLRenderer({canvas, antialias:true, alpha:true});
} catch (e) { say('此环境不支持 WebGL，请用 Chrome / Edge 直接打开本文件。'); throw e; }
renderer.setClearColor(0x000000, 0);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.NoToneMapping;          // 不做色调压缩，贴图颜色原样显示
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
const pm = new THREE.PMREMGenerator(renderer);
scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture;
scene.environmentIntensity = 0.5;
scene.add(new THREE.HemisphereLight(0xffffff, 0xd8c8b0, 0.9));
const key = new THREE.DirectionalLight(0xffffff, 1.6);
key.castShadow = true; key.shadow.mapSize.set(2048, 2048); key.shadow.bias = -0.0004; key.shadow.normalBias = 0.02;
scene.add(key, key.target);

const cam = new THREE.PerspectiveCamera(32, 1, 0.1, 200);
const controls = new OrbitControls(cam, canvas);
controls.enableDamping = true; controls.maxPolarAngle = Math.PI * 0.52;
controls.autoRotate = true; controls.autoRotateSpeed = 1.2;
['start'].forEach(ev => controls.addEventListener(ev, () => { controls.autoRotate = false; clearTimeout(window.__t); window.__t = setTimeout(() => controls.autoRotate = true, 12000); }));

const floor = new THREE.Mesh(new THREE.CircleGeometry(40, 64), new THREE.ShadowMaterial({opacity: 0.28}));
floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);

const b64 = document.getElementById('glb').textContent.trim();
const bin = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
say('加载模型…');
new GLTFLoader().parse(bin.buffer, '', gltf => {
  const root = gltf.scene; scene.add(root);
  let withMap = 0, total = 0;
  root.traverse(o => {
    if (!o.isMesh) return;
    o.castShadow = o.receiveShadow = true;
    const ms = Array.isArray(o.material) ? o.material : [o.material];
    ms.forEach(m => { total++; if (m.map) { withMap++; m.map.anisotropy = 8; m.map.colorSpace = THREE.SRGBColorSpace; }
      if (m.roughness !== undefined) m.roughness = Math.max(m.roughness, 0.5);
      m.envMapIntensity = 0.8; m.needsUpdate = true; });
  });
  const box = new THREE.Box3().setFromObject(root);
  const size = box.getSize(new THREE.Vector3()), c = box.getCenter(new THREE.Vector3()), R = Math.max(size.x, size.y, size.z);
  floor.position.y = box.min.y - 0.002;
  key.position.set(c.x + R * 1.2, c.y + R * 2.2, c.z + R * 1.6); key.target.position.copy(c);
  const s = R * 1.2; Object.assign(key.shadow.camera, {left: -s, right: s, top: s, bottom: -s, near: 0.1, far: R * 8}); key.shadow.camera.updateProjectionMatrix();
  cam.position.set(c.x + R * 1.5, c.y + R * 0.55, c.z + R * 2.3);
  controls.target.copy(c); controls.minDistance = R * 0.8; controls.maxDistance = R * 6;
  say(`已加载 · ${withMap}/${total} 个材质带贴图 · 拖拽旋转 / 滚轮缩放 / 右键平移`);
  window.__ready = true; window.__tex = [withMap, total];
}, err => say('模型解析失败：' + (err && err.message || err)));

function resize() { const w = canvas.clientWidth, h = canvas.clientHeight; renderer.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); }
addEventListener('resize', resize); resize();
window.__setView = (az, el, d, frozen) => { window.__frozen = !!frozen; controls.autoRotate = false;
  const c = controls.target, R = (controls.maxDistance || 6) / 6, r = R * d;
  cam.position.set(c.x + r * Math.sin(az) * Math.cos(el), c.y + r * Math.sin(el), c.z + r * Math.cos(az) * Math.cos(el)); controls.update(); renderer.render(scene, cam); };
renderer.setAnimationLoop(() => { if (window.__frozen) return; controls.update(); renderer.render(scene, cam); });
