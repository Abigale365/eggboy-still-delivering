import {build} from 'esbuild'; import fs from 'fs';
const title = process.argv[2] || 'B8 阳台小楼', out = process.argv[3] || 'out/viewer.html', glbPath = process.argv[4] || 'model.glb';
const r = await build({entryPoints:['main.js'],bundle:true,minify:true,write:false,format:'iife'});
const js = r.outputFiles[0].text.replace(/<\/script/g,'<\\/script');
const glb = fs.readFileSync(glbPath).toString('base64');
const html = `<!doctype html><html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title} · 3D 查看</title><style>
*{box-sizing:border-box}html,body{margin:0;height:100%;overflow:hidden;background:linear-gradient(#dfe9f4,#f6ecdc 75%);font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;color:#3a2a20}
#c{position:fixed;inset:0;width:100%;height:100%;display:block;cursor:grab}#c:active{cursor:grabbing}
#bar{position:fixed;left:20px;top:16px;background:rgba(255,250,243,.85);border-radius:12px;padding:10px 14px;box-shadow:0 4px 18px rgba(90,60,30,.12);max-width:calc(100% - 40px)}
#bar b{font-size:18px}#status{display:block;font-size:12px;opacity:.7;margin-top:3px}
</style></head><body><canvas id="c"></canvas><div id="bar"><b>${title}</b><span id="status">…</span></div>
<script id="glb" type="text/plain">${glb}</script><script>${js}</script></body></html>`;
fs.mkdirSync('out',{recursive:true}); fs.writeFileSync(out,html); console.log((html.length/1e6).toFixed(1)+' MB ->',out);
