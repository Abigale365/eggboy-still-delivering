"""Blender-only decimation and PBR transfer; original materials are never edited."""
import math

import bmesh
import bpy
import numpy as np


def _principled(material):
    return next((n for n in material.node_tree.nodes if n.type == "BSDF_PRINCIPLED"), None)


def _constant(materials, socket_name):
    values = []
    for material in materials:
        socket = _principled(material).inputs[socket_name]
        if socket.is_linked:
            return None
        values.append(float(socket.default_value))
    return values[0] if values and max(values) - min(values) < 1e-6 else None


def _connect_input(tree, source, target):
    if source.is_linked:
        tree.links.new(source.links[0].from_socket, target)
    else:
        value = source.default_value
        if isinstance(value, (int, float)):
            target.default_value = (value, value, value, 1) if target.type == "RGBA" else value
        else:
            target.default_value = value


def decimate_bake_pbr(high, target_tris, size=2048, cage=0.05, rough=None):
    if high.type != "MESH" or target_tris < 1 or size < 4:
        raise ValueError("减面需要网格、正的面数预算与至少 4px 的贴图")
    low = high.copy()
    low.data = high.data.copy()
    low.name = high.name + "_low"
    bpy.context.collection.objects.link(low)
    bm = bmesh.new()
    bm.from_mesh(low.data)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-4)
    # 非流形边（一条边连着 3 个以上的面，生成网格里零件和本体焊在一起处常见）会把点钉住：
    # 减面卡在高面数，硬压到低面数还会撑出尖刺、把形状毁掉（船长帽实测 29 万面压到 1.9 万直接碎成多边形）。
    # 劈开后每条边只连两个面；点位置不动，形状不变，只多出重合的边界。只改低模副本，原模型不动。
    nonmanifold = [e for e in bm.edges if len(e.link_faces) > 2]
    if nonmanifold:
        bmesh.ops.split_edges(bm, edges=nonmanifold)
    low["split_nonmanifold_edges"] = len(nonmanifold)
    bm.to_mesh(low.data)
    bm.free()
    tris = sum(len(p.vertices) - 2 for p in low.data.polygons)
    modifier = low.modifiers.new("dec", "DECIMATE")
    modifier.ratio = min(1, target_tris / max(tris, 1))
    modifier.use_collapse_triangulate = True
    bpy.ops.object.select_all(action="DESELECT")
    low.select_set(True)
    bpy.context.view_layer.objects.active = low
    bpy.ops.object.modifier_apply(modifier=modifier.name)
    # Decimation can leave duplicate/degenerate faces on generated meshes.
    # Validate the new copy before baking; never repair the original in place.
    low.data.validate(clean_customdata=False)
    bm = bmesh.new()
    bm.from_mesh(low.data)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(low.data)
    bm.free()
    for polygon in low.data.polygons:
        polygon.use_smooth = True
    while low.data.uv_layers:
        low.data.uv_layers.remove(low.data.uv_layers[0])
    low.data.uv_layers.new(name="UVMap")
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.uv.smart_project(angle_limit=math.radians(60), island_margin=.004)
    bpy.ops.object.mode_set(mode="OBJECT")

    original_materials = list(high.data.materials)
    temporary = []
    scene = bpy.context.scene
    settings = {"engine": scene.render.engine, "samples": scene.cycles.samples, "device": scene.cycles.device}
    bake_keys = ("use_selected_to_active", "cage_extrusion", "max_ray_distance", "margin",
                 "use_pass_direct", "use_pass_indirect", "use_pass_color")
    bake_settings = {key: getattr(scene.render.bake, key) for key in bake_keys}
    try:
        for original in original_materials or [None]:
            material = original.copy() if original else bpy.data.materials.new("temporary_source")
            material.use_nodes = True
            if not _principled(material):
                raise ValueError("精修烘焙目前需要 Principled BSDF 材质；此素材应先单独诊断")
            temporary.append(material)
        high.data.materials.clear()
        for material in temporary:
            high.data.materials.append(material)

        metallic = _constant(temporary, "Metallic")
        roughness = float(rough) if rough is not None else _constant(temporary, "Roughness")
        alpha = _constant(temporary, "Alpha")
        needs_alpha = alpha is None or alpha < .999999
        needs_emission = any(
            _principled(m).inputs["Emission Color"].is_linked
            or (_principled(m).inputs["Emission Strength"].is_linked
                or _principled(m).inputs["Emission Strength"].default_value > 0)
            and max(_principled(m).inputs["Emission Color"].default_value[:3]) > 0
            for m in temporary)

        material = bpy.data.materials.new(high.name + "_baked")
        material.use_nodes = True
        material.use_backface_culling = all(m.use_backface_culling for m in temporary)
        low.data.materials.clear()
        low.data.materials.append(material)
        tree = material.node_tree
        shader = _principled(material)
        target = tree.nodes.new("ShaderNodeTexImage")
        scene.render.engine = "CYCLES"
        scene.cycles.samples = 1
        scene.cycles.device = "CPU"
        scene.render.bake.use_selected_to_active = True
        scene.render.bake.cage_extrusion = cage
        scene.render.bake.max_ray_distance = cage * 2.5
        scene.render.bake.margin = 6
        bpy.ops.object.select_all(action="DESELECT")
        high.select_set(True)
        low.select_set(True)
        bpy.context.view_layer.objects.active = low

        def image(name, data=False, hdr=False):
            img = bpy.data.images.new(high.name + "_" + name, size, size, alpha=True, float_buffer=hdr)
            img.file_format = "PNG"
            if data:
                img.colorspace_settings.name = "Non-Color"
            return img

        def bake(img, socket_name=None, normal=False, emission=False):
            for source in temporary:
                nt = source.node_tree
                p = _principled(source)
                output = next((n for n in nt.nodes if n.type == "OUTPUT_MATERIAL" and n.is_active_output), None)
                if output is None:
                    output = nt.nodes.new("ShaderNodeOutputMaterial")
                if normal:
                    nt.links.new(p.outputs["BSDF"], output.inputs["Surface"])
                else:
                    emitter = nt.nodes.new("ShaderNodeEmission")
                    if emission:
                        scale = nt.nodes.new("ShaderNodeVectorMath")
                        scale.operation = "SCALE"
                        color = p.inputs["Emission Color"]
                        if color.is_linked:
                            nt.links.new(color.links[0].from_socket, scale.inputs[0])
                        else:
                            scale.inputs[0].default_value = color.default_value[:3]
                        _connect_input(nt, p.inputs["Emission Strength"], scale.inputs["Scale"])
                        nt.links.new(scale.outputs["Vector"], emitter.inputs["Color"])
                    else:
                        _connect_input(nt, p.inputs[socket_name], emitter.inputs["Color"])
                    nt.links.new(emitter.outputs[0], output.inputs["Surface"])
            target.image = img
            tree.nodes.active = target
            bpy.ops.object.bake(type="NORMAL" if normal else "EMIT", normal_space="TANGENT")
            return img

        color = bake(image("color"), "Base Color")
        normal = bake(image("normal", data=True), normal=True)
        if needs_alpha:
            ai = bake(image("alpha", data=True), "Alpha")
            pixels = np.array(color.pixels[:], dtype=np.float32).reshape(-1, 4)
            pixels[:, 3] = np.array(ai.pixels[:], dtype=np.float32).reshape(-1, 4)[:, 0]
            color.pixels.foreach_set(pixels.ravel())
            bpy.data.images.remove(ai)
        else:
            color.file_format = "JPEG"
        color["preserve_alpha"] = needs_alpha
        color.pack()
        normal.pack()
        base_texture = tree.nodes.new("ShaderNodeTexImage")
        base_texture.image = color
        tree.links.new(base_texture.outputs["Color"], shader.inputs["Base Color"])
        if needs_alpha:
            tree.links.new(base_texture.outputs["Alpha"], shader.inputs["Alpha"])
        tn = tree.nodes.new("ShaderNodeTexImage")
        tn.image = normal
        nm = tree.nodes.new("ShaderNodeNormalMap")
        tree.links.new(tn.outputs["Color"], nm.inputs["Color"])
        tree.links.new(nm.outputs["Normal"], shader.inputs["Normal"])

        if metallic is not None:
            shader.inputs["Metallic"].default_value = metallic
        if roughness is not None:
            shader.inputs["Roughness"].default_value = roughness
        if metallic is None or roughness is None:
            channels = []
            for name, constant in (("Roughness", roughness), ("Metallic", metallic)):
                if constant is None:
                    img = bake(image(name.lower(), data=True), name)
                    channels.append(np.array(img.pixels[:], dtype=np.float32).reshape(-1, 4)[:, 0])
                    bpy.data.images.remove(img)
                else:
                    channels.append(np.full(size * size, constant, dtype=np.float32))
            packed = image("metal_rough", data=True)
            values = np.ones((size * size, 4), dtype=np.float32)
            values[:, 1], values[:, 2] = channels
            packed.pixels.foreach_set(values.ravel())
            packed.pack()
            tex = tree.nodes.new("ShaderNodeTexImage")
            tex.image = packed
            separate = tree.nodes.new("ShaderNodeSeparateColor")
            separate.mode = "RGB"
            tree.links.new(tex.outputs["Color"], separate.inputs["Color"])
            tree.links.new(separate.outputs["Green"], shader.inputs["Roughness"])
            tree.links.new(separate.outputs["Blue"], shader.inputs["Metallic"])

        if needs_emission:
            emitted = bake(image("emission", hdr=True), emission=True)
            pixels = np.array(emitted.pixels[:], dtype=np.float32).reshape(-1, 4)
            strength = max(1, float(pixels[:, :3].max()))
            pixels[:, :3] /= strength
            emitted.pixels.foreach_set(pixels.ravel())
            emitted.pack()
            te = tree.nodes.new("ShaderNodeTexImage")
            te.image = emitted
            tree.links.new(te.outputs["Color"], shader.inputs["Emission Color"])
            shader.inputs["Emission Strength"].default_value = strength
        tree.nodes.remove(target)
        tree.nodes.active = base_texture
        return low
    finally:
        high.data.materials.clear()
        for original in original_materials:
            high.data.materials.append(original)
        for temporary_material in temporary:
            bpy.data.materials.remove(temporary_material)
        scene.render.engine = settings["engine"]
        scene.cycles.samples = settings["samples"]
        scene.cycles.device = settings["device"]
        for key, value in bake_settings.items():
            setattr(scene.render.bake, key, value)
