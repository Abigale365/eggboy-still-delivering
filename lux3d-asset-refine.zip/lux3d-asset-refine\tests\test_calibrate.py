"""calibrate_colors：用程序拼的小渲染图，不需要 Blender。"""
import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import calibrate_colors  # noqa: E402


def save(path, arr):
    Image.fromarray(np.asarray(arr, np.uint8)).save(path)


class Calibrate(unittest.TestCase):
    def build(self, ref_rgb, lit_rgb, flat_rgb, chroma_hint=None):
        d = Path(tempfile.mkdtemp())
        r = d / "audit-v0" / "renders"
        r.mkdir(parents=True)
        n = 120
        # 预览图：整个画面一个颜色（带光），透明背景外圈
        ref = np.zeros((n, n, 4), np.uint8)
        ref[10:-10, 10:-10] = (*ref_rgb, 255)
        (d / "inputs").mkdir()
        save(d / "inputs" / "front.png", ref)
        solid = np.zeros((n, n, 3), np.uint8)
        solid[10:-10, 10:-10] = 200
        lit = np.zeros((n, n, 3), np.uint8)
        lit[10:-10, 10:-10] = lit_rgb
        flat = np.zeros((n, n, 4), np.uint8)
        flat[10:-10, 10:-10] = (*flat_rgb, 255)
        save(r / "solid_front.png", solid)
        save(r / "lit_front.png", lit)
        save(r / "flat_front.png", flat)
        asset = {"id": "t", "name": "t", "reference": {"front": "inputs/front.png"}, "height_m": 1,
                 "color_regions": {"all": {"view": "front", "boxes": [[0.2, 0.8, 0.2, 0.8]]}}}
        (d / "asset.json").write_text(json.dumps(asset), encoding="utf-8")
        return d

    def test_big_gap_is_cut_to_the_step_limit_and_keeps_warm_hue(self):
        # 原版皮革：打光渲染 (94,77,68)，贴图色 (67,49,36)；预览图 (160,96,67)——差得远
        d = self.build((160, 96, 67), (94, 77, 68), (67, 49, 36))
        out = calibrate_colors.calibrate(d, step_max=10.0, hue_max=10.0)["all"]
        self.assertGreater(out["de_want"], 15)
        self.assertLessEqual(out["de_step"], 10.5)           # 截断到每步上限
        self.assertLess(out["t"], 1.0)
        self.assertLessEqual(out["hue_shift"], 10.5)         # 彩度高，色相不许跑
        self.assertTrue(out["need"])
        self.assertTrue((d / "colors.json").exists())

    def test_already_matching_color_is_marked_not_needed(self):
        # 渲染里原版和预览图几乎一样：不该硬挪（船长帽帽身的教训）
        d = self.build((48, 48, 52), (48, 48, 51), (28, 29, 33))
        out = calibrate_colors.calibrate(d)["all"]
        self.assertLess(out["de_want"], 3.0)
        self.assertFalse(out["need"])

    def test_missing_regions_is_an_error(self):
        d = self.build((100, 100, 100), (100, 100, 100), (100, 100, 100))
        a = json.loads((d / "asset.json").read_text(encoding="utf-8"))
        a.pop("color_regions")
        (d / "asset.json").write_text(json.dumps(a), encoding="utf-8")
        with self.assertRaises(ValueError):
            calibrate_colors.calibrate(d)


if __name__ == "__main__":
    unittest.main()
