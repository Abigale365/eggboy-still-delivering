"""调色前先量：每个区域“渲染里原版和预览图差多少”，按“每步最多挪 ΔE N、色相不跑、保暖”截断，写成 colors.json。

    python calibrate_colors.py <工作目录> [--step-max 10] [--hue-max 10] [--renders audit-v0/renders]

asset.json 里要有 color_regions（区域在某个视图里占的位置，用占物体包围盒的比例），例如：
    "color_regions": {
      "leather": {"view": "front", "boxes": [[0.30, 0.70, 0.80, 0.90]]},
      "brass":   {"view": "front", "boxes": [[0.47, 0.53, 0.36, 0.60]]}
    }
做法：
  1. 取三块像素的中位数：预览图、原版的打光渲染（lit）、原版的贴图原色（flat，不受光）；
  2. 想要的贴图色 = 原版贴图色 × (预览图 / 原版打光)，线性光下按通道，比值夹在 [0.5, 3]
     ——预览图带光，不能直接拿它的颜色当贴图色，要把“光”这一层按原版渲染里的光抵掉；
  3. 步子 = min(1, step_max / ΔE)；彩度够高（≥ 8）的颜色再卡色相 ≤ hue_max；
  4. 数据显示 ΔE < 3 的区域会标 “不需要挪”——不要凭第一眼觉得“偏黑”就去调（船长帽的帽身就是这样：
     肉眼觉得缺蓝，量下来颜色已经对上，差的是亮度和布纹对比）。
结果写 <工作目录>/colors.json：{区域: {src, dst, want, t, de_want, de_step, hue_shift, chroma, need, radius}}。
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))
from audit import lab_to_rgb_hex, srgb_to_lab  # noqa: E402
from common import load_asset  # noqa: E402

NEED_MIN_DE = 3.0


def _crop(rgb, mask):
    ys, xs = np.nonzero(mask)
    sl = (slice(ys.min(), ys.max() + 1), slice(xs.min(), xs.max() + 1))
    return rgb[sl], mask[sl]


def _patch(rgb, mask, boxes):
    rgb, mask = _crop(rgb, mask)
    h, w = mask.shape
    out = []
    for x0, x1, y0, y1 in boxes:
        sl = (slice(int(y0 * h), int(y1 * h)), slice(int(x0 * w), int(x1 * w)))
        out.append(rgb[sl][mask[sl]])
    px = np.concatenate(out)
    if len(px) == 0:
        raise ValueError("取样框里没有物体像素，检查 color_regions 的坐标")
    return np.median(px, axis=0), len(px)


def _lin(c):
    c = np.asarray(c, float) / 255
    return np.where(c > 0.04045, ((c + 0.055) / 1.055) ** 2.4, c / 12.92)


def _unlin(c):
    c = np.clip(c, 0, 1)
    return np.clip(np.where(c > 0.0031308, 1.055 * c ** (1 / 2.4) - 0.055, 12.92 * c) * 255, 0, 255)


def _hue(lab):
    return float(np.degrees(np.arctan2(lab[2], lab[1])) % 360)


def calibrate(workdir, step_max=10.0, hue_max=10.0, renders="audit-v0/renders"):
    workdir = Path(workdir).resolve()
    asset = load_asset(workdir)
    regions = asset.get("color_regions")
    if not regions:
        raise ValueError("asset.json 里没有 color_regions")
    rdir = workdir / renders
    out = {}
    for name, spec in regions.items():
        view, boxes = spec.get("view", "front"), spec["boxes"]
        ref = np.asarray(Image.open(asset["reference"][view]).convert("RGBA")).astype(float)
        solid = np.asarray(Image.open(rdir / f"solid_{view}.png").convert("L")) > 6
        lit = np.asarray(Image.open(rdir / f"lit_{view}.png").convert("RGB")).astype(float)
        flat = np.asarray(Image.open(rdir / f"flat_{view}.png").convert("RGBA")).astype(float)
        Lr, _ = _patch(ref[:, :, :3], ref[:, :, 3] > 200, boxes)
        Lm, _ = _patch(lit, solid, boxes)
        S, _ = _patch(flat[:, :, :3], flat[:, :, 3] > 200, boxes)
        ratio = np.clip(_lin(Lr) / np.maximum(_lin(Lm), 1e-4), 0.5, 3.0)
        want = _unlin(_lin(S) * ratio)
        ls = srgb_to_lab(S[None].astype(float))[0]
        lw = srgb_to_lab(want[None])[0]
        de = float(np.linalg.norm(lw - ls))
        t = min(1.0, step_max / de) if de > 0 else 0.0
        chroma = float(np.hypot(ls[1], ls[2]))
        while chroma >= 8 and t > 0:
            mix = ls + t * (lw - ls)
            if abs((_hue(mix) - _hue(ls) + 180) % 360 - 180) <= hue_max:
                break
            t -= 0.05
        t = max(t, 0.0)
        mix = ls + t * (lw - ls)
        out[name] = {"src": lab_to_rgb_hex(ls), "dst": lab_to_rgb_hex(mix), "want": lab_to_rgb_hex(lw),
                     "t": round(t, 3), "de_want": round(de, 1), "de_step": round(float(np.linalg.norm(mix - ls)), 1),
                     "hue_shift": round(abs((_hue(mix) - _hue(ls) + 180) % 360 - 180), 1), "chroma": round(chroma, 1),
                     "need": de >= NEED_MIN_DE, "radius": spec.get("radius", 30)}
    (workdir / "colors.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("workdir", type=Path)
    ap.add_argument("--step-max", type=float, default=10.0)
    ap.add_argument("--hue-max", type=float, default=10.0)
    ap.add_argument("--renders", default="audit-v0/renders")
    o = ap.parse_args()
    for name, c in calibrate(o.workdir, o.step_max, o.hue_max, o.renders).items():
        flag = "" if c["need"] else "  ← 数据显示颜色已对上，不需要挪"
        print(f"{name:10s} 贴图色 {c['src']} → {c['dst']}（想要 {c['want']}，差 ΔE {c['de_want']}，只挪 {c['t']:.0%} = ΔE {c['de_step']}，"
              f"色相变 {c['hue_shift']}°，彩度 {c['chroma']}）{flag}")


if __name__ == "__main__":
    main()
