"""Portable launcher for the asset-specific oven example; never calls Lux3D."""
import argparse
import sys
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "scripts"))
from common import load_asset, run_blender


def main():
    parser = argparse.ArgumentParser(description="运行烤炉小手术示例；先准备工作目录里的 asset.json")
    parser.add_argument("workdir", type=Path)
    parser.add_argument("stage", choices=("surgery", "export"))
    args = parser.parse_args()
    asset = load_asset(args.workdir)
    if not asset.get("generated") or not Path(asset["generated"]).is_file():
        parser.error("asset.json.generated 必须指向现有 Lux3D 原版 GLB")
    if args.stage == "export" and not (args.workdir / "out" / "oven_surgery.blend").is_file():
        parser.error("没有 out/oven_surgery.blend，先运行 surgery 阶段")
    print(run_blender(Path(__file__).with_name("oven_v2.py"), args.stage, args.workdir.resolve(), "--skill", SKILL))


if __name__ == "__main__":
    main()
