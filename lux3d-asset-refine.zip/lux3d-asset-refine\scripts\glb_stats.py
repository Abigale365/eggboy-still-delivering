"""不开 Blender，直接读 GLB 统计：三角面、网格、材质、贴图尺寸、动画、节点上的功能说明。

    python glb_stats.py <模型.glb>
"""
import io
import json
import struct
import sys
from pathlib import Path

from PIL import Image
from common import read_glb_chunks


def read_glb(path):
    data = Path(path).read_bytes()
    j, _ = read_glb_chunks(path)
    offset, binstart = 12, len(data)
    while offset + 8 <= len(data):
        size, kind = struct.unpack_from("<I4s", data, offset)
        if kind == b"BIN\0":
            binstart = offset + 8
            break
        offset += size + 8
    return data, j, binstart


def glb_stats(path):
    data, j, b0 = read_glb(path)
    acc = j.get("accessors", [])
    tris = 0
    meshes = []
    for m in j.get("meshes", []):
        t = 0
        for p in m["primitives"]:
            if p.get("mode", 4) != 4:
                continue
            t += (acc[p["indices"]]["count"] if "indices" in p else acc[p["attributes"]["POSITION"]]["count"]) // 3
        meshes.append({"name": m.get("name"), "triangles": t})
    # 每个网格可能被多个节点引用
    for nd in j.get("nodes", []):
        if "mesh" in nd:
            tris += meshes[nd["mesh"]]["triangles"]
    texs = []
    for im in j.get("images", []):
        info = {"mime": im.get("mimeType", "?"), "bytes": 0, "size": [0, 0]}
        if "bufferView" in im:
            bv = j["bufferViews"][im["bufferView"]]
            raw = data[b0 + bv.get("byteOffset", 0): b0 + bv.get("byteOffset", 0) + bv["byteLength"]]
            info["bytes"] = len(raw)
            try:
                info["size"] = list(Image.open(io.BytesIO(raw)).size)
            except Exception as exc:
                info["error"] = f"贴图不能解码：{type(exc).__name__}"
        else:
            info["error"] = "贴图没有内嵌在 GLB 中，不能核实体量"
        texs.append(info)
    nodes = [{"name": nd.get("name"), "extras": nd["extras"]} for nd in j.get("nodes", []) if nd.get("extras")]
    mesh_nodes = [{"name": nd.get("name"), "triangles": meshes[nd["mesh"]]["triangles"],
                   "lux3d_origin": (nd.get("extras") or {}).get("lux3d_origin")} for nd in j.get("nodes", []) if "mesh" in nd]
    return {"file_bytes": len(data), "triangles": tris, "meshes": meshes, "materials": len(j.get("materials", [])),
            "textures": texs, "texture_bytes": sum(t["bytes"] for t in texs),
            "animations": [a.get("name", "?") for a in j.get("animations", [])],
            "node_names": [nd.get("name") for nd in j.get("nodes", [])], "nodes_with_extras": nodes,
            "mesh_nodes": mesh_nodes,
            "scene_extras": (j.get("scenes") or [{}])[0].get("extras"),
            "pbr_materials": [{"name": m.get("name"), **m.get("pbrMetallicRoughness", {}),
                               "emissiveFactor": m.get("emissiveFactor", [0, 0, 0]),
                               "normalTexture": m.get("normalTexture"), "emissiveTexture": m.get("emissiveTexture")}
                              for m in j.get("materials", [])],
            "extensions": j.get("extensionsUsed", [])}


if __name__ == "__main__":
    s = glb_stats(sys.argv[1])
    print(json.dumps(s, ensure_ascii=False, indent=1))
