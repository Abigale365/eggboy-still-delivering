// Run with node. Paid operations are blocked before credentials or network access.
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import { pathToFileURL } from 'node:url';

const source = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../scripts/lux3d.mjs');
assert.equal(spawnSync(process.execPath, ['--check', source]).status, 0);
let count = 0;
for (const command of ['img3d', 'fourview', 'edit', 'split']) {
  for (const flags of [[], ['--confirm=false']]) {
    const result = spawnSync(process.execPath, [source, command, 'offline-placeholder', ...flags], {
      encoding: 'utf8', timeout: 5000,
    });
    assert.equal(result.status, 3, `${command} ${flags}: ${result.stderr}`);
    count++;
  }
}
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'lux3d-offline-test-'));
const moduleUrl = pathToFileURL(source).href;
const timeoutCode = `
process.env.AHOLO_API_KEY = 'offline-test-only';
process.argv = [process.execPath, ${JSON.stringify(source)}, 'wait', ${JSON.stringify(root)}, 'offline-task', '--timeout-seconds=0.001'];
globalThis.fetch = async () => { throw new Error('Unexpected network call'); };
try { await import(${JSON.stringify(moduleUrl)}); process.exitCode = 1; }
catch (e) { if (!/等待超时/.test(e.message)) throw e; }
`;
const timeout = spawnSync(process.execPath, ['--input-type=module', '-e', timeoutCode], { encoding: 'utf8', timeout: 5000 });
assert.equal(timeout.status, 0, timeout.stderr);
assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'lux3d-log.json'), 'utf8')).steps[0].taskId, 'offline-task');
const badOutput = path.join(root, 'bad.glb');
const failedDownloadCode = `
process.env.AHOLO_API_KEY = 'offline-test-only';
process.argv = [process.execPath, ${JSON.stringify(source)}, 'wait', ${JSON.stringify(root)}, 'download-task', ${JSON.stringify(badOutput)}, '--timeout-seconds=10'];
const nativeTimer = globalThis.setTimeout;
globalThis.setTimeout = (fn, ms) => nativeTimer(fn, 0);
globalThis.fetch = async (url) => String(url).includes('/task/get')
  ? new Response(JSON.stringify({c:'0',d:{status:3,outputs:[{content:'https://offline.invalid/result.glb'}]}}), {status:200})
  : new Response('failure', {status:503});
try { await import(${JSON.stringify(moduleUrl)}); process.exitCode = 1; }
catch (e) { if (!/下载失败 HTTP 503/.test(e.message)) throw e; }
`;
const failedDownload = spawnSync(process.execPath, ['--input-type=module', '-e', failedDownloadCode], { encoding: 'utf8', timeout: 5000 });
assert.equal(failedDownload.status, 0, failedDownload.stderr);
assert.equal(fs.existsSync(badOutput), false);
console.log(`PASS: ${count} paid-command gates, bounded polling and failed download; all network calls mocked or blocked`);
