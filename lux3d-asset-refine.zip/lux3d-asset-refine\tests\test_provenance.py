"""glb_geom.provenance 的离线测试：用程序拼的小 GLB，不需要 Blender、不调 Lux3D。

覆盖：同形状不同缩放仍判 100%；删掉一半、整体偏移、换成别的形状会被抓；
标记写 True 也骗不了（几何按位置量）；压缩 GLB 报错而不是放行。
"""
import json
import struct
import sys
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import glb_geom  # noqa: E402


def cube(size=1.0, center=(0, 0, 0), n=6):
    """(顶点, 三角形下标)：每个面切成 n×n 个小方块，好让“一半被删”能按面删。"""
    v, idx = [], []
    h = size / 2
    for axis in range(3):
        for sign in (-1, 1):
            base = len(v)
            for i in range(n + 1):
                for j in range(n + 1):
                    p = [0, 0, 0]
                    p[axis] = sign * h
                    p[(axis + 1) % 3] = -h + size * i / n
                    p[(axis + 2) % 3] = -h + size * j / n
                    v.append([c + o for c, o in zip(p, center)])
            for i in range(n):
                for j in range(n):
                    a = base + i * (n + 1) + j
                    b, c, d = a + 1, a + n + 1, a + n + 2
                    idx += [[a, b, c], [b, d, c]]
    return np.array(v, np.float32), np.array(idx, np.uint32)


def write_glb(path, meshes, extensions_required=None):
    """meshes: [(名字, 顶点, 下标, extras 或 None)]，每个网格一个根节点。"""
    blob, views, accessors, doc_meshes, nodes = b"", [], [], [], []
    for name, v, idx, extras in meshes:
        pos_off = len(blob)
        blob += v.tobytes()
        views.append({"buffer": 0, "byteOffset": pos_off, "byteLength": v.nbytes})
        accessors.append({"bufferView": len(views) - 1, "componentType": 5126, "count": len(v), "type": "VEC3"})
        idx_off = len(blob)
        blob += idx.astype(np.uint32).tobytes()
        views.append({"buffer": 0, "byteOffset": idx_off, "byteLength": idx.size * 4})
        accessors.append({"bufferView": len(views) - 1, "componentType": 5125, "count": idx.size, "type": "SCALAR"})
        doc_meshes.append({"primitives": [{"attributes": {"POSITION": len(accessors) - 2}, "indices": len(accessors) - 1}]})
        node = {"name": name, "mesh": len(doc_meshes) - 1}
        if extras is not None:
            node["extras"] = extras
        nodes.append(node)
    doc = {"asset": {"version": "2.0"}, "scene": 0, "scenes": [{"nodes": list(range(len(nodes)))}], "nodes": nodes,
           "meshes": doc_meshes, "accessors": accessors, "bufferViews": views, "buffers": [{"byteLength": len(blob)}]}
    if extensions_required:
        doc["extensionsRequired"] = extensions_required
    js = json.dumps(doc).encode()
    js += b" " * (-len(js) % 4)
    blob += b"\0" * (-len(blob) % 4)
    total = 12 + 8 + len(js) + 8 + len(blob)
    Path(path).write_bytes(struct.pack("<4sII", b"glTF", 2, total) + struct.pack("<I4s", len(js), b"JSON") + js
                           + struct.pack("<I4s", len(blob), b"BIN\0") + blob)


class Provenance(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.dir = Path(tempfile.mkdtemp())
        self.orig = self.dir / "orig.glb"
        v, i = cube(0.42, n=8)                       # Lux3D 原版：0.42 m 的方块
        write_glb(self.orig, [("geometry_0", v, i, None)])

    def run_prov(self, meshes, **kw):
        out = self.dir / "refined.glb"
        write_glb(out, meshes, **kw)
        return glb_geom.provenance(self.orig, out, 2.0, n_orig=120_000, n_out=60_000)

    def test_same_shape_scaled_to_real_height(self):
        v, i = cube(2.0, center=(0, 1.0, 0), n=8)    # 精修后：2 m 高、底面在 y=0
        r = self.run_prov([("oven_body", v, i, {"lux3d_origin": True})])
        self.assertGreater(r["share"], 0.99)
        self.assertGreater(r["coverage"], 0.99)

    def test_new_geometry_far_from_original_is_caught_even_if_tagged_original(self):
        v, i = cube(2.0, center=(0, 1.0, 0), n=8)
        v2, i2 = cube(1.0, center=(3.0, 0.5, 0), n=8)   # 一大块新东西，离原版很远，却标成原件
        r = self.run_prov([("oven_body", v, i, {"lux3d_origin": True}), ("fake_original", v2, i2, {"lux3d_origin": True})])
        self.assertLess(r["share"], 0.9)
        fake = next(n for n in r["nodes"] if n["name"] == "fake_original")
        self.assertLess(fake["near"], 0.1)

    def test_removed_half_of_original_lowers_coverage(self):
        v, i = cube(2.0, center=(0, 1.0, 0), n=8)
        keep = np.array([t for t in i if v[t][:, 0].mean() < 0.0])   # 只留 x<0 的那半
        r = self.run_prov([("oven_body", v, keep, {"lux3d_origin": True})])
        self.assertGreater(r["share"], 0.99)             # 剩下的都是原件
        self.assertLess(r["coverage"], 0.7)              # 但原版少了一大半
        self.assertTrue(r["lost"])

    def test_wrong_scale_fails_closed(self):
        v, i = cube(0.42, n=8)                           # 没缩放到真实高度
        r = self.run_prov([("oven_body", v, i, {"lux3d_origin": True})])
        self.assertLess(r["share"], 0.5)

    def test_compressed_glb_is_rejected(self):
        v, i = cube(2.0, center=(0, 1.0, 0), n=2)
        with self.assertRaises(ValueError):
            self.run_prov([("oven_body", v, i, None)], extensions_required=["EXT_meshopt_compression"])


if __name__ == "__main__":
    unittest.main()
