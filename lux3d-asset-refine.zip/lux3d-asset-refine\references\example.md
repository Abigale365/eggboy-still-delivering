# 运行示例

两个示例都只演示“怎么在原件上写分阶段脚本”：选区、位置和转轴来自那两件素材，换素材要重新量、重新写。原始图片与模型不随技能打包；示例只写工作目录里的输出，不改原件。

## 船长帽（小件，无会动的部件，有分开烘）

`examples/cap_refine.py`，素材配置 `examples/cap_asset.json`，调色 `examples/cap_colors.json`（v8 时代的值，只作格式参考，新素材用 `calibrate_colors.py` 现量）。完整流程和数字见 `workflow-captain-cap.md`。

1. 建一个独立工作目录，复制 `examples/cap_asset.json` 为 `asset.json`；把 `generated` 改成这件帽子的 Lux3D 原版 GLB，四个 `reference` 改成对应参考图。相对路径相对工作目录。
2. `python <skill>/scripts/calibrate_colors.py <工作目录>` 写 `colors.json`。
3. 分阶段跑，参数 `k=v`：

```
blender -b --factory-startup -P <skill>/examples/cap_refine.py -- surgery <工作目录>
blender -b --factory-startup -P <skill>/examples/cap_refine.py -- export <工作目录> tag=v2 cage=0.0025 ratio=0.97 budget=20000
blender -b --factory-startup -P <skill>/examples/cap_refine.py -- rebake <工作目录> from=v2 tag=v8
```

| 阶段 | 做什么 | 参数 |
|---|---|---|
| `surgery` | 缩放、合并重复点、删漂浮碎片、按区域调色，存 `out/*.blend` | — |
| `export` | `decimate_bake` + 装锚点和碰撞体 + 标来源 + 导出 | `tag` `out` `budget` `ratio` `cage` |
| `export_keepuv` | 保留原 UV 减面（会棱角，只作对比） | `tag` `budget` |
| `rebake` | 从已导出的 `from` 版出发，只对区域重烘颜色（分开烘） | `from` `tag` `zmax` `facedist` `cage` |

**整体烘焙不出斑，到 `export` 就够了，不需要 `rebake`。** 脚本里的 `CEILING_Z`、`TOP_BUTTON`、皮革 / 黄铜的颜色类别都是这件帽子的，别照搬。

之后：功能检查、验收、看图、填 verdicts，见 SKILL.md 第 6 步。

## 砖砌烤炉（大件，有炉门转轴）

`examples/oven_v2.py` 的选区、原件位置与门轴来自那件户外砖砌烤炉。

1. 复制 `examples/oven_asset.json` 为 `<工作目录>/asset.json`，改 `generated` 与四个 `reference` 路径。
2. 用系统 Python 启动，不要求将 Blender 加到 PATH；找不到时设 `BLENDER_EXE`：

```
python <skill>/examples/run_oven.py <工作目录> surgery
python <skill>/examples/run_oven.py <工作目录> export
```

第一阶段输出 `out/oven_surgery.blend`，第二阶段输出 `out/oven_v2_final.blend` 与 `out/brick-oven-v2.glb`。第二阶段可以单独重跑。也可直接使用 Blender：

```
blender -b --factory-startup -P <skill>/examples/oven_v2.py -- surgery <工作目录>
blender -b --factory-startup -P <skill>/examples/oven_v2.py -- export <工作目录>
```

把示例脚本复制到其他地方时，增加 `--skill <技能目录>` 指定工具库。`run_oven.py` 不生成模型、不创建付费任务，也不会自行换掉原版错误部件。
