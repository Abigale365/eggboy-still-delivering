import {build} from 'esbuild'; import fs from 'fs';
const r = await build({entryPoints:['main.js'],bundle:true,minify:true,write:false,format:'iife'});
const js = r.outputFiles[0].text.replace(/<\/script/g,'<\\/script');
const glb = fs.readFileSync('/tmp/b8.glb').toString('base64');
const html = `<!doctype html><html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>B8 阳台小楼 · 可分解 3D</title><style>
*{box-sizing:border-box}html,body{margin:0;height:100%;overflow:hidden;background:linear-gradient(#cfe0f2,#f6e9d6 70%);font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;color:#3a2a20}
#c{position:fixed;inset:0;width:100%;height:100%;display:block}
.panel{position:fixed;background:rgba(255,250,243,.82);backdrop-filter:blur(8px);border:1px solid rgba(120,80,50,.18);border-radius:14px;padding:14px 16px;box-shadow:0 6px 24px rgba(90,60,30,.12)}
#title{left:24px;top:22px}#title h1{margin:0;font-size:22px}#title p{margin:4px 0 0;font-size:12px;opacity:.65}
#ctl{left:24px;bottom:24px;width:min(360px,calc(100% - 48px))}
#ctl label{font-size:12px;opacity:.7;display:flex;justify-content:space-between}
#ex{width:100%;margin:8px 0 12px;accent-color:#e0703a}
#groups{display:flex;flex-wrap:wrap;gap:6px}
button{font:inherit;font-size:12px;padding:6px 10px;border-radius:999px;border:1px solid rgba(120,80,50,.3);background:#fff;color:#6a5040;cursor:pointer}
button.on{background:#e0703a;border-color:#e0703a;color:#fff}
#tour{margin-top:10px;width:100%;border-radius:8px;background:#fff;color:#3a2a20}
#hint{right:24px;top:22px;font-size:12px;opacity:.75;max-width:220px}
body:not(.ready) #title:after{content:"加载模型…";font-size:12px}
</style></head><body><canvas id="c"></canvas>
<div class="panel" id="title"><h1>B8 阳台小楼</h1><p>潮汐镇 · 76 个命名部件 · 可拖拽旋转 / 滚轮缩放</p></div>
<div class="panel" id="hint">不操作时自动演示：合拢 → 展开 → 回收。任意操作接管，25 秒无操作后恢复。</div>
<div class="panel" id="ctl"><label><span>分解程度</span><span>合 ⟷ 展</span></label><input id="ex" type="range" min="0" max="1" step="0.005" value="0"><div id="groups"></div><button id="tour">▶ 重新播放自动演示</button></div>
<script id="glb" type="text/plain">${glb}</script><script>${js}</script></body></html>`;
fs.mkdirSync('out',{recursive:true}); fs.writeFileSync('out/B8_可分解3D.html',html); console.log((html.length/1e6).toFixed(1)+' MB');
