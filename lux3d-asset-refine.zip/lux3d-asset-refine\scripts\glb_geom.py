"""不开 Blender，直接从 GLB 读世界坐标三角形，量“精修后的模型有多少表面贴着 Lux3D 原版的表面”。

用来验收“原件占比”：不信节点上自己声明的 lux3d_origin 标记，按几何量。
做法：把原版按 asset.json 的真实高度归一化（和精修脚本里的 normalize 一致：按包围盒缩放到 height_m、
x / z 居中、底面放到 y=0），在原版表面撒点建树；再在精修模型每个网格的表面按面积撒点，
统计离原版表面不超过容差的比例。

    python glb_geom.py <原版.glb> <精修后.glb> <真实高度米> [yaw 度数]

只支持未压缩的 GLB（没有 Draco / meshopt）、三角形网格、内嵌 buffer；不支持时报错，验收按不通过处理。
"""
import math
import sys

import numpy as np
from scipy.spatial import cKDTree

from common import read_glb_chunks

_CT = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
_NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}


def _accessor(doc, binary, index):
    acc = doc["accessors"][index]
    if "sparse" in acc or "bufferView" not in acc:
        raise ValueError("不支持稀疏或无 bufferView 的 accessor")
    view = doc["bufferViews"][acc["bufferView"]]
    if view.get("buffer", 0) != 0:
        raise ValueError("需要内嵌的 GLB buffer")
    dt = np.dtype(_CT[acc["componentType"]]).newbyteorder("<")
    n = _NC[acc["type"]]
    esize = dt.itemsize * n
    stride = view.get("byteStride") or esize
    start = view.get("byteOffset", 0) + acc.get("byteOffset", 0)
    count = acc["count"]
    buf = np.frombuffer(binary, dtype=np.uint8)
    if stride == esize:
        raw = buf[start:start + count * esize]
    else:
        raw = buf[start + np.arange(count)[:, None] * stride + np.arange(esize)[None, :]]
    if raw.size != count * esize:
        raise ValueError("accessor 数据不完整")
    return np.ascontiguousarray(raw).view(dt).reshape(count, n)


def _local_matrix(nd):
    if "matrix" in nd:
        return np.array(nd["matrix"], float).reshape(4, 4).T
    x, y, z, w = nd.get("rotation", (0, 0, 0, 1))
    norm = math.sqrt(x * x + y * y + z * z + w * w) or 1.0
    x, y, z, w = x / norm, y / norm, z / norm, w / norm
    rot = np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                    [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                    [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])
    m = np.eye(4)
    m[:3, :3] = rot * np.array(nd.get("scale", (1, 1, 1)), float)[None, :]
    m[:3, 3] = nd.get("translation", (0, 0, 0))
    return m


def world_triangles(path, skip_prefix=("COL_",)):
    """返回 [{"name": 节点名, "tris": (n, 3, 3) 世界坐标三角形}]，跳过碰撞体。"""
    doc, binary = read_glb_chunks(path)
    required = set(doc.get("extensionsRequired", []))
    if required & {"KHR_draco_mesh_compression", "EXT_meshopt_compression", "KHR_mesh_quantization"}:
        raise ValueError("不支持压缩 / 量化的 GLB：" + "、".join(sorted(required)))
    nodes = doc.get("nodes", [])
    parent = {c: i for i, nd in enumerate(nodes) for c in nd.get("children", [])}
    world = {}

    def wm(i):
        if i not in world:
            local = _local_matrix(nodes[i])
            world[i] = wm(parent[i]) @ local if i in parent else local
        return world[i]

    out = []
    for i, nd in enumerate(nodes):
        if "mesh" not in nd or str(nd.get("name", "")).startswith(skip_prefix):
            continue
        m = wm(i)
        chunks = []
        for prim in doc["meshes"][nd["mesh"]]["primitives"]:
            if prim.get("mode", 4) != 4:
                continue
            pos = _accessor(doc, binary, prim["attributes"]["POSITION"])
            if pos.dtype != np.float32:
                raise ValueError("位置不是 float32，不支持")
            pos = pos.astype(np.float64) @ m[:3, :3].T + m[:3, 3]
            if "indices" in prim:
                idx = _accessor(doc, binary, prim["indices"]).reshape(-1).astype(np.int64)
            else:
                idx = np.arange(len(pos))
            idx = idx[:len(idx) // 3 * 3].reshape(-1, 3)
            chunks.append(pos[idx])
        if chunks:
            out.append({"name": nd.get("name", f"node{i}"), "tris": np.concatenate(chunks)})
    if not out:
        raise ValueError("GLB 里没有三角形网格")
    return out


def _areas(tris):
    return 0.5 * np.linalg.norm(np.cross(tris[:, 1] - tris[:, 0], tris[:, 2] - tris[:, 0]), axis=1)


def sample_surface(tris, n, rng):
    """按面积在三角形表面均匀撒 n 个点。"""
    area = _areas(tris)
    total = area.sum()
    if total <= 0 or n <= 0:
        return np.zeros((0, 3)), 0.0
    which = rng.choice(len(tris), size=n, p=area / total)
    u, v = rng.random(n), rng.random(n)
    flip = u + v > 1
    u[flip], v[flip] = 1 - u[flip], 1 - v[flip]
    t = tris[which]
    return t[:, 0] + u[:, None] * (t[:, 1] - t[:, 0]) + v[:, None] * (t[:, 2] - t[:, 0]), float(total)


def normalize_like_pipeline(parts, height_m, yaw_deg=0.0):
    """和精修脚本里的 normalize 一致：（绕竖直轴转 yaw）→ 按高度缩放 → x / z 居中 → 底面到 y=0。就地改 parts。"""
    a = math.radians(yaw_deg)
    rot = np.array([[math.cos(a), 0, math.sin(a)], [0, 1, 0], [-math.sin(a), 0, math.cos(a)]])
    allv = np.concatenate([p["tris"].reshape(-1, 3) for p in parts]) @ rot.T
    lo, hi = allv.min(0), allv.max(0)
    if hi[1] - lo[1] <= 0:
        raise ValueError("原版没有高度")
    s = height_m / (hi[1] - lo[1])
    shift = np.array([-(lo[0] + hi[0]) / 2, -lo[1], -(lo[2] + hi[2]) / 2])
    for p in parts:
        p["tris"] = ((p["tris"].reshape(-1, 3) @ rot.T + shift) * s).reshape(-1, 3, 3)
    return s


def provenance(original, refined, height_m, tol_frac=0.006, yaw_deg=0.0, n_orig=800_000, n_out=600_000, seed=0):
    """量两件事（都按表面积）：
      share     精修后的模型有多少表面离原版表面不超过容差（新做的、偏离原版的部件会拉低它）；
      coverage  原版表面有多少还被精修后的模型保留着（删掉、换掉原版部件会拉低它）。
    容差 = 高度 × tol_frac + 采样间距的 1.5 倍（采样点是离散的，最近点距离本身有这么大的误差）。
    量不出来的：贴在原版表面上的薄片 / 小凸起（离表面很近，两个指标都算它是原件），靠 lux3d_origin 标记和看图。
    返回 dict：share、coverage、tol_m、nodes（每个网格贴着原版的比例）、lost（原版没保留的区域，按 0.25 m 格子）。"""
    rng = np.random.default_rng(seed)
    orig = world_triangles(original)
    scale = normalize_like_pipeline(orig, height_m, yaw_deg)
    opts, orig_area = sample_surface(np.concatenate([p["tris"] for p in orig]), n_orig, rng)
    o_spacing = math.sqrt(orig_area / max(len(opts), 1))
    tol = height_m * tol_frac + 1.5 * o_spacing
    otree = cKDTree(opts)

    out = world_triangles(refined)
    areas = [float(_areas(p["tris"]).sum()) for p in out]
    total = sum(areas) or 1.0
    nodes, near_area, all_pts, all_d = [], 0.0, [], []
    for p, a in zip(out, areas):
        k = max(2000, int(n_out * a / total))
        samples, _ = sample_surface(p["tris"], k, rng)
        if len(samples) == 0:
            continue
        d, _ = otree.query(samples)
        near = float((d <= tol).mean())
        near_area += near * a
        all_pts.append(samples)
        all_d.append(d)
        nodes.append({"name": p["name"], "area_m2": round(a, 3), "near": round(near, 3),
                      "p95_mm": round(float(np.percentile(d, 95)) * 1000, 1)})
    pts_out = np.concatenate(all_pts)
    r_spacing = math.sqrt(total / max(len(pts_out), 1))
    tol_cov = height_m * tol_frac + 1.5 * r_spacing
    sub = opts[rng.choice(len(opts), size=min(200_000, len(opts)), replace=False)]
    dc, _ = cKDTree(pts_out).query(sub)
    covered = dc <= tol_cov
    lost = []
    if (~covered).any():
        cells, counts = np.unique(np.floor(sub[~covered] / 0.25).astype(int), axis=0, return_counts=True)
        for i in np.argsort(-counts)[:3]:
            c = (cells[i] + 0.5) * 0.25
            lost.append({"center_m": [round(float(v), 2) for v in c], "share_of_original": round(float(counts[i] / len(sub)), 3)})
    return {"share": near_area / total, "coverage": float(covered.mean()), "tol_m": tol, "tol_cov_m": tol_cov,
            "spacing_m": o_spacing, "scale": scale, "p95_mm": round(float(np.percentile(np.concatenate(all_d), 95)) * 1000, 1),
            "nodes": nodes, "lost": lost}

if __name__ == "__main__":
    r = provenance(sys.argv[1], sys.argv[2], float(sys.argv[3]), yaw_deg=float(sys.argv[4]) if len(sys.argv) > 4 else 0.0)
    print(f"精修后的表面贴着原版的比例 {r['share']:.1%}；原版表面被保留的比例 {r['coverage']:.1%}"
          f"（容差 {r['tol_m'] * 1000:.1f} mm，缩放 ×{r['scale']:.3f}）")
    for l in r["lost"]:
        print(f"  原版没保留的区域：中心 {l['center_m']} m，占原版表面 {l['share_of_original']:.1%}")
    for n in sorted(r["nodes"], key=lambda n: -n["area_m2"]):
        print(f"  {n['name']:<22} 面积 {n['area_m2']:>7.3f} m²  贴着原版 {n['near']:.0%}  95% 的点离原版 ≤ {n['p95_mm']} mm")
