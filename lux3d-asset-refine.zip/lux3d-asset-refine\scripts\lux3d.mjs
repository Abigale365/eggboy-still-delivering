// 调 Aholo Lux3D：上传本地图 / 模型、下单、等结果、下载。只用 Node 18+ 自带的 fetch，不装依赖。
// 每次下单都记进 <工作目录>/lux3d-log.json（结果地址约 2 小时内有效，拆分等后续任务要用）。
//
//   node lux3d.mjs img3d   <工作目录> <名字> <图1> [图2 ...] [--turbo] [--faces=300000]
//   node lux3d.mjs fourview <工作目录> <图片> ["提示词"]           → <工作目录>/inputs/fourview-*.png
//   node lux3d.mjs edit    <工作目录> <图片> "提示词" <输出.png>    （改图：去掉某个部件、改材质等）
//   node lux3d.mjs split   <工作目录> <名字> [--file=本地.glb]      → gen/<名字>-parts.glb
//   node lux3d.mjs wait    <工作目录> <taskId> <输出文件>           （接着等已经下过单的任务）
//   node lux3d.mjs check                                            （只验 key，不花积分）
//
// 花积分的命令（img3d / fourview / edit / split）必须加 --confirm，表示用户已经同意这一次调用；
// 不加只打印要做什么，不下单。agent 不能自己替用户加 --confirm。
//
// key：环境变量 AHOLO_API_KEY；没有就从当前目录往上找 .env 里的 AHOLO_API_KEY=...；
//      再没有就用 --env=<.env 路径>。
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const GATEWAY = 'https://api.aholo3d.cn';
const [cmd, ...rest] = process.argv.slice(2);
const flags = Object.fromEntries(rest.filter(a => a.startsWith('--')).map(a => { const [k, v] = a.slice(2).split('='); return [k, v ?? true]; }));
const pos = rest.filter(a => !a.startsWith('--'));

function findKey() {
  if (process.env.AHOLO_API_KEY) return process.env.AHOLO_API_KEY.trim();
  const files = [];
  if (flags.env) files.push(path.resolve(flags.env));
  for (let d = process.cwd(); ; d = path.dirname(d)) {
    files.push(path.join(d, '.env'));
    if (path.dirname(d) === d) break;
  }
  if (pos[0]) for (let d = path.resolve(pos[0]); ; d = path.dirname(d)) {
    files.push(path.join(d, '.env'));
    if (path.dirname(d) === d) break;
  }
  for (const f of files) {
    if (!fs.existsSync(f)) continue;
    const m = fs.readFileSync(f, 'utf8').match(/^\s*AHOLO_API_KEY\s*=\s*(\S+)\s*$/m);
    if (m) return m[1].replace(/^["']|["']$/g, '');
  }
  console.error('找不到 AHOLO_API_KEY：设环境变量，或用 --env=<.env 路径>');
  process.exit(2);
}
const PAID = new Set(['img3d', 'fourview', 'edit', 'split']);
if (PAID.has(cmd) && flags.confirm !== true && flags.confirm !== 'true') {
  console.log('【没有下单】这一步会花 Lux3D 积分：', cmd, pos.join(' '));
  console.log('先把要做什么、为什么、预计几次调用告诉用户，用户同意后再加 --confirm 重跑。');
  process.exit(3);
}
const key = findKey();

const sleep = ms => new Promise(r => setTimeout(r, ms));
const now = () => new Date().toISOString();
const requestOptions = () => ({ signal: AbortSignal.timeout(60000) });
let LOG, log;
function openLog(workdir) {
  fs.mkdirSync(workdir, { recursive: true });
  LOG = path.join(workdir, 'lux3d-log.json');
  log = fs.existsSync(LOG) ? JSON.parse(fs.readFileSync(LOG, 'utf8')) : { steps: [], models: {} };
}
const saveLog = () => fs.writeFileSync(LOG, JSON.stringify(log, null, 2));

async function api(method, url, body) {
  const res = await fetch(GATEWAY + url, {
    ...requestOptions(),
    method,
    headers: { authorization: key, ...(body ? { 'content-type': 'application/json' } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`${url} → HTTP ${res.status}: ${text.slice(0, 300)}`);
  try { return JSON.parse(text); } catch { throw new Error(`${url} → HTTP ${res.status}: ${text.slice(0, 300)}`); }
}

async function upload(file) {
  const tok = await api('GET', '/asset/v1/token');
  const { ousToken, globalDomain } = tok.d ?? tok;
  if (!ousToken) throw new Error('拿不到上传 token：' + JSON.stringify(tok).slice(0, 300));
  const buf = fs.readFileSync(file);
  const form = new FormData();
  form.append('md5', crypto.createHash('md5').update(buf).digest('hex'));
  form.append('file', new Blob([buf]), path.basename(file));
  const up = await (await fetch(globalDomain + '/ous/api/v2/single/upload', { ...requestOptions(), method: 'POST', headers: { 'ous-token-v2': ousToken }, body: form })).json();
  if (up.c !== '0') throw new Error('上传失败 ' + JSON.stringify(up));
  for (let i = 0; i < 150; i++) {
    await sleep(400);
    const st = await (await fetch(globalDomain + '/ous/api/v2/upload/status', { ...requestOptions(), headers: { 'ous-token-v2': ousToken } })).json();
    if (st.d?.status === 5) return st.d.url;
    if (st.d?.status === 6 || st.d?.status === 8) throw new Error('上传失败 ' + JSON.stringify(st));
  }
  throw new Error('上传超时');
}

async function run(step, url, body) {
  const t0 = Date.now();
  const created = await api('POST', url, body);
  if (created.c !== '0' || created.d == null) throw new Error(`${step} 下单失败：${JSON.stringify(created)}`);
  const rec = { step, url, body, taskId: created.d, at: now() };
  console.log(`[${step}] 任务 ${rec.taskId} 已创建`);
  log.steps.push(rec);
  saveLog();
  return wait(rec, t0);
}

async function wait(rec, t0 = Date.now()) {
  const seconds = Number(flags['timeout-seconds'] ?? 1200);
  if (!Number.isFinite(seconds) || seconds <= 0) throw new Error('--timeout-seconds 必须是正数');
  const deadline = Date.now() + seconds * 1000;
  if (!log.steps.includes(rec)) { log.steps.push(rec); saveLog(); }
  let last = -1;
  while (Date.now() < deadline) {
    await sleep(Math.min(4000, Math.max(1, deadline - Date.now())));
    if (Date.now() >= deadline) break;
    const q = await api('GET', `/lux3d/v1/generate/task/get?taskid=${rec.taskId}`);
    if (q.c !== '0') { console.log('查询异常', q.c, q.m); continue; }
    const { status, outputs } = q.d;
    if (status !== last) { console.log(`[${rec.step}] 状态 ${status} @ ${Math.round((Date.now() - t0) / 1000)}s`); last = status; }
    if (status === 3) {
      rec.outputs = (outputs ?? []).map(o => o?.content);
      rec.seconds = Math.round((Date.now() - t0) / 1000);
      rec.doneAt = now();
      saveLog();
      return rec.outputs;
    }
    if (status === 4 || status === 6) {
      rec.error = JSON.stringify(q.d).slice(0, 800);
      saveLog();
      throw new Error(`[${rec.step}] 失败：${rec.error}`);
    }
  }
  rec.lastWaitEndedAt = now();
  saveLog();
  throw new Error(`等待超时，任务 ${rec.taskId} 已保存在日志中。用 wait 继续查询；不要重复下单。`);
}

async function download(u, file) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  if (typeof u !== 'string' || !u.startsWith('http')) throw new Error('没有有效的结果下载地址');
  const response = await fetch(u, requestOptions());
  if (!response.ok) throw new Error(`下载失败 HTTP ${response.status}`);
  const buf = Buffer.from(await response.arrayBuffer());
  if (!buf.length || /\.glb$/i.test(file) && buf.subarray(0, 4).toString() !== 'glTF') {
    throw new Error('下载内容为空或不是有效 GLB，不写入输出文件');
  }
  fs.writeFileSync(file, buf);
  console.log('  已下载', file, (buf.length / 1e6).toFixed(2) + ' MB');
}

const findGlb = outs => outs.find(u => typeof u === 'string' && /\.glb(\?|$)/i.test(u)) ?? outs.find(u => typeof u === 'string' && u.startsWith('http'));
const findImgs = outs => JSON.stringify(outs).match(/https?:[^"\\\s]+?\.(png|jpe?g|webp)[^"\\\s]*/gi) ?? [];

if (cmd === 'check') {
  const tok = await api('GET', '/asset/v1/token');
  // 返回有时包在 d 里、有时是平的（upload() 两种都认），这里也要两种都认；失败时不打印返回体（里面有临时上传令牌）
  const ok = Boolean((tok.d ?? tok)?.ousToken);
  console.log(ok ? 'key 可用' : `key 不可用：接口返回里没有上传令牌（c=${tok.c ?? '无'}，m=${String(tok.m ?? '').slice(0, 80)}）`);
  process.exit(ok ? 0 : 4);
} else if (cmd === 'img3d') {
  const [workdir, name, ...imgs] = pos;
  openLog(workdir);
  const urls = [];
  for (const f of imgs) urls.push(await upload(f));
  const body = { version: flags.turbo ? 'G1-Turbo' : 'G1', faceCount: Number(flags.faces ?? 300000), outputFormat: ['glb'], aiPredictSize: false };
  if (urls.length === 1) body.img = urls[0]; else body.imgs = urls;
  const outs = await run('img3d:' + name, '/lux3d/v1/generate/img-to-3d/task/create', body);
  const glb = findGlb(outs);
  log.models[name] = { url: glb, at: now(), inputs: imgs, version: body.version, faceCount: body.faceCount };
  saveLog();
  await download(glb, path.join(workdir, 'gen', name + '.glb'));
} else if (cmd === 'fourview') {
  const [workdir, img, prompt] = pos;
  openLog(workdir);
  const body = { img: await upload(img), ...(prompt ? { prompt } : {}) };
  const outs = await run('fourview', '/lux3d/v1/generate/image-to-four-view/task/create', body);
  const urls = findImgs(outs);
  for (const [i, u] of urls.entries()) await download(u, path.join(workdir, 'inputs', `fourview-${i + 1}.png`));
} else if (cmd === 'edit') {
  const [workdir, img, prompt, out] = pos;
  openLog(workdir);
  const outs = await run('edit', '/lux3d/v1/generate/multimodal-to-image/task/create', { img: await upload(img), prompt });
  const [u] = findImgs(outs);
  if (!u) throw new Error('没拿到图片：' + JSON.stringify(outs).slice(0, 300));
  await download(u, path.resolve(out));
} else if (cmd === 'split') {
  const [workdir, name] = pos;
  openLog(workdir);
  const glbUrl = flags.file ? await upload(flags.file) : log.models?.[name]?.url;
  if (!glbUrl) throw new Error('log 里没有这个模型的地址（可能已过期），用 --file=本地.glb 上传');
  const outs = await run('split:' + name, '/lux3d/v1/part-split/task/create', { glbUrl });
  const u = findGlb(outs);
  log.models[name + '-parts'] = { url: u, at: now() };
  saveLog();
  await download(u, path.join(workdir, 'gen', name + '-parts.glb'));
} else if (cmd === 'wait') {
  const [workdir, taskId, out] = pos;
  openLog(workdir);
  const rec = log.steps.find(s => String(s.taskId) === String(taskId)) ?? { step: 'wait', taskId };
  const outs = await wait(rec);
  console.log(outs);
  if (out) await download(findGlb(outs), path.resolve(out));
} else {
  console.log('用法见文件开头注释');
}
