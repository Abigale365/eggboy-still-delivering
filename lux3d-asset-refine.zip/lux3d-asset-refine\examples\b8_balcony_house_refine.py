import bpy
import bmesh
import math
import mathutils
from mathutils import Vector
import numpy as np
from pathlib import Path

# Paths
PROJECT_ROOT = Path(r"G:\1 business\the second brain\项目工作区\2026.09.05 AI赛事\2026.11.19 群核Aholo全球3D AI黑客松")
SRC_GLB = PROJECT_ROOT / r"06_模型测试\2026-11-02_模型边界测试\models\T05_balcony_house.glb"
REF_PNG = PROJECT_ROOT / r"05_Skill与三维资产\04_批量制作\2026-11-06_B8阳台小楼_Blender实跑\参考.png"
OUT_DIR = PROJECT_ROOT / r"05_Skill与三维资产\04_批量制作\2026-11-06_B8阳台小楼_Blender实跑\2026-11-14_B8_四面精雕版"
OUT_DIR.mkdir(parents=True, exist_ok=True)

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(SRC_GLB))

base_obj = bpy.data.objects["geometry_0"]
base_obj.name = "B8_House_Body"

# 1. Scale to standard scene scale (height = 5.25m, bottom at Z=0)
S = 35.0
base_obj.scale = (S, S, S)
base_obj.location = (0.0, 0.0, 0.075 * S)
bpy.context.view_layer.update()
bpy.ops.object.select_all(action='DESELECT')
base_obj.select_set(True)
bpy.context.view_layer.objects.active = base_obj
bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

mesh = base_obj.data

def smoothstep(edge0, edge1, x):
    t = max(0.0, min(1.0, (x - edge0) / (edge1 - edge0)))
    return t * t * (3.0 - 2.0 * t)

# First smoothly collapse ONLY the old blurry bronze moon & pedestal (z > 4.635, 0.68 < x < 1.12, -0.12 < y < 0.32)
# onto its exact neck center (0.82, 0.06, 4.635) with smoothstep so zero stretched triangles or wires appear!
for v in mesh.vertices:
    if v.co.z > 4.635 and 0.68 < v.co.x < 1.12 and -0.12 < v.co.y < 0.32:
        t = min(1.0, (v.co.z - 4.635) / 0.06)
        v.co.x = v.co.x * (1.0 - 0.92 * t) + 0.82 * (0.92 * t)
        v.co.y = v.co.y * (1.0 - 0.92 * t) + 0.06 * (0.92 * t)
        v.co.z = 4.635 + (v.co.z - 4.635) * 0.02

orig_coords = [(v.co.x, v.co.y, v.co.z) for v in mesh.vertices]

def eval_roof_deform(x, y, z):
    z_clamped = min(z, 4.64)
    if z <= 2.78:
        return x, y, z

    # (A) Upper Ridge & Witch-Hat Peak Domain (x > -0.55):
    #     All asymmetric peak/ridge deformations (dx_peak, dy_crown, dz_peak, dz_front_prow, dz_back_saddle)
    #     smoothly taper to 0.0 by x = -0.55 (60cm to the right of the chimney at x = -1.14).
    #     This keeps the entire chimney (x in [-2.02, -1.14]) 100.0% rigid, vertical, and level-capped
    #     AND completely eliminates the sharp upward tile ridge/horn at x = -1.00 next to the chimney!
    h_crown = smoothstep(2.82, 4.55, z_clamped)
    w_peak_x = smoothstep(-0.55, 0.45, x) * (1.0 - smoothstep(1.38, 2.12, x))
    dz_peak = 0.24 * (h_crown ** 1.25) * w_peak_x
    dx_peak = 0.14 * (h_crown ** 1.35) * w_peak_x

    # (B) Longitudinal Saddle-Arch on the Upper Ridge (Front Prow Uplift + Back Saddle Sweep + Crown Camber)
    w_ridge_x = smoothstep(-0.55, 0.20, x) * (1.0 - smoothstep(1.15, 1.75, x))
    w_front_y = smoothstep(0.20, -0.88, y)
    dz_front_prow = 0.13 * (h_crown ** 1.20) * w_front_y * w_ridge_x

    w_back_y = smoothstep(-0.10, 0.85, y)
    dz_back_saddle = -0.18 * (smoothstep(3.10, 4.48, z_clamped) ** 1.20) * w_back_y * w_ridge_x

    cos_y = math.cos(min(math.pi * 0.5, abs(y) * 1.15))
    dy_crown = -0.10 * (h_crown ** 1.45) * (cos_y ** 1.5) * w_ridge_x

    # (C) Left Eave Overhang Smooth Downward Follow-Through (x < -1.55)
    #     1) Pure X-dependent downward follow-through (dz_left_droop) eliminates the upward curl at the left eave tip.
    #     2) Soft-knee height compression above z_ref_left(x) along the outer left eave flattens the side arch smoothly.
    dz_left_droop = -0.09 * smoothstep(-1.55, -2.50, x) * smoothstep(2.78, 3.10, z_clamped) * (1.0 - smoothstep(3.55, 3.95, z_clamped))
    z_ref_left = 2.91 + 0.36 * max(0.0, x + 2.55)
    w_left_cap = smoothstep(-1.60, -2.22, x) * smoothstep(-0.88, -0.25, y) * smoothstep(z_ref_left - 0.02, z_ref_left + 0.14, z_clamped) * (1.0 - smoothstep(3.50, 3.85, z_clamped))
    dz_left_side = -0.56 * w_left_cap * max(0.0, z_clamped - z_ref_left)
    dz_left_smooth = dz_left_droop + dz_left_side

    # (D) Right Snail-Scroll Coplanar Pull (dy_scroll) + Two-Lobe Hump Equalizer (dz_right_smooth)
    #     1) Pulls the backward-slanted upper lobe of the front snail scroll forward in -Y (dy_scroll) so it sits
    #        coplanar with the front bargeboard.
    #     2) Specifically targets the two raw 3.56m humps at y in [-0.65, -0.15] and y in [+0.45, +0.88] while keeping
    #        the already-low middle (y in [-0.10, +0.40], raw 3.40m) at ~3.33m and preserving the round spiral domes
    #        on the front (y < -0.68) and back (y > +0.88) scroll faces!
    w_scroll_x = smoothstep(1.82, 2.12, x)
    w_scroll_y = smoothstep(-0.95, -0.38, y) * (1.0 - smoothstep(-0.15, 0.45, y))
    w_scroll_z = smoothstep(3.08, 3.32, z_clamped)
    dy_scroll = -0.18 * w_scroll_x * w_scroll_y * w_scroll_z

    y_start_r = -0.76 + 0.22 * smoothstep(2.08, 2.35, x)
    w_front_hump = smoothstep(y_start_r, y_start_r + 0.30, y) * (1.0 - 0.42 * smoothstep(-0.22, 0.08, y))
    w_back_hump = 0.42 * smoothstep(0.32, 0.65, y) * (1.0 - smoothstep(0.82, 1.06, y))
    w_back_keep = 1.0 - 0.55 * smoothstep(0.75, 1.02, y) * smoothstep(2.08, 2.35, x)
    w_right_y = 0.24 + 0.74 * min(1.0, (w_front_hump + w_back_hump)) * w_back_keep
    w_right_x = smoothstep(1.68, 2.05, x)
    w_right_z = smoothstep(3.15, 3.30, z_clamped)
    dz_right_smooth = -0.62 * w_right_y * w_right_x * w_right_z * max(0.0, z_clamped - 3.20)

    nx = x + dx_peak
    ny = y + dy_crown + dy_scroll
    nz = z_clamped + dz_peak + dz_front_prow + dz_back_saddle + dz_left_smooth + dz_right_smooth
    return nx, ny, nz

for idx, v in enumerate(mesh.vertices):
    x, y, z = orig_coords[idx]
    v.co.x, v.co.y, v.co.z = eval_roof_deform(x, y, z)

# Compute exact deformed apex where the collapsed pedestal sits (0.82, 0.06, 4.64)
px, py, pz = eval_roof_deform(0.82, 0.06, 4.64)
neck_center = Vector((px, py, pz + 0.015))

mesh.update()
bpy.context.view_layer.update()

# 2b. Non-Destructive 1-Ring Border UV Repair on B8_House_Body (Zero Faces Deleted!)
#     Any triangle on a crease that has 1 or 2 valid UVs and 1 unbaked (0,0) UV copies the valid UV of its own triangle.
bm_clean = bmesh.new()
bm_clean.from_mesh(mesh)
uv_lay_clean = bm_clean.loops.layers.uv.active

def is_unbaked_uv(uv):
    return uv.x < 0.0015 and uv.y < 0.0015

for _ in range(3):
    for f in bm_clean.faces:
        valid_f = [l[uv_lay_clean].uv.copy() for l in f.loops if not is_unbaked_uv(l[uv_lay_clean].uv)]
        if valid_f:
            avg_f = sum(valid_f, Vector((0.0, 0.0))) / len(valid_f)
            for l in f.loops:
                if is_unbaked_uv(l[uv_lay_clean].uv):
                    l[uv_lay_clean].uv = avg_f

bm_clean.to_mesh(mesh)
bm_clean.free()
mesh.update()
bpy.context.view_layer.update()

# 3. Preserve 100% of Original Aholo Glazed Ceramic Figurine Material (Image_0 + Image_1)
#    AND seamlessly inpaint all dark unbaked occlusion pinholes/cracks (luma < 0.195) from surrounding valid pixels!
img0 = bpy.data.images['Image_0']
p0 = np.array(img0.pixels[:], dtype=np.float32).reshape(2048, 2048, 4)

luma = 0.299 * p0[:, :, 0] + 0.587 * p0[:, :, 1] + 0.114 * p0[:, :, 2]
hole_mask = luma < 0.195
valid = (luma >= 0.215).astype(np.float32)
rgb = p0[:, :, :3].copy()
rgb[~(luma >= 0.215)] = 0.0
for _ in range(48):
    sum_rgb = (
        np.roll(rgb, 1, axis=0) + np.roll(rgb, -1, axis=0) +
        np.roll(rgb, 1, axis=1) + np.roll(rgb, -1, axis=1) +
        np.roll(np.roll(rgb, 1, axis=0), 1, axis=1) +
        np.roll(np.roll(rgb, 1, axis=0), -1, axis=1) +
        np.roll(np.roll(rgb, -1, axis=0), 1, axis=1) +
        np.roll(np.roll(rgb, -1, axis=0), -1, axis=1)
    )
    sum_w = (
        np.roll(valid, 1, axis=0) + np.roll(valid, -1, axis=0) +
        np.roll(valid, 1, axis=1) + np.roll(valid, -1, axis=1) +
        np.roll(np.roll(valid, 1, axis=0), 1, axis=1) +
        np.roll(np.roll(valid, 1, axis=0), -1, axis=1) +
        np.roll(np.roll(valid, -1, axis=0), 1, axis=1) +
        np.roll(np.roll(valid, -1, axis=0), -1, axis=1)
    )
    can_fill = (valid == 0.0) & (sum_w > 0.0)
    rgb = np.where(can_fill[:, :, None], sum_rgb / np.maximum(sum_w[:, :, None], 1e-5), rgb)
    valid = np.where(can_fill, 1.0, valid)

# Smooth blend for borderline dark pixels (0.14 < luma < 0.215) so zero hard ring appears
blend_t = np.clip((0.215 - luma) / 0.075, 0.0, 1.0)[:, :, None]
p0[:, :, :3] = p0[:, :, :3] * (1.0 - blend_t) + rgb * blend_t
img0.pixels.foreach_set(p0.ravel())
img0.pack()

mat_base = bpy.data.materials['Designer_Logic_PBR']
mat_base.use_backface_culling = False
bsdf_base = mat_base.node_tree.nodes.get('Principled BSDF')
if bsdf_base:
    bsdf_base.inputs['Specular IOR Level'].default_value = 0.50
    bsdf_base.inputs['Emission Strength'].default_value = 0.0

# 3b. Non-Destructive Front-Wall Pinhole Sealer (Seals ONLY rays that pass through Front Wall into Hollow Cave loc.y > -0.82!)
def build_front_pinhole_sealer(nx=260, nz=260):
    xs = np.linspace(-1.35, 1.35, nx)
    zs = np.linspace(1.02, 3.62, nz)
    valid_hit = np.zeros((nz, nx), dtype=bool)
    raw_holes = np.zeros((nz, nx), dtype=bool)
    steep_rim = np.zeros((nz, nx), dtype=bool)
    y_grid = np.full((nz, nx), -0.98, dtype=np.float32)
    u_grid = np.full((nz, nx), 0.273, dtype=np.float32)
    v_grid = np.full((nz, nx), 0.308, dtype=np.float32)

    uv_data = mesh.uv_layers.active.data
    polys = mesh.polygons
    ray_dir = Vector((0.0, 1.0, 0.0))

    for iz, wz in enumerate(zs):
        for ix, wx in enumerate(xs):
            # Skip the 2nd-floor balcony door/railing zone where railing balusters have intentional gaps
            if -0.62 < wx < 0.62 and 1.85 < wz < 3.32:
                continue
            hit, loc, norm, idx = base_obj.ray_cast(Vector((wx, -9.5, wz)), ray_dir)
            if not hit:
                continue
            if loc.y > -0.82:
                # Ray passed through a pinhole in the front wall and hit the inner cavity wall (loc.y ~ +1.224 or -0.798)!
                raw_holes[iz, ix] = True
            else:
                if norm.y > -0.42:
                    steep_rim[iz, ix] = True
                if norm.y < -0.45:
                    p = polys[idx]
                    uvs = [uv_data[li].uv for li in p.loop_indices]
                    u_m = sum(u.x for u in uvs) / len(uvs)
                    v_m = sum(u.y for u in uvs) / len(uvs)
                    if u_m > 0.002 or v_m > 0.002:
                        valid_hit[iz, ix] = True
                        y_grid[iz, ix] = loc.y
                        u_grid[iz, ix] = u_m
                        v_grid[iz, ix] = v_m

    # Expand raw_holes into adjacent steep_rim cells (the dark inward-curving lip of each pinhole) + 1-cell rim cover
    holes = raw_holes.copy()
    for _ in range(3):
        nbr_hole = np.roll(holes, 1, 0) | np.roll(holes, -1, 0) | np.roll(holes, 1, 1) | np.roll(holes, -1, 1)
        holes = holes | (nbr_hole & steep_rim)
    holes = holes | np.roll(raw_holes, 1, 0) | np.roll(raw_holes, -1, 0) | np.roll(raw_holes, 1, 1) | np.roll(raw_holes, -1, 1)

    # Diffuse 3D depth y_grid from valid_hit into holes over 48 steps
    w_valid = valid_hit.astype(np.float32)
    y_fill = np.where(valid_hit, y_grid, 0.0)
    for _ in range(48):
        sw = (
            np.roll(w_valid, 1, 0) + np.roll(w_valid, -1, 0) +
            np.roll(w_valid, 1, 1) + np.roll(w_valid, -1, 1) +
            np.roll(np.roll(w_valid, 1, 0), 1, 1) + np.roll(np.roll(w_valid, 1, 0), -1, 1) +
            np.roll(np.roll(w_valid, -1, 0), 1, 1) + np.roll(np.roll(w_valid, -1, 0), -1, 1)
        )
        sa = (
            np.roll(y_fill, 1, 0) + np.roll(y_fill, -1, 0) +
            np.roll(y_fill, 1, 1) + np.roll(y_fill, -1, 1) +
            np.roll(np.roll(y_fill, 1, 0), 1, 1) + np.roll(np.roll(y_fill, 1, 0), -1, 1) +
            np.roll(np.roll(y_fill, -1, 0), 1, 1) + np.roll(np.roll(y_fill, -1, 0), -1, 1)
        )
        upd = (w_valid == 0.0) & (sw > 0.0)
        y_fill = np.where(upd, sa / np.maximum(sw, 1e-5), y_fill)
        w_valid = np.where(upd, 1.0, w_valid)

    for _ in range(6):
        y_avg = 0.25 * (np.roll(y_fill, 1, 0) + np.roll(y_fill, -1, 0) + np.roll(y_fill, 1, 1) + np.roll(y_fill, -1, 1))
        y_fill = np.where(holes, y_avg, y_fill)

    # Dilate holes by 1 grid cell to form a tucked collar behind the intact wall rim
    active = holes | np.roll(holes, 1, 0) | np.roll(holes, -1, 0) | np.roll(holes, 1, 1) | np.roll(holes, -1, 1)

    comp_id = np.full((nz, nx), -1, dtype=np.int32)
    comp_uv = {}
    cid = 0
    for iz in range(nz):
        for ix in range(nx):
            if active[iz, ix] and comp_id[iz, ix] == -1:
                stack = [(iz, ix)]
                comp_id[iz, ix] = cid
                cells = []
                while stack:
                    cz, cx = stack.pop()
                    cells.append((cz, cx))
                    for dz_i, dx_i in [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)]:
                        nz_i, nx_i = cz + dz_i, cx + dx_i
                        if 0 <= nz_i < nz and 0 <= nx_i < nx and active[nz_i, nx_i] and comp_id[nz_i, nx_i] == -1:
                            comp_id[nz_i, nx_i] = cid
                            stack.append((nz_i, nx_i))
                candidates = []
                for cz, cx in cells:
                    for dz_i in range(-3, 4):
                        for dx_i in range(-3, 4):
                            nz_i, nx_i = cz + dz_i, cx + dx_i
                            if 0 <= nz_i < nz and 0 <= nx_i < nx and valid_hit[nz_i, nx_i]:
                                u_c, v_c = float(u_grid[nz_i, nx_i]), float(v_grid[nz_i, nx_i])
                                px_i = int(np.clip(u_c, 0.0, 0.999) * 2048)
                                py_i = int(np.clip(v_c, 0.0, 0.999) * 2048)
                                lum_c = float(0.299 * p0[py_i, px_i, 0] + 0.587 * p0[py_i, px_i, 1] + 0.114 * p0[py_i, px_i, 2])
                                candidates.append((lum_c, u_c, v_c))
                if candidates:
                    candidates.sort(key=lambda t: t[0])
                    pick_idx = int(len(candidates) * 0.78)
                    _, u0, v0 = candidates[min(pick_idx, len(candidates) - 1)]
                else:
                    u0, v0 = 0.273, 0.308
                wx_c = sum(xs[cx] for _, cx in cells) / len(cells)
                wz_c = sum(zs[cz] for cz, _ in cells) / len(cells)
                comp_uv[cid] = (u0, v0, wx_c, wz_c)
                cid += 1

    s_verts = []
    s_uvs = []
    s_faces = []
    v_map = {}

    for iz in range(nz - 1):
        for ix in range(nx - 1):
            c_here = max(comp_id[iz, ix], comp_id[iz + 1, ix], comp_id[iz, ix + 1], comp_id[iz + 1, ix + 1])
            if c_here < 0:
                continue
            u0, v0, wx_c, wz_c = comp_uv[c_here]
            quad_idx = []
            for jz, jx in [(iz, ix), (iz, ix + 1), (iz + 1, ix + 1), (iz + 1, ix)]:
                key = (c_here, jz, jx)
                if key not in v_map:
                    is_h = holes[jz, jx]
                    offset = -0.0032 if is_h else 0.0065
                    vy = float(y_fill[jz, jx]) + offset
                    v_map[key] = len(s_verts)
                    s_verts.append((float(xs[jx]), vy, float(zs[jz])))
                    du = np.clip((float(xs[jx]) - wx_c) * 0.006, -0.003, 0.003)
                    dv = np.clip((float(zs[jz]) - wz_c) * 0.006, -0.003, 0.003)
                    s_uvs.append((float(np.clip(u0 + du, 0.002, 0.998)), float(np.clip(v0 + dv, 0.002, 0.998))))
                quad_idx.append(v_map[key])
            s_faces.append((quad_idx[0], quad_idx[1], quad_idx[2], quad_idx[3]))

    if s_faces:
        sm = bpy.data.meshes.new("B8_Sealer_front")
        sm.from_pydata(s_verts, [], s_faces)
        for poly in sm.polygons:
            poly.use_smooth = True
        uv_l = sm.uv_layers.new(name="UVMap")
        for poly in sm.polygons:
            for li in poly.loop_indices:
                uv_l.data[li].uv = s_uvs[sm.loops[li].vertex_index]
        sm.materials.append(mat_base)
        sobj = bpy.data.objects.new("B8_Sealer_front", sm)
        bpy.context.collection.objects.link(sobj)

build_front_pinhole_sealer(nx=260, nz=260)
bpy.context.view_layer.update()

# 4. Build Rich Glazed Hand-Painted Texture Atlas Matched to Aholo's Image_0 Palette & Glossy Figurine Shader
ATLAS_RES = 1024
atlas = np.zeros((ATLAS_RES, ATLAS_RES, 4), dtype=np.float32)
atlas[:, :, 3] = 1.0

rng = np.random.default_rng(42)
yy, xx = np.mgrid[0:256, 0:512].astype(np.float32)
uu = xx / 512.0
vv = yy / 256.0

border_u = np.minimum(uu, 1.0 - uu)
border_v = np.minimum(vv, 1.0 - vv)
border = np.minimum(border_u, border_v)
crevice_mask = (np.clip((0.13 - border) / 0.13, 0.0, 1.0) ** 1.45)
center_glow = (np.sin(np.pi * uu) * np.sin(np.pi * vv)) ** 0.75 * 0.075

def smooth_noise(h=256, w=512, gh=16, gw=32):
    grid = rng.standard_normal((gh + 1, gw + 1)).astype(np.float32)
    gy = np.linspace(0, gh - 1e-4, h)
    gx = np.linspace(0, gw - 1e-4, w)
    iy = gy.astype(np.int32)
    ix = gx.astype(np.int32)
    fy = (gy - iy)[:, None]
    fx = (gx - ix)[None, :]
    c00 = grid[iy[:, None], ix[None, :]]
    c10 = grid[iy[:, None], ix[None, :] + 1]
    c01 = grid[iy[:, None] + 1, ix[None, :]]
    c11 = grid[iy[:, None] + 1, ix[None, :] + 1]
    sx = fx * fx * (3.0 - 2.0 * fx)
    sy = fy * fy * (3.0 - 2.0 * fy)
    return (c00 * (1 - sx) + c10 * sx) * (1 - sy) + (c01 * (1 - sx) + c11 * sx) * sy

organic_mottle = 0.022 * smooth_noise(256, 512, 8, 16) + 0.012 * smooth_noise(256, 512, 24, 48)
wood_streak = 0.026 * smooth_noise(256, 512, 6, 48) + 0.012 * smooth_noise(256, 512, 12, 96)

def fill_tile(row, col, base_rgb, crevice_rgb, mottle_field, use_bevel=True):
    r0, r1 = row * 256, (row + 1) * 256
    c0, c1 = col * 512, (col + 1) * 512
    grad_v = (vv - 0.5) * 0.045
    for ch in range(3):
        val = base_rgb[ch] + mottle_field + grad_v + (center_glow if use_bevel else 0.0)
        if use_bevel:
            val = val * (1.0 - 0.42 * crevice_mask) + crevice_rgb[ch] * (0.42 * crevice_mask)
        atlas[r0:r1, c0:c1, ch] = np.clip(val, 0.02, 0.98)

fill_tile(0, 0, (0.93, 0.78, 0.61), (0.52, 0.28, 0.14), organic_mottle, True)          # Tile 0: Warm Cream Arch Stone
fill_tile(0, 1, (0.87, 0.46, 0.24), (0.46, 0.20, 0.09), organic_mottle * 1.15, True)   # Tile 1: Vibrant Terracotta Orange Stone
fill_tile(1, 0, (0.76, 0.62, 0.49), (0.42, 0.26, 0.15), organic_mottle, True)          # Tile 2: Warm Tan-Grey Base Stone
fill_tile(1, 1, (0.44, 0.24, 0.13), (0.22, 0.10, 0.05), wood_streak, False)            # Tile 3: Smooth Glazed Caramel-Walnut Wood
fill_tile(2, 0, (0.58, 0.34, 0.17), (0.26, 0.12, 0.06), wood_streak * 0.8, False)      # Tile 4: Warm Honey-Ochre Mullion Timber

r0, r1 = 2 * 256, 3 * 256
c0, c1 = 1 * 512, 2 * 512
diag_sheen = np.exp(-((uu - vv * 0.65 - 0.20) / 0.11) ** 2) * 0.16 + np.exp(-((uu - vv * 0.65 - 0.35) / 0.05) ** 2) * 0.10
warm_bottom = (1.0 - vv) * np.sin(np.pi * uu) * 0.22
vignette = 0.38 + 0.62 * (np.sin(np.pi * uu) * np.sin(np.pi * vv)) ** 0.30
atlas[r0:r1, c0:c1, 0] = np.clip((0.28 + warm_bottom * 1.10 + diag_sheen * 0.95) * vignette, 0.10, 0.78)
atlas[r0:r1, c0:c1, 1] = np.clip((0.16 + warm_bottom * 0.65 + diag_sheen * 0.85) * vignette, 0.06, 0.65)
atlas[r0:r1, c0:c1, 2] = np.clip((0.09 + warm_bottom * 0.30 + diag_sheen * 0.70) * vignette, 0.04, 0.52)

fill_tile(3, 0, (0.92, 0.66, 0.20), (0.55, 0.32, 0.06), organic_mottle * 0.35, False)  # Tile 6: Glossy Gold Finial
fill_tile(3, 1, (0.28, 0.15, 0.09), (0.16, 0.08, 0.04), organic_mottle * 0.3, False)   # Tile 7: Warm Deep Brown Recess Backing

atlas_img = bpy.data.images.new("B8_Detail_Atlas", width=ATLAS_RES, height=ATLAS_RES)
atlas_img.pixels.foreach_set(atlas.ravel())
atlas_img.pack()

def tile_uv(tile_idx, u, v):
    row = tile_idx // 2
    col = tile_idx % 2
    u_clamped = max(0.02, min(0.98, u))
    v_clamped = max(0.02, min(0.98, v))
    return ((col + u_clamped) * 0.5, (row + v_clamped) * 0.25)

def make_detail_material(name, roughness=0.09, metallic=0.0, spec=0.50):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nodes = m.node_tree.nodes
    links = m.node_tree.links
    bsdf = nodes.get("Principled BSDF")
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Specular IOR Level"].default_value = spec
    bsdf.inputs["Emission Strength"].default_value = 0.0
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = atlas_img
    links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    return m

mat_detail = make_detail_material("B8_Sculpted_Masonry_Wood", roughness=0.09, metallic=0.0, spec=0.50)
mat_glass = make_detail_material("B8_Storybook_Glass", roughness=0.05, metallic=0.0, spec=0.60)
mat_gold = make_detail_material("B8_Finial_Gold", roughness=0.12, metallic=0.88, spec=0.55)

# 5. Raycast Surface Fitting Helper onto base_obj
def wall_raycast(wall_side, u_coord, z_coord):
    if wall_side == 'left':
        hit, loc, norm, _ = base_obj.ray_cast((-5.0, u_coord, z_coord), (1.0, 0.0, 0.0))
        if not hit or loc.x < -2.40 or loc.x > -1.85:
            loc = Vector((-2.16, u_coord, z_coord))
        return loc, Vector((-1.0, 0.0, 0.0))
    elif wall_side == 'right':
        hit, loc, norm, _ = base_obj.ray_cast((5.0, u_coord, z_coord), (-1.0, 0.0, 0.0))
        if not hit or loc.x > 2.40 or loc.x < 1.75:
            loc = Vector((2.03, u_coord, z_coord))
        return loc, Vector((1.0, 0.0, 0.0))
    elif wall_side == 'back':
        hit, loc, norm, _ = base_obj.ray_cast((u_coord, 5.0, z_coord), (0.0, -1.0, 0.0))
        if not hit or loc.y > 1.48 or loc.y < 1.10:
            loc = Vector((u_coord, 1.245, z_coord))
        return loc, Vector((0, 1.0, 0.0))

detail_objects = []

def create_pillow_patch(name, wall_side, grid_uv_func, nu, nv, height_max, tile_idx, mat=mat_detail, sink_depth=-0.025, power=2.6, periodic_u=False):
    verts = []
    uvs = []
    faces = []
    for j in range(nv + 1):
        v_param = j / nv
        pv = max(0.0, math.sin(math.pi * v_param)) ** (1.0 / power)
        for i in range(nu + 1):
            u_param = i / nu
            pu = 1.0 if periodic_u else (max(0.0, math.sin(math.pi * u_param)) ** (1.0 / power))
            profile = pu * pv
            u_w, z_w = grid_uv_func(u_param, v_param)
            loc, nrm = wall_raycast(wall_side, u_w, z_w)
            disp = sink_depth + (height_max - sink_depth) * profile
            p_front = loc + nrm * disp
            verts.append(p_front)
            uvs.append(tile_uv(tile_idx, u_param, v_param))

    for j in range(nv):
        for i in range(nu):
            v0 = j * (nu + 1) + i
            v1 = v0 + 1
            v2 = v0 + (nu + 1) + 1
            v3 = v0 + (nu + 1)
            faces.append((v0, v1, v2, v3))

    perim_indices = []
    for i in range(nu + 1):
        perim_indices.append(i)
    for j in range(1, nv + 1):
        perim_indices.append(j * (nu + 1) + nu)
    for i in range(nu - 1, -1, -1):
        perim_indices.append(nv * (nu + 1) + i)
    for j in range(nv - 1, 0, -1):
        perim_indices.append(j * (nu + 1))

    nrm_vec = Vector((-1, 0, 0)) if wall_side == 'left' else (Vector((1, 0, 0)) if wall_side == 'right' else Vector((0, 1, 0)))
    back_start = len(verts)
    for idx in perim_indices:
        verts.append(verts[idx] - nrm_vec * 0.065)
        uvs.append(uvs[idx])

    n_p = len(perim_indices)
    for k in range(n_p):
        k_next = (k + 1) % n_p
        f0 = perim_indices[k]
        f1 = perim_indices[k_next]
        b1 = back_start + k_next
        b0 = back_start + k
        faces.append((f1, f0, b0, b1))

    m_data = bpy.data.meshes.new(name)
    m_data.from_pydata([tuple(v) for v in verts], [], faces)

    bm = bmesh.new()
    bm.from_mesh(m_data)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(m_data)
    bm.free()

    for poly in m_data.polygons:
        poly.use_smooth = True

    uv_layer = m_data.uv_layers.new(name="UVMap")
    for poly in m_data.polygons:
        for loop_idx in poly.loop_indices:
            v_idx = m_data.loops[loop_idx].vertex_index
            uv_layer.data[loop_idx].uv = uvs[v_idx]

    m_data.materials.append(mat)
    obj = bpy.data.objects.new(name, m_data)
    bpy.context.collection.objects.link(obj)
    detail_objects.append(obj)
    return obj

# ==============================================================================
# 6. Build LEFT Wall (-X): Sculpted Round Window (圆窗) with Smooth Continuous Wood Rim
# ==============================================================================
Yc_L, Zc_L = 0.04, 1.58
R_in_L, R_out_L = 0.25, 0.43

create_pillow_patch(
    "Left_Window_Backing", 'left',
    lambda u, v: (
        Yc_L + (R_in_L + 0.04) * (2*u - 1) * math.sqrt(max(0.0, 1.0 - 0.5 * (2*v - 1)**2)),
        Zc_L + (R_in_L + 0.04) * (2*v - 1) * math.sqrt(max(0.0, 1.0 - 0.5 * (2*u - 1)**2))
    ),
    16, 16, height_max=0.024, tile_idx=7, mat=mat_detail, sink_depth=-0.02, power=4.0
)

create_pillow_patch(
    "Left_Window_Glass", 'left',
    lambda u, v: (
        Yc_L + (R_in_L - 0.01) * (2*u - 1) * math.sqrt(max(0.0, 1.0 - 0.5 * (2*v - 1)**2)),
        Zc_L + (R_in_L - 0.01) * (2*v - 1) * math.sqrt(max(0.0, 1.0 - 0.5 * (2*u - 1)**2))
    ),
    18, 18, height_max=0.052, tile_idx=5, mat=mat_glass, sink_depth=0.012, power=2.2
)

create_pillow_patch(
    "Left_Inner_Wood_Ring", 'left',
    lambda u, v: (
        Yc_L + (R_in_L - 0.032 + 0.058 * v) * math.cos(2.0 * math.pi * u),
        Zc_L + (R_in_L - 0.032 + 0.058 * v) * math.sin(2.0 * math.pi * u)
    ),
    48, 8, height_max=0.072, tile_idx=3, mat=mat_detail, sink_depth=0.012, power=2.2, periodic_u=True
)

create_pillow_patch(
    "Left_Cross_H", 'left',
    lambda u, v: (Yc_L + (2*u - 1) * (R_in_L - 0.005), Zc_L + (2*v - 1) * 0.026),
    16, 6, height_max=0.068, tile_idx=4, mat=mat_detail, sink_depth=0.02, power=2.5
)
create_pillow_patch(
    "Left_Cross_V", 'left',
    lambda u, v: (Yc_L + (2*u - 1) * 0.026, Zc_L + (2*v - 1) * (R_in_L - 0.005)),
    6, 16, height_max=0.068, tile_idx=4, mat=mat_detail, sink_depth=0.02, power=2.5
)

N_stones_L = 8
for k in range(N_stones_L):
    gap = 0.012
    a0 = 2.0 * math.pi * k / N_stones_L + gap
    a1 = 2.0 * math.pi * (k + 1) / N_stones_L - gap
    tile = 1 if (k % 2 == 0) else 0
    create_pillow_patch(
        f"Left_Round_Stone_{k}", 'left',
        lambda u, v, a0=a0, a1=a1: (
            Yc_L + (R_in_L + 0.012 + (R_out_L - R_in_L) * v) * math.cos(a0 + (a1 - a0) * u),
            Zc_L + (R_in_L + 0.012 + (R_out_L - R_in_L) * v) * math.sin(a0 + (a1 - a0) * u)
        ),
        12, 10, height_max=0.095, tile_idx=tile, mat=mat_detail, sink_depth=-0.02, power=2.6
    )

# ==============================================================================
# 7. Build Arch Window Helper with Smooth Continuous Wood Rim
# ==============================================================================
def arch_point(u_center, z_base, w_half, h_rect, t_param):
    if t_param <= 0.32:
        s = t_param / 0.32
        return u_center - w_half, z_base + s * h_rect, -1.0, 0.0
    elif t_param >= 0.68:
        s = (1.0 - t_param) / 0.32
        return u_center + w_half, z_base + s * h_rect, 1.0, 0.0
    else:
        s = (t_param - 0.32) / 0.36
        ang = math.pi * (1.0 - s)
        return u_center + w_half * math.cos(ang), z_base + h_rect + w_half * math.sin(ang), math.cos(ang), math.sin(ang)

def build_storybook_arch_window(prefix, wall_side, u_center, z_base, w_half, h_rect, stone_thick=0.125, sill_w=0.40, sill_h=0.095, add_corbels=True):
    def interior_map(u, v, pad=0.0):
        x_rel = (2.0 * u - 1.0) * (w_half + pad)
        z_top = z_base + h_rect + math.sqrt(max(0.0, (w_half + pad)**2 - x_rel**2))
        z_bot = z_base - pad * 0.3
        return (u_center + x_rel, z_bot + v * (z_top - z_bot))

    create_pillow_patch(
        f"{prefix}_Backing", wall_side,
        lambda u, v: interior_map(u, v, pad=0.025),
        14, 18, height_max=0.024, tile_idx=7, mat=mat_detail, sink_depth=-0.025, power=4.0
    )

    create_pillow_patch(
        f"{prefix}_Glass", wall_side,
        lambda u, v: interior_map(u, v, pad=-0.015),
        16, 20, height_max=0.052, tile_idx=5, mat=mat_glass, sink_depth=0.012, power=2.2
    )

    def wood_rim_map(u, v):
        px, pz, nx, nz = arch_point(u_center, z_base, w_half - 0.022, h_rect, u)
        r_off = v * 0.048
        return (px + nx * r_off, pz + nz * r_off)

    create_pillow_patch(
        f"{prefix}_WoodRim", wall_side, wood_rim_map,
        48, 8, height_max=0.072, tile_idx=3, mat=mat_detail, sink_depth=0.012, power=2.2, periodic_u=True
    )

    h_total = h_rect + w_half
    create_pillow_patch(
        f"{prefix}_Mullion_V", wall_side,
        lambda u, v: (u_center + (2*u - 1) * 0.022, z_base + v * (h_total - 0.012)),
        6, 18, height_max=0.068, tile_idx=4, mat=mat_detail, sink_depth=0.018, power=2.5
    )
    for k_bar, z_frac in enumerate([0.36, 0.70]):
        zbar = z_base + z_frac * h_total
        if zbar <= z_base + h_rect:
            hw = w_half - 0.008
        else:
            hw = math.sqrt(max(0.01, w_half**2 - (zbar - (z_base + h_rect))**2))
        create_pillow_patch(
            f"{prefix}_Mullion_H_{k_bar}", wall_side,
            lambda u, v, zbar=zbar, hw=hw: (u_center + (2*u - 1) * hw, zbar + (2*v - 1) * 0.020),
            14, 6, height_max=0.066, tile_idx=4, mat=mat_detail, sink_depth=0.018, power=2.5
        )

    n_stones = 9
    for k in range(n_stones):
        gap = 0.003
        t0 = k / n_stones + gap
        t1 = (k + 1) / n_stones - gap
        tile = 1 if (k % 2 == 1) else 0
        def stone_map(u, v, t0=t0, t1=t1):
            t = t0 + (t1 - t0) * u
            px, pz, nx, nz = arch_point(u_center, z_base, w_half + 0.008, h_rect, t)
            r_off = v * stone_thick
            return (px + nx * r_off, pz + nz * r_off)
        create_pillow_patch(
            f"{prefix}_ArchStone_{k}", wall_side, stone_map,
            10, 10, height_max=0.095, tile_idx=tile, mat=mat_detail, sink_depth=-0.022, power=2.6
        )

    if sill_w > 0:
        z_sill_top = z_base + 0.012
        z_sill_bot = z_sill_top - sill_h
        create_pillow_patch(
            f"{prefix}_Sill", wall_side,
            lambda u, v: (u_center + (2*u - 1) * sill_w, z_sill_bot + v * sill_h),
            20, 10, height_max=0.125, tile_idx=3, mat=mat_detail, sink_depth=-0.025, power=2.6
        )
        if add_corbels:
            for c_idx, u_off in enumerate([-sill_w * 0.56, sill_w * 0.56]):
                create_pillow_patch(
                    f"{prefix}_Corbel_{c_idx}", wall_side,
                    lambda u, v, u_off=u_off: (
                        u_center + u_off + (2*u - 1) * 0.056 * (0.65 + 0.35 * v),
                        z_sill_bot - 0.115 + v * 0.125
                    ),
                    8, 10, height_max=0.098, tile_idx=3, mat=mat_detail, sink_depth=-0.025, power=2.5
                )

# 8. Build RIGHT Wall (+X): Tall Narrow Arched Window (窄拱窗)
build_storybook_arch_window(
    prefix="Right_Window",
    wall_side='right',
    u_center=0.05,
    z_base=1.18,
    w_half=0.165,
    h_rect=0.45,
    stone_thick=0.115,
    sill_w=0.33,
    sill_h=0.090,
    add_corbels=True
)

# 9. Build BACK Wall (+Y): Twin Arched Windows + Corbels + 2 Base Stones
for idx, x_win in enumerate([-0.55, 0.55]):
    build_storybook_arch_window(
        prefix=f"Back_Window_{idx}",
        wall_side='back',
        u_center=x_win,
        z_base=1.74,
        w_half=0.22,
        h_rect=0.37,
        stone_thick=0.12,
        sill_w=0.38,
        sill_h=0.092,
        add_corbels=True
    )

for idx, (x_st, w_st, h_st, tile_st) in enumerate([(-0.92, 0.25, 0.12, 2), (-0.08, 0.16, 0.135, 1)]):
    create_pillow_patch(
        f"Back_Base_Stone_{idx}", 'back',
        lambda u, v, x_st=x_st, w_st=w_st, h_st=h_st: (x_st + (2*u - 1) * w_st, 0.02 + v * h_st),
        14, 10, height_max=0.072, tile_idx=tile_st, mat=mat_detail, sink_depth=-0.022, power=2.6
    )

# ==============================================================================
# 10. Sculpt 3D Tilted C-Shaped Golden Crescent Moon & Pedestal Orb on Sculpted Roof Peak
# ==============================================================================
base_cx, base_cy, base_cz = neck_center.x, neck_center.y, neck_center.z + 0.01

finial_verts = []
finial_uvs = []
finial_faces = []

nu_f, nv_f = 28, 16
for j in range(nv_f + 1):
    v = j / nv_f
    ang_v = math.pi * (v - 0.5)
    z_orb = base_cz + 0.075 * math.sin(ang_v)
    r_orb = 0.086 * math.cos(ang_v) + 0.022 * (1.0 - v)**2
    for i in range(nu_f + 1):
        u = i / nu_f
        ang_u = 2.0 * math.pi * u
        finial_verts.append((base_cx + r_orb * math.cos(ang_u), base_cy + r_orb * math.sin(ang_u), z_orb))
        finial_uvs.append(tile_uv(6, u, v))

for j in range(nv_f):
    for i in range(nu_f):
        v0 = j * (nu_f + 1) + i
        finial_faces.append((v0, v0 + 1, v0 + (nu_f + 1) + 1, v0 + (nu_f + 1)))

c_offset = len(finial_verts)
nu_c, nv_c = 40, 20
moon_cx, moon_cy, moon_cz = base_cx + 0.01, base_cy, base_cz + 0.235
R_major = 0.165
tilt_rad = math.radians(-30.0)
cos_t, sin_t = math.cos(tilt_rad), math.sin(tilt_rad)

for j in range(nv_c + 1):
    v = j / nv_c
    s = 2.0 * v - 1.0
    ang_s = s * math.radians(122.0)
    taper = math.cos(s * math.pi * 0.5) ** 0.72
    r_sec_x = 0.068 * taper + 0.004
    r_sec_y = 0.052 * taper + 0.004
    cx_local = R_major * math.cos(ang_s) - 0.022 * taper
    cz_local = R_major * math.sin(ang_s)
    nx_local = math.cos(ang_s)
    nz_local = math.sin(ang_s)
    for i in range(nu_c + 1):
        u = i / nu_c
        ang_u = 2.0 * math.pi * u
        px_u = cx_local + r_sec_x * math.cos(ang_u) * nx_local
        pz_u = cz_local + r_sec_x * math.cos(ang_u) * nz_local
        py_u = r_sec_y * math.sin(ang_u)
        rx = px_u * cos_t - pz_u * sin_t
        rz = px_u * sin_t + pz_u * cos_t
        finial_verts.append((moon_cx + rx, moon_cy + py_u, moon_cz + rz))
        finial_uvs.append(tile_uv(6, u, v))

for j in range(nv_c):
    for i in range(nu_c):
        v0 = c_offset + j * (nu_c + 1) + i
        finial_faces.append((v0, v0 + 1, v0 + (nu_c + 1) + 1, v0 + (nu_c + 1)))

finial_mesh = bpy.data.meshes.new("Finial_Gold_Crescent")
finial_mesh.from_pydata(finial_verts, [], finial_faces)
bm = bmesh.new()
bm.from_mesh(finial_mesh)
bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
bm.to_mesh(finial_mesh)
bm.free()
for poly in finial_mesh.polygons:
    poly.use_smooth = True
uv_layer = finial_mesh.uv_layers.new(name="UVMap")
for poly in finial_mesh.polygons:
    for loop_idx in poly.loop_indices:
        uv_layer.data[loop_idx].uv = finial_uvs[finial_mesh.loops[loop_idx].vertex_index]
finial_mesh.materials.append(mat_gold)
finial_obj = bpy.data.objects.new("Finial_Gold_Crescent", finial_mesh)
bpy.context.collection.objects.link(finial_obj)
detail_objects.append(finial_obj)

# ==============================================================================
# 11. Export Final Refined GLB & Save .blend
# ==============================================================================
bpy.context.view_layer.update()
out_glb = OUT_DIR / "B8_balcony_house_refined.glb"
out_blend = OUT_DIR / "B8_balcony_house_refined.blend"

bpy.ops.export_scene.gltf(
    filepath=str(out_glb),
    export_format='GLB',
    export_apply=True
)
bpy.ops.wm.save_as_mainfile(filepath=str(out_blend))

# ==============================================================================
# 12. Render 6 Studio Views via GPU CYCLES + OpenImageDenoise
# ==============================================================================
scene = bpy.context.scene
scene.render.engine = 'CYCLES'
scene.cycles.device = 'GPU'
try:
    prefs = bpy.context.preferences.addons['cycles'].preferences
    prefs.compute_device_type = 'OPTIX'
    prefs.get_devices()
    for d in prefs.devices:
        d.use = True
except Exception:
    pass

scene.cycles.samples = 96
scene.cycles.use_denoising = True
scene.cycles.use_adaptive_sampling = True
scene.render.resolution_x = 1024
scene.render.resolution_y = 1024
scene.render.film_transparent = False
scene.view_settings.view_transform = 'Standard'
scene.view_settings.look = 'None'
scene.view_settings.exposure = 0.05

world = bpy.data.worlds.new("WarmStudioWorld")
scene.world = world
world.use_nodes = True
bg_node = world.node_tree.nodes.get("Background")
bg_node.inputs[0].default_value = (0.95, 0.91, 0.86, 1.0)
bg_node.inputs[1].default_value = 0.95

def add_area_light(name, loc, target, energy, size, color):
    ldata = bpy.data.lights.new(name=name, type='AREA')
    ldata.energy = energy
    ldata.size = size
    ldata.color = color
    lobj = bpy.data.objects.new(name=name, object_data=ldata)
    bpy.context.collection.objects.link(lobj)
    lobj.location = loc
    direction = Vector(target) - Vector(loc)
    lobj.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()
    return lobj

add_area_light("KeyLight",  (-6.5, -6.5, 7.5), (0, 0, 2.5), 420.0, 9.0, (1.0, 0.96, 0.90))
add_area_light("FillLight", (6.5, -5.5, 5.5),  (0, 0, 2.3), 260.0, 10.0, (0.95, 0.97, 1.0))
add_area_light("BackKey",   (-4.5, 7.0, 6.8),  (0, 0, 2.5), 360.0, 9.0, (1.0, 0.96, 0.90))
add_area_light("BackFill",  (5.5, 6.0, 5.0),   (0, 0, 2.2), 230.0, 10.0, (0.96, 0.97, 1.0))
add_area_light("BotBounce", (0.0, 0.0, -4.5),  (0, 0, 2.5), 140.0, 11.0, (0.98, 0.92, 0.84))

cam_data = bpy.data.cameras.new("RenderCam")
cam_obj = bpy.data.objects.new("RenderCam", cam_data)
bpy.context.collection.objects.link(cam_obj)
scene.camera = cam_obj

def look_at(obj, loc, target):
    obj.location = loc
    direction = Vector(target) - Vector(loc)
    obj.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()

views = [
    ("render_front.png", (0.0, -9.5, 2.62), (0.0, 0.0, 2.62), 'ORTHO', 5.85),
    ("render_left.png",  (-9.5, 0.0, 2.62), (0.0, 0.0, 2.62), 'ORTHO', 5.85),
    ("render_back.png",  (0.0,  9.5, 2.62), (0.0, 0.0, 2.62), 'ORTHO', 5.85),
    ("render_right.png", (9.5,  0.0, 2.62), (0.0, 0.0, 2.62), 'ORTHO', 5.85),
    ("render_hero.png",  (-6.2, -6.8, 3.95), (0.0, 0.0, 2.48), 'PERSP', 46.0),
    ("render_below.png", (5.5, -6.0, 0.65),  (0.0, 0.0, 2.55), 'PERSP', 44.0),
]

for fname, loc, tgt, mode, param in views:
    look_at(cam_obj, loc, tgt)
    cam_data.type = mode
    if mode == 'ORTHO':
        cam_data.ortho_scale = param
    else:
        cam_data.lens = param
    scene.render.filepath = str(OUT_DIR / fname)
    bpy.ops.render.render(write_still=True)

print("ALL DONE:", out_glb)
