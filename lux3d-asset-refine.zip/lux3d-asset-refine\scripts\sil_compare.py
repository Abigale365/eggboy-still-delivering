"""把 sil_render.py 渲出的轮廓和参考图四视图对比，给出数字和叠加图。

python sil_compare.py <参考.png> <前缀> [输出前缀]
读 <前缀>_front.png / <前缀>_back.png，输出：
  - 轮廓 IoU
  - “顶部轮廓线”逐列误差（像素；屋檐/屋脊走样、扭曲会直接体现为误差大）
  - <输出前缀>_overlay_front.png / _back.png：绿=参考，红=模型，黄=重合
窗口要和 sil_render.py 的 VIEWS 一致。
"""
import sys

import numpy as np
from PIL import Image

ref_path, prefix = sys.argv[1], sys.argv[2]
outp = sys.argv[3] if len(sys.argv) > 3 else prefix
WIN = {"front": (0, 720, 0, 640), "back": (0, 700, 640, 1254)}

ref = np.asarray(Image.open(ref_path).convert("RGBA"), dtype=np.float32)[:, :, 3] / 255.0
res = {}
for name, (u0, u1, v0, v1) in WIN.items():
    R = ref[v0:v1, u0:u1] > 0.9
    M = np.asarray(Image.open(f"{prefix}_{name}.png").convert("RGBA"))[:, :, 3] > 127
    h = min(R.shape[0], M.shape[0]); w = min(R.shape[1], M.shape[1])
    R, M = R[:h, :w], M[:h, :w]
    inter, union = (R & M).sum(), (R | M).sum()
    # 顶部轮廓：每列第一个不透明像素
    def top(mask):
        has = mask.any(0)
        t = np.where(has, mask.argmax(0), -1)
        return t
    tr, tm = top(R), top(M)
    ok = (tr >= 0) & (tm >= 0)
    d = np.abs(tr - tm)[ok]
    cols = np.where(ok)[0]
    worst = cols[np.argsort(-np.abs(tr - tm)[ok])[:3]]
    res[name] = (inter / union, d.mean(), np.percentile(d, 95), d.max(), worst.tolist())
    print(f"{name:5s} IoU={inter/union:.3f}  顶轮廓误差 均值={d.mean():.1f}px  95%={np.percentile(d,95):.1f}px  最大={d.max():.0f}px  最差列(u)={worst.tolist()}")
    img = np.zeros((h, w, 3), np.uint8)
    img[R & ~M] = (60, 200, 60); img[M & ~R] = (230, 50, 50); img[R & M] = (235, 215, 70)
    Image.fromarray(img).save(f"{outp}_overlay_{name}.png")
