"""Blender 侧脚本共用：读 GLB 的节点原始姿态。

Blender 导入 GLB 时会把第一段动画套上去，物体就不在“静止姿态”了（比如门被拉回 0°）。
验收渲染和功能检查都要先调用 restore_rest_pose，把带动画的节点恢复成文件里写的姿态。
"""
import json
import struct

import bpy
from mathutils import Matrix, Quaternion, Vector
from common import read_glb_chunks


def glb_json(path):
    return read_glb_chunks(path)[0]


def restore_rest_pose(glb_path):
    j = glb_json(glb_path)
    nodes = {nd.get("name"): nd for nd in j.get("nodes", [])}
    for o in bpy.context.scene.objects:
        if not o.animation_data:
            continue
        nd = nodes.get(o.name) or nodes.get(o.name.split(".")[0])
        o.animation_data_clear()
        if not nd:
            continue
        # glTF（Y 朝上）→ Blender（Z 朝上）：(x, y, z) → (x, -z, y)
        if "matrix" in nd:
            raw = nd["matrix"]
            local = Matrix([raw[i:i + 4] for i in range(0, 16, 4)]).transposed()
            basis = Matrix(((1, 0, 0, 0), (0, 0, -1, 0), (0, 1, 0, 0), (0, 0, 0, 1)))
            o.matrix_basis = basis @ local @ basis.inverted()
            continue
        x, y, z = nd.get("translation", (0, 0, 0)); o.location = Vector((x, -z, y))
        o.rotation_mode = "QUATERNION"
        if "rotation" in nd:
            x, y, z, w = nd["rotation"]; o.rotation_quaternion = Quaternion((w, x, -z, y))
        else:
            o.rotation_quaternion = Quaternion()
        x, y, z = nd.get("scale", (1, 1, 1)); o.scale = Vector((x, z, y))
    bpy.context.view_layer.update()
