# 可分解 3D 展示（参考 elvarofficial/teardown 的做法）

把精修后的 GLB 做成**一个离线 HTML**：可拖拽旋转/缩放、按部件组一键拆开（屋顶/阳台/门窗/基座/墙体）、
分解滑块、自动演示（合拢→展开→回收，任意操作接管，25 秒无操作恢复）。

构建（Node 20+）：
    npm i three@0.170.0 esbuild
    # 把 build_viewer.mjs 里的 /tmp/b8.glb 改成你的 GLB 路径，viewer_main.js 放同目录并改名 main.js
    node build_viewer.mjs        # -> out/*.html

部件分组靠 GLB 节点名的正则（viewer_main.js 顶部 GROUPS）。精修时给节点起有意义的英文名，分解效果才好。
展示规则（取自 teardown）：先看参考再动手；浅色背景 + 单一强调色；部件分层要“看得出原因”；
截图审查：用无头浏览器暂停动画后逐帧截图（window.__freeze / __setExplode / __setCam / __renderOnce）。

## 带贴图的纯查看器（默认交付物）
`textured_viewer_main.js` + `build_textured_viewer.mjs`：一个离线 HTML，模型内嵌，拖拽旋转/滚轮缩放/右键平移，空闲时自动慢转，
不做色调压缩（贴图颜色原样），状态栏显示“N/M 个材质带贴图”，用来一眼确认不是白膜。
构建：npm i three@0.170.0 esbuild；node build_textured_viewer.mjs "标题" out/viewer.html model.glb
（把 textured_viewer_main.js 复制成 main.js 放同目录）。用户要“看 3D”时先交这个；拆解面板只在用户要求时再用。
