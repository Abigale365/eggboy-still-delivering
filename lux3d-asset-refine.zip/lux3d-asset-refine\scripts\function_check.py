"""Blender: check declared functions in world coordinates; bind results to inputs.

blender -b --factory-startup -P function_check.py -- model.glb asset.json output.json
"""
import json
import math
import os
import sys
from pathlib import Path

import bpy
from mathutils import Quaternion, Vector
from mathutils.bvhtree import BVHTree

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bl_common import restore_rest_pose
from common import FUNCTION_KINDS, function_inputs, load_asset, read_accessor, read_glb_chunks


def descendants(obj):
    found = []
    for child in obj.children:
        found.extend([child, *descendants(child)])
    return found


def world_bvh(obj):
    """Trees and triangle centers share world coordinates, including parent transforms."""
    evaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
    mesh = evaluated.to_mesh()
    try:
        mesh.calc_loop_triangles()
        vertices = [evaluated.matrix_world @ v.co for v in mesh.vertices]
        triangles = [tuple(t.vertices) for t in mesh.loop_triangles]
        centers = [sum((vertices[i] for i in tri), Vector()) / 3 for tri in triangles]
        return BVHTree.FromPolygons(vertices, triangles, all_triangles=True), centers
    finally:
        evaluated.to_mesh_clear()


def animation_check(document, binary, node_name, clips):
    node_indices = {i for i, n in enumerate(document.get("nodes", [])) if n.get("name") == node_name}
    if not isinstance(clips, list) or len(clips) != 2:
        return False, "需要明确的开、关两段动画"
    problems = []
    for clip in clips:
        animation = next((a for a in document.get("animations", []) if a.get("name") == clip), None)
        if not animation:
            problems.append(f"缺 {clip}")
            continue
        channels = [c for c in animation.get("channels", [])
                    if c.get("target", {}).get("node") in node_indices and c["target"].get("path") == "rotation"]
        moving = False
        for channel in channels:
            sampler = animation["samplers"][channel["sampler"]]
            times = read_accessor(document, binary, sampler["input"])
            rotations = read_accessor(document, binary, sampler["output"])
            if sampler.get("interpolation") == "CUBICSPLINE":
                rotations = rotations[1::3]
            if len(times) >= 2 and times[-1][0] > times[0][0] and len(rotations) >= 2:
                first = Quaternion((rotations[0][3], *rotations[0][:3]))
                moving |= any(first.rotation_difference(Quaternion((q[3], *q[:3]))).angle > 1e-4 for q in rotations[1:])
        if not moving:
            problems.append(f"{clip} 没有驱动该转轴的有效转动")
    return not problems, "；".join(problems) if problems else "有且驱动转轴：" + "、".join(clips)


def collision_check(obj, hinge, fn):
    moving = [m for m in descendants(obj) if m.type == "MESH"]
    if not moving:
        return False, "转轴下面没有会动的网格"
    excluded = set(fn.get("ignore_meshes", []))
    test = [m for m in moving if "knuckle" not in m.name.lower() and m.name not in excluded]
    if not test:
        return False, "没有可检测的活动网格，不能以空检查判通过"
    others = [m for m in bpy.context.scene.objects if m.type == "MESH" and m not in moving
              and not m.name.startswith("COL_") and m.name not in excluded]
    axis = Vector(tuple(float(a == hinge["axis_blender"]) for a in "xyz"))
    sign = float(hinge.get("sign_blender", hinge.get("sign", 1)))
    rest = obj.rotation_quaternion.copy()
    base = rest @ Quaternion(axis, -math.radians(float(hinge.get("rest_deg", 0))) * sign)
    step = float(fn.get("collision_step_deg", 2))
    ignore = float(fn.get("axis_ignore_m", 0.04))
    if not 0 < step <= 10 or not 0 <= ignore <= 0.1:
        return False, "collision_step_deg 需在 (0,10]，axis_ignore_m 需在 [0,0.1]"
    minimum, maximum = float(hinge["min_deg"]), float(hinge["max_deg"])
    count = max(2, math.ceil(abs(maximum - minimum) / step) + 1)
    static = [(m, world_bvh(m)[0]) for m in others]
    worst, bad_angles, worst_bounds = 0, [], None
    try:
        for i in range(count):
            deg = minimum + (maximum - minimum) * i / (count - 1)
            obj.rotation_quaternion = base @ Quaternion(axis, math.radians(deg) * sign)
            bpy.context.view_layer.update()
            pivot = obj.matrix_world.translation
            axis_world = (obj.matrix_world.to_3x3() @ axis).normalized()
            hits = []
            for mesh in test:
                tree, centers = world_bvh(mesh)
                for _, other in static:
                    for triangle, _ in tree.overlap(other):
                        point = centers[triangle]
                        radius = point - pivot
                        if (radius - axis_world * radius.dot(axis_world)).length > ignore:
                            hits.append(point)
            if hits:
                bad_angles.append(round(deg, 3))
            if len(hits) > worst:
                worst = len(hits)
                worst_bounds = [[min(p[a] for p in hits), max(p[a] for p in hits)] for a in range(3)]
    finally:
        obj.rotation_quaternion = rest
        bpy.context.view_layer.update()
    text = f"{minimum:g}°–{maximum:g}° 采样 {count} 个角度（步长 ≤ {step:g}°，合页轴附近忽略 {ignore:g} m）；"
    text += "未检出表面相交" if not worst else f"最多 {worst} 对三角形相交；角度：{bad_angles}；相交面中心范围：{worst_bounds}"
    return worst == 0, text


def main():
    glb, asset_path, output = [Path(a).resolve() for a in sys.argv[sys.argv.index("--") + 1:]]
    asset = load_asset(asset_path.parent)
    document, binary = read_glb_chunks(glb)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=str(glb))
    restore_rest_pose(str(glb))
    objects = {o.name: o for o in bpy.context.scene.objects}
    checks = []

    def add(fn, kind, ok, text):
        node = fn.get("node", fn["id"])
        checks.append({"function_id": fn["id"], "kind": kind, "item": f"{fn.get('desc', fn['id'])}（{node}） {kind}",
                       "pass": bool(ok), "value": text})

    for fn in asset.get("functions", []):
        node = fn.get("node", fn["id"])
        obj = objects.get(node)
        if obj is None:
            candidates = [o for name, o in objects.items() if name.rsplit(".", 1)[0] == node]
            obj = candidates[0] if len(candidates) == 1 else None
        add(fn, "node", obj is not None, "节点存在" if obj else "节点不存在或名字不唯一")
        if obj is None:
            for kind in FUNCTION_KINDS[fn["type"]][1:]:
                add(fn, kind, False, "节点不存在，无法检查")
            continue
        if fn["type"] == "hinge":
            raw = obj.get("hinge")
            h = dict(raw) if raw else {}
            valid = (obj.type == "EMPTY" and h.get("axis_blender") in ("x", "y", "z")
                     and h.get("sign_blender", h.get("sign", 1)) in (-1, 1)
                     and all(isinstance(h.get(k), (int, float)) and math.isfinite(h[k]) for k in ("min_deg", "max_deg", "rest_deg")))
            valid = valid and h["min_deg"] < h["max_deg"] and h["min_deg"] <= h["rest_deg"] <= h["max_deg"]
            valid = valid and all(k not in fn or abs(float(fn[k]) - h[k]) < 1e-4 for k in ("min_deg", "max_deg", "rest_deg"))
            add(fn, "hinge", valid, "转轴、角度范围、静止姿态有效且与配置一致" if valid else "转轴说明缺失、角度无效或与配置不符")
            ok, text = animation_check(document, binary, node, fn.get("clips", [f"{node}_open", f"{node}_close"]))
            add(fn, "animation", ok, text)
            ok, text = collision_check(obj, h, fn) if valid else (False, "转轴说明无效，无法检查")
            add(fn, "collision", ok, text)
        elif fn["type"] == "socket":
            add(fn, "socket", obj.type == "EMPTY", f"位置点类型 {obj.type}，世界位置 {tuple(round(v, 4) for v in obj.matrix_world.translation)}")
        elif fn["type"] == "collider":
            ok = obj.type == "MESH" and len(obj.data.polygons) > 0 and len(obj.data.vertices) >= 4
            add(fn, "collider", ok, f"{len(obj.data.polygons)} 个面" if obj.type == "MESH" else "不是网格")
        elif fn["type"] == "emissive":
            glowing = False
            for mesh in [obj, *descendants(obj)]:
                if mesh.type != "MESH":
                    continue
                for material in mesh.data.materials:
                    if not material or not material.use_nodes:
                        continue
                    shader = next((n for n in material.node_tree.nodes if n.type == "BSDF_PRINCIPLED"), None)
                    if shader:
                        strength = shader.inputs["Emission Strength"]
                        color = shader.inputs["Emission Color"]
                        glowing |= bool(strength.links or strength.default_value > 0) and bool(color.links or max(color.default_value[:3]) > 0)
            add(fn, "emissive", glowing, "有发光颜色/贴图与强度；亮度效果仍需看图" if glowing else "没有有效的发光材质")

    result = {"schema_version": 2, "inputs": function_inputs(glb, asset_path), "checks": checks,
              "sampling_note": "离散角度的网格表面相交检查，不等于连续碰撞或封闭体积包含检测"}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    for check in checks:
        print("FUNC", "过" if check["pass"] else "不过", check["item"], check["value"])


if __name__ == "__main__":
    main()
