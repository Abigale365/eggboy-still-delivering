"""从参考图的 alpha 通道提取“屋顶外轮廓线”，代替手填坐标。

用法（任意 Python，需要 numpy + pillow）：
    from profile_from_ref import top_profile
    pts = top_profile(ref_png, window=(u0,u1,v0,v1), skip_cols=[(120,230)], step=6)
返回 [(u, v_global), ...]，v 为整图坐标（像素），可直接喂给 rz() / roof_sweep.build_roof。

为什么：手填的 PROFILE_BACK 与背面参考图的真实屋顶轮廓差了 15~40 px（用 sil_compare.py 量出来的）。
          轮廓“量出来”而不是“估出来”，几何才能和参考一致。
skip_cols：要挖掉的列（烟囱、月牙等高出屋面的东西），这些列用两侧线性插值补上。
"""
import numpy as np


def _alpha(ref_png):
    """读 alpha 通道。普通 Python 用 PIL；Blender 自带 Python 没有 PIL，改用 bpy 读。"""
    try:
        from PIL import Image
        return np.asarray(Image.open(ref_png).convert("RGBA"))[:, :, 3] / 255.0
    except ImportError:
        import bpy
        img = bpy.data.images.load(str(ref_png), check_existing=False)
        w, h = img.size
        px = np.array(img.pixels[:], dtype=np.float32).reshape(h, w, 4)
        bpy.data.images.remove(img)
        return np.flipud(px)[:, :, 3]                    # bpy 的行序是自下而上


def top_profile(ref_png, window, skip_cols=(), step=6, thresh=230, smooth=5):
    u0, u1, v0, v1 = window
    a = _alpha(ref_png)[v0:v1, u0:u1] > thresh / 255.0
    top = np.where(a.any(0), a.argmax(0), -1).astype(float)
    us = np.arange(u0, u1)
    bad = top < 0
    for s, e in skip_cols:
        bad |= (us >= s) & (us <= e)
    good = ~bad
    top = np.interp(us, us[good], top[good])
    if smooth > 1:                                   # 去掉瓦片边缘的小锯齿，不改变大形
        k = np.ones(smooth) / smooth
        pad = np.pad(top, smooth // 2, mode="edge")
        top = np.convolve(pad, k, mode="valid")
    idx = list(range(0, len(us), step))
    if idx[-1] != len(us) - 1:
        idx.append(len(us) - 1)
    return [(int(us[i]), float(top[i] + v0)) for i in idx]
