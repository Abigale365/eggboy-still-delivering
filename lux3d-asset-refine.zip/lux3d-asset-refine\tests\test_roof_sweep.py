"""Blender 内运行：blender -b --factory-startup -P test_roof_sweep.py -- <输出png>
用 B8 的前檐剖面扫掠出屋顶，自检前后檐一致，并出一张斜视图。"""
import math, os, sys
import bpy
from mathutils import Vector

here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(here, "..", "scripts"))
from roof_sweep import build_roof, check_symmetry  # noqa

out = sys.argv[sys.argv.index("--") + 1]
S = 120.0
PF = [(55, 266), (110, 247), (180, 213), (250, 168), (320, 119), (375, 87), (418, 83),
      (452, 105), (488, 166), (527, 222), (570, 254), (606, 266), (634, 249)]
profile = [((u - 350) / S, (630 - v) / S) for u, v in PF]
depth = (-1.38, 1.38)
ok, worst = check_symmetry(profile, depth, 0.10, 0.30)
print("SYMMETRY", ok, worst)
assert ok, worst

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
mt = bpy.data.materials.new("tile"); mt.diffuse_color = (0.85, 0.38, 0.2, 1)
me = bpy.data.materials.new("eave"); me.diffuse_color = (0.95, 0.9, 0.8, 1)
for m, c in ((mt, (0.85, 0.38, 0.2, 1)), (me, (0.95, 0.9, 0.8, 1))):
    m.use_nodes = True
    m.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = c
    m.node_tree.nodes["Principled BSDF"].inputs["Roughness"].default_value = 0.55
parts = build_roof(profile, depth, thickness=0.11, eave_radius=0.12, sag=0.10, sides_lift=0.30,
                   mat_tile=mt, mat_eave=me)
# 一个简化墙体盒，只为看屋檐与墙的关系
# 墙体高度取剖面最低檐口高度，这样屋檐落在墙顶附近（B8 的剖面 z≈2.8~4.6）
_zmin = min(p[1] for p in profile)
bpy.ops.mesh.primitive_cube_add(size=1, location=(0.0, 0, (_zmin - 0.1) / 2))
w = bpy.context.object; w.scale = (4.6, 2.5, _zmin - 0.1)
wm = bpy.data.materials.new("wall"); wm.use_nodes = True
wm.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = (0.9, 0.82, 0.68, 1)
w.data.materials.append(wm)

sc.render.engine = "CYCLES"          # 无 GPU/EGL 的环境也能跑
sc.cycles.samples = 24
sc.cycles.use_denoising = True
sc.render.resolution_x, sc.render.resolution_y = 900, 700
sc.view_settings.view_transform = "Standard"
world = bpy.data.worlds.new("w"); sc.world = world; world.use_nodes = True
world.node_tree.nodes["Background"].inputs[0].default_value = (0.85, 0.9, 0.97, 1)
sun = bpy.data.objects.new("sun", bpy.data.lights.new("sun", "SUN")); sun.data.energy = 1.6; sc.view_settings.exposure = -0.6
sun.rotation_euler = (math.radians(50), 0, math.radians(30)); sc.collection.objects.link(sun)
cam = bpy.data.objects.new("cam", bpy.data.cameras.new("cam")); sc.collection.objects.link(cam); sc.camera = cam
cam.data.lens = 40
cam.location = (7.5, -9.5, 5.0)
cam.rotation_euler = (Vector((0, 0, 2.4)) - cam.location).to_track_quat("-Z", "Y").to_euler()
sc.render.filepath = out
bpy.ops.render.render(write_still=True)
print("TEST_DONE")
