"""验收：把模型和参考图逐项比，出 audit.json 和对比网页 report.html。

    python audit.py <工作目录> <模型.glb> <版本名> [--before=<旧版本名>] [--elev=8] [--no-render]

自动量的：外形（轮廓）、颜色、体量（面数 / 贴图），以及 function_check.py 的结果（如果有）。
要看图判断的：关键部件、破损——写在 audit-<版本名>/verdicts.json，第一次跑会按 asset.json 生成空模板，
agent 看完 report.html 里的图后填 pass / note，再跑一次（加 --no-render 省时间）就合进结论。
"""
import base64
import argparse
import io
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy import ndimage

sys.path.insert(0, str(Path(__file__).parent))
from common import (SCRIPTS, FUNCTION_KINDS, budget_for, load_asset, run_blender,
                    sha256_file, function_inputs, render_inputs)  # noqa: E402
from glb_stats import glb_stats  # noqa: E402
from glb_geom import provenance  # noqa: E402

H = 800
VIEWS = ("front", "left", "back", "right")
VIEW_CN = {"front": "正面", "left": "左侧", "back": "背面", "right": "右侧"}
SHAPE_P95_MAX = 0.05     # 轮廓 95% 的点偏差不超过高度的 5%（对预览图；超了只记录，见下）
SHAPE_GROSS_MAX = 0.10   # 对预览图的外形偏差超过高度的 10% 才算严重跑偏、判失败；5%–10% 之间只记录
                         # （用户 2026-11-03 定的：以建模为准，和预览图的出入只写日志；预览图两张侧面常常本身就不一致）
COLOR_DE_MAX = 15.0      # 没有原版可比时：主要颜色和参考图的色差（CIE76 ΔE，参考图带光照，留一点余量）
ORIG_P95_MAX = 0.02      # 小手术：外形和原版比，95% 的轮廓点偏差不超过高度的 2%
ORIGIN_SHARE_MIN = 0.90  # 小手术：精修后表面至少 90%（按面积）贴着原版表面（新加 / 重做的部件要用户同意，且标 lux3d_origin=false）
COVERAGE_MIN = 0.90      # 小手术：原版表面至少 90% 还保留着（删掉、换掉原版部件会拉低）
ORIGIN_SURFACE_TOL = 0.006   # “贴着”的容差：高度的 0.6%（另加采样间距的 1.5 倍，见 glb_geom.provenance）
COLOR_STEP_MAX = 12.0    # 小手术调色：每个主色和原版比 ΔE 不超过 12（只挪一小步）
HUE_SHIFT_MAX = 10.0     # 调色后色相跑偏不超过 10°（保住原来的冷暖）


# ---------- 图像小工具 ----------
def ref_mask_rgb(path):
    im = Image.open(path).convert("RGBA")
    a = np.array(im)[:, :, 3]
    mask = a > 20
    rgb = Image.new("RGB", im.size, "white")
    rgb.paste(im, mask=im.split()[3])
    return mask, rgb


def glb_mask(render_dir, view):
    solid = np.array(Image.open(render_dir / f"solid_{view}.png").convert("L"))
    return solid > 6


def crop_fit(img, mask):
    ys, xs = np.nonzero(mask)
    if not len(xs):
        raise ValueError("图片没有可测量的有效主体")
    box = (xs.min(), ys.min(), xs.max() + 1, ys.max() + 1)
    w = round((box[2] - box[0]) * H / (box[3] - box[1]))
    im = img.crop(box).resize((w, H), Image.LANCZOS)
    m = Image.fromarray(mask.astype(np.uint8) * 255).crop(box).resize((w, H), Image.LANCZOS)
    return im, np.array(m) > 127


def on_canvas(arr, W):
    out = np.zeros((H, W), bool)
    off = (W - arr.shape[1]) // 2
    out[:, off:off + arr.shape[1]] = arr
    return out


def contour(m):
    return m & ~ndimage.binary_erosion(m)


def shape_metrics(ma, mb):
    W = max(ma.shape[1], mb.shape[1])
    A, B = on_canvas(ma, W), on_canvas(mb, W)
    ca, cb = contour(A), contour(B)
    da = ndimage.distance_transform_edt(~cb)[ca]
    db = ndimage.distance_transform_edt(~ca)[cb]
    d = np.concatenate([da, db]) / H
    iou = (A & B).sum() / max((A | B).sum(), 1)
    return {"p95": float(np.percentile(d, 95)), "mean": float(d.mean()), "iou": float(iou),
            "aspect_ref": ma.shape[1] / H, "aspect_glb": mb.shape[1] / H}, A, B


def outline_overlay(A, B):
    W = A.shape[1]
    img = Image.new("RGB", (W, H), "white")
    img.paste((228, 228, 228), mask=Image.fromarray(A.astype(np.uint8) * 255))
    for m, col in ((A, (200, 0, 0)), (B, (0, 70, 220))):
        e = Image.fromarray(contour(m).astype(np.uint8) * 255).filter(ImageFilter.MaxFilter(3))
        img.paste(col, mask=e)
    return img


def srgb_to_lab(rgb):
    c = rgb / 255.0
    c = np.where(c > 0.04045, ((c + 0.055) / 1.055) ** 2.4, c / 12.92)
    xyz = c @ np.array([[0.4124, 0.3576, 0.1805], [0.2126, 0.7152, 0.0722], [0.0193, 0.1192, 0.9505]]).T
    xyz /= [0.95047, 1.0, 1.08883]
    f = np.where(xyz > 0.008856, np.cbrt(xyz), 7.787 * xyz + 16 / 116)
    return np.stack([116 * f[:, 1] - 16, 500 * (f[:, 0] - f[:, 1]), 200 * (f[:, 1] - f[:, 2])], 1)


def kmeans(lab, k, iters=25, seed=0):
    if not len(lab):
        raise ValueError("没有可比较的颜色像素")
    k = min(k, len(lab))
    rng = np.random.default_rng(seed)
    cen = lab[rng.choice(len(lab), k, replace=False)]
    for _ in range(iters):
        lbl = ((lab[:, None] - cen[None]) ** 2).sum(2).argmin(1)
        cen = np.array([lab[lbl == i].mean(0) if (lbl == i).any() else cen[i] for i in range(k)])
    w = np.bincount(lbl, minlength=k) / len(lbl)
    return cen, w


def lab_to_rgb_hex(lab):
    L, a, b = lab
    fy = (L + 16) / 116
    fx, fz = fy + a / 500, fy - b / 200
    f = np.array([fx, fy, fz])
    xyz = np.where(f ** 3 > 0.008856, f ** 3, (f - 16 / 116) / 7.787) * [0.95047, 1.0, 1.08883]
    m = np.array([[3.2406, -1.5372, -0.4986], [-0.9689, 1.8758, 0.0415], [0.0557, -0.2040, 1.0570]])
    c = m @ xyz
    c = np.where(c > 0.0031308, 1.055 * np.clip(c, 0, None) ** (1 / 2.4) - 0.055, 12.92 * c)
    r, g, bb = (np.clip(c, 0, 1) * 255).astype(int)
    return f"#{r:02x}{g:02x}{bb:02x}"


def _sample_lab(px, n=40000):
    rng = np.random.default_rng(1)
    return srgb_to_lab(px[rng.choice(len(px), min(n, len(px)), replace=False)].astype(float))


def hue_deg(lab):
    return float(np.degrees(np.arctan2(lab[2], lab[1])) % 360)


def ref_colors_at(rrgb, rmask, omask, sel):
    """原版渲染图里被选中的每个像素，在**对齐后的同一个位置**上预览图是什么颜色。

    对齐方式和外形比较一样：各自裁到主体外框、缩到同高、水平居中。
    返回 (N, 3) 的 float，N = sel 里 True 的个数、顺序和 `img[sel]` 一致；对不上的像素
    （落在预览图主体外、或离预览图边缘 3 像素以内）是 NaN。
    omask 是原版主体的遮罩（决定外框），sel 是要取的像素。"""
    ra, ram = crop_fit(rrgb, rmask)
    ys, xs = np.nonzero(omask)
    if not len(xs):
        raise ValueError("原版渲染没有可测量的有效主体")
    x0, y0, x1, y1 = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
    wo = round((x1 - x0) * H / (y1 - y0))
    sx_scale, sy_scale = wo / (x1 - x0), H / (y1 - y0)
    W = max(wo, ra.width)
    off_o, off_r = (W - wo) // 2, (W - ra.width) // 2
    py, px = np.nonzero(sel)
    rx = np.floor((px - x0 + 0.5) * sx_scale + off_o - off_r).astype(int)
    ry = np.floor((py - y0 + 0.5) * sy_scale).astype(int)
    inner = ndimage.binary_erosion(ram, iterations=3)
    ok = (rx >= 0) & (rx < ra.width) & (ry >= 0) & (ry < H)
    ok[ok] = inner[ry[ok], rx[ok]]
    out = np.full((len(px), 3), np.nan)
    out[ok] = np.array(ra.convert("RGB"))[ry[ok], rx[ok]]
    return out


def color_compare(ref_pixels, glb_pixels, orig_pixels=None, ref_at_orig=None):
    """参考图的颜色和模型的颜色比。

    没有原版时（诊断原版自己）：参考图占比 ≥8% 的主色，每个去模型里找最近的颜色，算 ΔE。
    给了原版像素时：glb_pixels 和 orig_pixels 必须是**逐像素一一对应**的（同一个相机、同样的像素位置）。
    做法：在原版像素里聚类，每块原版颜色算一行；这块颜色**在图上的位置**对应的预览图像素的平均色，
    就是它的参考色（ref_at_orig，按位置对齐，见 ref_colors_at；对不上的像素是 NaN）；
    再看这批像素在新版里变成了什么。这样追踪的永远是同一个部位，不会因为“颜色最接近”
    而把预览图上的亮布色配给原版里别的小色块。占物体像素 ≥8% 的原版色块才评。"""
    pairs = []
    if orig_pixels is not None and ref_at_orig is None:
        raise ValueError("和原版比颜色需要按位置对齐的预览图颜色（ref_at_orig）")
    if orig_pixels is None:
        rc, rw = kmeans(_sample_lab(ref_pixels), 5)
        gc, _ = kmeans(_sample_lab(glb_pixels), 7)
        for c, w in sorted(zip(rc, rw), key=lambda t: -t[1]):
            if w < 0.08:
                continue
            j = int(np.sqrt(((gc - c) ** 2).sum(1)).argmin())
            pairs.append({"ref": lab_to_rgb_hex(c), "glb": lab_to_rgb_hex(gc[j]), "share": round(float(w), 3),
                          "dE": round(float(np.linalg.norm(gc[j] - c)), 1)})
        return pairs
    if len(glb_pixels) != len(orig_pixels) or len(ref_at_orig) != len(orig_pixels):
        raise ValueError("追踪颜色需要新版、原版和对齐后的预览图颜色逐像素一一对应")
    idx = np.random.default_rng(1).choice(len(orig_pixels), min(300_000, len(orig_pixels)), replace=False)
    lo = srgb_to_lab(orig_pixels[idx].astype(float))
    ln = srgb_to_lab(glb_pixels[idx].astype(float))
    ref_rgb = np.asarray(ref_at_orig, float)[idx]
    has_ref = ~np.isnan(ref_rgb).any(1)
    lr = np.full_like(lo, np.nan)
    lr[has_ref] = srgb_to_lab(ref_rgb[has_ref])
    oc, _ = kmeans(lo[np.random.default_rng(2).choice(len(lo), min(40_000, len(lo)), replace=False)], 7)
    assign = ((lo[:, None, :] - oc[None]) ** 2).sum(2).argmin(1)
    # 预览图是带光的，同一块原版颜色在图上有亮面也有阴影面；取这块颜色所在位置上预览图的平均色当参考色，
    # 一块原版颜色只评一次。和参考图比的两边（原版、新版）也只取预览图对得上的那些像素。
    for k in range(len(oc)):
        members = assign == k
        share = members.sum() / len(assign)
        if share < 0.08 or members.sum() < 50:
            continue
        usable = members & has_ref
        if usable.sum() < 50:        # 这块颜色在预览图上几乎对不到位置，没法比，不硬凑
            continue
        o_mean, n_mean = lo[members].mean(0), ln[members].mean(0)
        o_cmp, n_cmp, ref_mean = lo[usable].mean(0), ln[usable].mean(0), lr[usable].mean(0)
        pairs.append({"ref": lab_to_rgb_hex(ref_mean), "glb": lab_to_rgb_hex(n_mean), "share": round(float(share), 3),
                      "dE": round(float(np.linalg.norm(n_cmp - ref_mean)), 1),
                      "orig": lab_to_rgb_hex(o_mean), "dE_orig_ref": round(float(np.linalg.norm(o_cmp - ref_mean)), 1),
                      "dE_new_orig": round(float(np.linalg.norm(n_mean - o_mean)), 1),
                      "hue_shift": round(abs((hue_deg(n_mean) - hue_deg(o_mean) + 180) % 360 - 180), 1),
                      "chroma_orig": round(float(np.hypot(o_mean[1], o_mean[2])), 1),
                      "ref_coverage": round(float(usable.sum() / members.sum()), 2)})
    pairs.sort(key=lambda p: -p["share"])
    return pairs


def b64(img, maxw=1400, q=84):
    if img.width > maxw:
        img = img.resize((maxw, round(img.height * maxw / img.width)), Image.LANCZOS)
    buf = io.BytesIO()
    img.convert("RGB").save(buf, "JPEG", quality=q)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()


def _font(size=20):
    from PIL import ImageFont
    for f in ("msyh.ttc", "simhei.ttf", "NotoSansCJK-Regular.ttc", "PingFang.ttc", "Arial Unicode.ttf"):
        try:
            return ImageFont.truetype(f, size)
        except OSError:
            pass
    return ImageFont.load_default()


def side_by_side(*imgs, gap=16, labels=None):
    h = max(i.height for i in imgs)
    W = sum(i.width for i in imgs) + gap * (len(imgs) - 1)
    top = 30 if labels else 0
    out = Image.new("RGB", (W, h + top), "white")
    x = 0
    d = ImageDraw.Draw(out)
    font = _font(20)
    for k, i in enumerate(imgs):
        out.paste(i, (x, top))
        if labels:
            d.text((x + 4, 3), labels[k], fill="black", font=font)
        x += i.width + gap
    return out


# ---------- 检查证据的完整性 ----------
def cache_matches(folder, expected):
    manifest = folder / "render.json"
    try:
        data = json.loads(manifest.read_text(encoding="utf-8-sig"))
        return (data.get("inputs") == expected
                and all((folder / f"{mode}_{view}.png").exists()
                        for mode in ("lit", "flat", "solid") for view in VIEWS))
    except (OSError, ValueError, TypeError):
        return False


def append_function_checks(checks, asset, glb, workdir, adir):
    if not asset.get("functions"):
        return
    fc = adir / "function-check.json"
    try:
        data = json.loads(fc.read_text(encoding="utf-8-sig"))
        if data.get("schema_version") != 2 or data.get("inputs") != function_inputs(glb, workdir / "asset.json"):
            raise ValueError("结果不对应当前 GLB、配置或检查器，请重跑 function_check.py")
        rows = data.get("checks", [])
        expected = {(fn["id"], kind) for fn in asset["functions"] for kind in FUNCTION_KINDS[fn["type"]]}
        actual = [(row.get("function_id"), row.get("kind")) for row in rows]
        if set(actual) != expected or len(actual) != len(set(actual)):
            raise ValueError("功能结果为空、不完整、重复或包含未声明的功能")
        if any(type(row.get("pass")) is not bool for row in rows):
            raise ValueError("功能结果缺少明确的布尔结论")
        checks.extend({"group": "能用", **row} for row in rows)
    except (OSError, ValueError, TypeError, KeyError) as exc:
        checks.append({"group": "能用", "item": "功能检查证据", "pass": False,
                       "value": f"缺失、过期或不完整：{exc}"})


def visual_verdicts(adir, asset, inputs):
    vf = adir / "verdicts.json"
    template = {"schema_version": 2, "inputs": inputs,
                "parts": {p["id"]: {"desc": p["desc"], "pass": None, "note": ""} for p in asset.get("parts", [])},
                "damage": {"desc": "乱洞、明显接缝、平折面在游戏镜头距离下不明显", "pass": None, "note": ""}}
    if vf.exists():
        old = json.loads(vf.read_text(encoding="utf-8-sig"))
        if old.get("inputs") == inputs:
            for pid, part in template["parts"].items():
                if pid in old.get("parts", {}):
                    part.update(old["parts"][pid])
            template["damage"].update(old.get("damage", {}))
        else:
            backup = adir / f"verdicts.previous-{sha256_file(vf)[:12]}.json"
            if not backup.exists():
                backup.write_bytes(vf.read_bytes())
    for row in [*template["parts"].values(), template["damage"]]:
        if type(row.get("pass")) not in (bool, type(None)):
            row["pass"] = None
            row["note"] = "原结论不是 true/false/null，请重新判断。 " + str(row.get("note", ""))
    vf.write_text(json.dumps(template, ensure_ascii=False, indent=2), encoding="utf-8")
    return template


# ---------- 主流程 ----------
def main():
    parser = argparse.ArgumentParser(description="验收 GLB 并生成逐项对比报告；原版诊断请用 --baseline")
    parser.add_argument("workdir", type=Path)
    parser.add_argument("glb", type=Path)
    parser.add_argument("label")
    parser.add_argument("--before")
    parser.add_argument("--orig", default="v0")
    parser.add_argument("--baseline", action="store_true")
    parser.add_argument("--elev", type=float)
    parser.add_argument("--resolution", type=int, default=1400)
    parser.add_argument("--no-render", action="store_true")
    options = parser.parse_args()
    workdir, glb, label = options.workdir.resolve(), options.glb.resolve(), options.label
    flags = {"before": options.before, "orig": options.orig, "no-render": options.no_render}
    asset = load_asset(workdir)
    baseline = options.baseline or label == options.orig
    elevation = options.elev if options.elev is not None else asset.get("audit_elevation", 8)
    resolution = options.resolution
    yaw = asset.get("yaw_fix_deg", 0)
    adir = workdir / f"audit-{label}"
    adir.mkdir(parents=True, exist_ok=True)
    rdir = adir / "renders"
    rinputs = render_inputs(glb, elevation, resolution, yaw)
    if options.no_render:
        if not cache_matches(rdir, rinputs):
            parser.error("--no-render 的渲染缓存缺失或已过期；去掉该参数重新渲染当前 GLB")
    else:
        run_blender(SCRIPTS / "render_views.py", glb, rdir, elevation, resolution, yaw)
    before = workdir / f"audit-{flags['before']}" / "renders" if flags.get("before") else None

    checks, views = [], {}
    original_glb = Path(asset["generated"]) if asset.get("generated") else None
    if baseline and (not original_glb or not original_glb.is_file() or sha256_file(original_glb) != sha256_file(glb)):
        checks.append({"group": "证据", "item": "原版诊断身份", "pass": False,
                       "value": "--baseline/v0 只能用于 asset.json.generated 指定的原版 GLB"})
    aligned = {}
    for v in VIEWS:
        if v not in asset.get("reference", {}):
            checks.append({"group": "外形", "item": f"{VIEW_CN[v]}参考图", "pass": False, "value": "缺少视图"})
            continue
        try:
            rmask, rrgb = ref_mask_rgb(asset["reference"][v])
            if not rmask.any():
                raise ValueError("没有有效主体")
        except (OSError, ValueError) as exc:
            checks.append({"group": "外形", "item": f"{VIEW_CN[v]}参考图", "pass": False, "value": str(exc)})
            continue
        gm = glb_mask(rdir, v)
        lit = Image.open(rdir / f"lit_{v}.png").convert("RGB")
        lit = Image.composite(lit, Image.new("RGB", lit.size, "white"), Image.fromarray(gm.astype(np.uint8) * 255))
        ra, ram = crop_fit(rrgb, rmask)
        ga, gam = crop_fit(lit, gm)
        met, A, B = shape_metrics(ram, gam)
        aligned[v] = (ra, ga)
        row = [ra, ga]
        labels = ["参考图", f"{label}"]
        if before and (before / f"solid_{v}.png").exists():
            bm = np.array(Image.open(before / f"solid_{v}.png").convert("L")) > 6
            bl = Image.open(before / f"lit_{v}.png").convert("RGB")
            bl = Image.composite(bl, Image.new("RGB", bl.size, "white"), Image.fromarray(bm.astype(np.uint8) * 255))
            row.insert(1, crop_fit(bl, bm)[0])
            labels.insert(1, flags["before"])
        row.append(outline_overlay(A, B))
        labels.append("轮廓：红=参考 蓝=模型")
        sbs = side_by_side(*row, labels=labels)
        sbs.save(adir / f"view_{v}.jpg", quality=85)      # 单独存一份，agent 直接看图用
        views[v] = {"metrics": met, "img": b64(sbs, 1800)}
        ok = met["p95"] <= SHAPE_P95_MAX
        checks.append({"group": "外形", "item": f"{VIEW_CN[v]}轮廓",
                       "value": f"95% 的轮廓点偏差 ≤ {met['p95']:.1%} 高度（平均 {met['mean']:.1%}，重合度 {met['iou']:.0%}）",
                       "pass": ok, "record_only": (not ok) and met["p95"] <= SHAPE_GROSS_MAX})

    # 改动量：和 Lux3D 原版比（--orig=原版的版本名，默认 v0）。小手术不该明显改外形
    orig = workdir / f"audit-{flags.get('orig', 'v0')}" / "renders"
    has_orig = (not baseline and original_glb is not None and original_glb.is_file()
                and cache_matches(orig, render_inputs(original_glb, elevation, resolution, yaw)))
    if not baseline and not has_orig:
        checks.append({"group": "改动量", "item": "原版基线", "pass": False,
                       "value": f"缺少当前原版及其有效渲染；先验收 asset.json.generated 为 {options.orig} --baseline"})
    if has_orig:
        for v in aligned:
            om = np.array(Image.open(orig / f"solid_{v}.png").convert("L")) > 6
            _, oam = crop_fit(Image.fromarray(om.astype(np.uint8) * 255).convert("RGB"), om)
            _, gam2 = crop_fit(Image.fromarray(glb_mask(rdir, v).astype(np.uint8) * 255).convert("RGB"), glb_mask(rdir, v))
            m2, _, _ = shape_metrics(oam, gam2)
            checks.append({"group": "改动量", "item": f"{VIEW_CN[v]}外形和原版比",
                           "value": f"95% 的轮廓点偏差 ≤ {m2['p95']:.1%} 高度（重合度 {m2['iou']:.0%}）",
                           "pass": m2["p95"] <= ORIG_P95_MAX})
    # 原件占比：不信节点上的标记，按几何量（glb_geom.provenance）。
    # 标记（lux3d_origin：true = 从原件改的，false = 新加的）只用来和几何互相核对。
    mn = [m for m in glb_stats(glb)["mesh_nodes"] if not str(m["name"]).startswith("COL_")]
    tags = {m["name"]: m["lux3d_origin"] for m in mn}
    untagged = [n for n, t in tags.items() if t is None]
    if not baseline:     # 没有基线也不能跳过来源检查
        try:
            height = float(asset["height_m"])
            prov = provenance(original_glb, glb, height, ORIGIN_SURFACE_TOL, float(asset.get("yaw_fix_deg", 0)))
        except Exception as exc:          # 读不了几何就按不通过处理，不放行
            prov = None
            checks.append({"group": "改动量", "item": "原件占比（几何，按表面积）", "pass": False,
                           "value": f"量不出来：{type(exc).__name__}: {exc}（需要 asset.json 的 height_m、asset.json.generated 指向原版 GLB，且 GLB 未压缩）"})
        if prov:
            far = sorted((n for n in prov["nodes"] if n["near"] < 0.9), key=lambda n: n["near"] * n["area_m2"] - n["area_m2"])
            val = (f"{prov['share']:.0%} 的表面离原版表面 ≤ {prov['tol_m'] * 1000:.0f} mm（下限 {ORIGIN_SHARE_MIN:.0%}）"
                   + ("；偏离原版的网格：" + "、".join(f"{n['name']}（只有 {n['near']:.0%} 贴着）" for n in far[:6]) if far else ""))
            checks.append({"group": "改动量", "item": "原件占比（几何，按表面积）", "value": val,
                           "pass": prov["share"] >= ORIGIN_SHARE_MIN})
            val = f"{prov['coverage']:.0%} 的原版表面还在（下限 {COVERAGE_MIN:.0%}）"
            if prov["lost"]:
                val += "；缺得最多的区域（米，缩放后的坐标）：" + "、".join(f"{l['center_m']} 占 {l['share_of_original']:.1%}" for l in prov["lost"])
            checks.append({"group": "改动量", "item": "原版表面保留率", "value": val, "pass": prov["coverage"] >= COVERAGE_MIN})
            liars = [n["name"] for n in prov["nodes"] if tags.get(n["name"]) is True and n["near"] < 0.5]
            val = "标记和几何一致"
            if untagged:
                val = f"没标 lux3d_origin 的网格：{'、'.join(untagged[:8])}{'…' if len(untagged) > 8 else ''}"
            if liars:
                val = f"标成原件、实际不贴原版的网格：{'、'.join(liars)}（标记不可信）"
            checks.append({"group": "改动量", "item": "来源标记和几何核对", "value": val,
                           "pass": not untagged and not liars})

    # 颜色：参考图（带光）对模型贴图原色（flat 渲染），四个方向的像素合在一起比。
    # 参考图带了暖光，贴图原色本来就该比它暗、比它饱和，所以不追求和参考图一样；
    # 有原版时主要看：和原版比只挪了一小步、离参考图没变远、色相没跑（保住暖色）
    rp, gp, op, rao = [], [], [], []
    for v in aligned:
        rmask, rrgb = ref_mask_rgb(asset["reference"][v])
        inner = ndimage.binary_erosion(rmask, iterations=3)
        rp.append(np.array(rrgb)[inner if inner.any() else rmask])
        fl = np.array(Image.open(rdir / f"flat_{v}.png").convert("RGBA"))
        if has_orig:
            # 同一个相机、同一个物体：只留两张图都有物体的像素，按同样的顺序排好，一一对应（逐像素追踪颜色用）
            fo = np.array(Image.open(orig / f"flat_{v}.png").convert("RGBA"))
            both = (fl[:, :, 3] > 200) & (fo[:, :, 3] > 200)
            gp.append(fl[:, :, :3][both])
            op.append(fo[:, :, :3][both])
            # 每个像素在预览图上对应位置的颜色（按位置对齐，不按颜色配）
            rao.append(ref_colors_at(rrgb, rmask, np.array(Image.open(orig / f"solid_{v}.png").convert("L")) > 6, both))
        else:
            gp.append(fl[:, :, :3][fl[:, :, 3] > 200])
    if not baseline and not has_orig:
        # 颜色只能和原版比：没有有效的原版基线就不给颜色结论，更不能退回去直接比参考图（参考图带光，会把颜色调白调冷）
        checks.append({"group": "颜色", "item": "和原版比", "pass": False,
                       "value": "没有有效的原版基线，不给颜色结论；先验收原版（--baseline）"})
        pairs = []
    else:
        pairs = (color_compare(np.concatenate(rp), np.concatenate(gp), np.concatenate(op) if op else None,
                               np.concatenate(rao) if rao else None) if rp else [])
    sw = lambda h: f'<span class="sw" style="background:{h}"></span>{h}'
    for p in pairs:
        if "orig" in p:
            ok = (p["dE_new_orig"] <= COLOR_STEP_MAX and p["dE"] <= p["dE_orig_ref"]
                  and (p["chroma_orig"] < 8 or p["hue_shift"] <= HUE_SHIFT_MAX))
            val = (f'参考 {sw(p["ref"])} ｜ 原版 {sw(p["orig"])} → 现在 {sw(p["glb"])}；'
                   f'和原版差 ΔE {p["dE_new_orig"]}（上限 {COLOR_STEP_MAX}），离参考 ΔE {p["dE_orig_ref"]} → {p["dE"]}，色相变了 {p["hue_shift"]}°；预览图上对得上位置的像素占 {p["ref_coverage"]:.0%}')
        else:
            ok = p["dE"] <= COLOR_DE_MAX
            val = f'参考 {sw(p["ref"])} → 模型 {sw(p["glb"])}，ΔE {p["dE"]}'
        checks.append({"group": "颜色", "item": f"主色（占 {p['share']:.0%}）", "value": val, "pass": ok})

    # 体量
    st = glb_stats(glb)
    budget = budget_for(asset)
    vis = sum(m["triangles"] for m in st["mesh_nodes"] if not str(m["name"]).startswith("COL_"))
    checks.append({"group": "体量", "item": "三角面（不算碰撞体）", "value": f"{vis:,}（预算 {budget:,}）", "pass": vis <= budget})
    big = [t for t in st["textures"] if max(t["size"]) > 2048 or t.get("error") or min(t["size"]) <= 0]
    checks.append({"group": "体量", "item": "贴图", "value": "；".join(f"{t['size'][0]}×{t['size'][1]} {t['mime']} {t['bytes'] / 1e6:.1f} MB" for t in st["textures"]) or "无",
                   "pass": not big and st["texture_bytes"] <= 12e6})
    checks.append({"group": "体量", "item": "文件大小", "value": f"{st['file_bytes'] / 1e6:.1f} MB", "pass": st["file_bytes"] <= 20e6})

    # 功能（function_check.py 的结果）
    if not baseline:
        append_function_checks(checks, asset, glb, workdir, adir)

    # 看图判断的项目
    verdicts = visual_verdicts(adir, asset, {"glb_sha256": rinputs["glb_sha256"],
                                         "asset_sha256": sha256_file(workdir / "asset.json"),
                                         "renders": rinputs})
    for pid, p in verdicts["parts"].items():
        # 关键部件是对预览图的看图判断：没做到只记录（修不了的写“下次生成怎么改输入”），不拉低总结论
        checks.append({"group": "关键部件", "item": p.get("desc", pid), "value": p.get("note") or "", "pass": p.get("pass"),
                       "record_only": True})
    d = verdicts["damage"]
    checks.append({"group": "破损", "item": d.get("desc", "破损"), "value": d.get("note") or "", "pass": d.get("pass")})

    # 局部放大
    details = []
    for det in asset.get("details", []):
        if det["view"] not in aligned:
            continue
        ra, ga = aligned[det["view"]]
        x0, y0, x1, y1 = det["box"]
        crops = [im.crop((int(x0 * im.width), int(y0 * im.height), int(x1 * im.width), int(y1 * im.height))) for im in (ra, ga)]
        s = 460 / max(c.height for c in crops)
        crops = [c.resize((round(c.width * s), round(c.height * s)), Image.LANCZOS) for c in crops]
        sbs = side_by_side(*crops, labels=["参考图", label])
        sbs.save(adir / f"detail_{det['name']}.jpg", quality=85)
        details.append({"name": det.get("title", det["name"]), "img": b64(sbs, 1300)})
    solid = side_by_side(*[Image.open(rdir / f"solid_{v}.png").convert("RGB").resize((420, 420)) for v in VIEWS])

    judged = judge(checks)
    result = {"schema_version": 2, "label": label, "mode": "baseline" if baseline else "refined",
              "glb": str(glb), "inputs": rinputs, "stats": st, "checks": checks, **judged}
    (adir / "audit.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    write_html(adir / "report.html", asset, label, result, views, details, b64(solid, 1700))
    print(f"结论：{result['verdict']}")
    for x in result["failed"]:
        print("  不过：", x)
    for x in result["recorded"]:
        print("  只记录（对预览图的出入，不拉低结论）：", x)
    for x in result["pending"]:
        print("  待判断：", x)
    print("报告：", adir / "report.html")


def judge(checks):
    """总结论。pass 为 False 且 record_only 的项只记录（对预览图的出入），不算失败；其余 False 才算失败。
    有失败 → 不达标；没失败但还有待看图的 → 待看图判断；都没有 → 达标。"""
    failed = [c for c in checks if c["pass"] is False and not c.get("record_only")]
    recorded = [c for c in checks if c["pass"] is False and c.get("record_only")]
    pending = [c for c in checks if c["pass"] is None]
    name = lambda c: f"{c['group']}·{c['item']}"
    return {"verdict": "不达标" if failed else ("待看图判断" if pending else "达标"),
            "failed": [name(c) for c in failed], "recorded": [name(c) for c in recorded],
            "pending": [name(c) for c in pending]}


def write_html(path, asset, label, result, views, details, solid_img):
    badge = {True: '<b class="ok">过</b>', False: '<b class="no">不过</b>', None: '<b class="wait">待判断</b>'}
    rec = '<b class="rec">只记录</b>'
    rows = "".join(f"<tr><td>{c['group']}</td><td>{c['item']}</td><td>{c['value']}</td>"
                   f"<td>{rec if (c['pass'] is False and c.get('record_only')) else badge[c['pass']]}</td></tr>" for c in result["checks"])
    vhtml = "".join(f"<h3>{VIEW_CN[v]}</h3><img src='{d['img']}'>" for v, d in views.items())
    dhtml = "".join(f"<figure><img src='{d['img']}'><figcaption>{d['name']}</figcaption></figure>" for d in details)
    color = {"达标": "#1e8449", "不达标": "#c0392b", "待看图判断": "#d68910"}[result["verdict"]]
    html = f"""<!doctype html><html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{asset.get('name', asset.get('id'))} 验收 {label}</title><style>
body{{font:15px/1.6 "Microsoft YaHei",system-ui,sans-serif;background:#faf8f5;color:#2b2b2b;margin:0}}
main{{max-width:1200px;margin:0 auto;padding:24px 16px 60px}} img{{max-width:100%;border:1px solid #e6ddd2;background:#fff}}
table{{border-collapse:collapse;width:100%;background:#fff}} td,th{{border:1px solid #e6ddd2;padding:6px 9px;text-align:left;vertical-align:top}}
th{{background:#f1e9df}} .ok{{color:#1e8449}} .no{{color:#c0392b}} .wait{{color:#d68910}} .rec{{color:#7f8c8d}}
.sw{{display:inline-block;width:14px;height:14px;border:1px solid #999;vertical-align:-2px;margin-right:3px}}
.verdict{{font-size:22px;font-weight:700;color:{color}}} figure{{margin:12px 0}} figcaption{{color:#666;font-size:14px}}
</style></head><body><main>
<h1>{asset.get('name', asset.get('id'))} · 验收 {label}</h1>
    <p class="verdict">{'原版诊断' if result['mode'] == 'baseline' else '精修验收'}：{result['verdict']}</p>
    <p>失败 {len(result['failed'])} 项 · 只记录 {len(result['recorded'])} 项（对预览图的出入，以建模为准） · 待看图 {len(result['pending'])} 项。表面相交采用离散角度采样；材质和细节仍需看图判断。</p>
<p>{result['stats']['triangles']:,} 个三角面 · {len(result['stats']['meshes'])} 个网格 · {result['stats']['materials']} 个材质 · 动画 {', '.join(result['stats']['animations']) or '无'}</p>
<h2>逐项检查</h2><table><tr><th>类别</th><th>项目</th><th>结果</th><th>结论</th></tr>{rows}</table>
<h2>四个方向</h2>{vhtml}
<h2>局部放大</h2>{dhtml or '<p>asset.json 里没写 details</p>'}
<h2>灰模（看形状、破洞、折面）</h2><img src="{solid_img}">
</main></body></html>"""
    path.write_text(html, encoding="utf-8")


if __name__ == "__main__":
    main()
