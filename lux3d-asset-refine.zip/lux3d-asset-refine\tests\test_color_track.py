"""audit.color_compare 的逐像素颜色追踪 + 按位置配对：
追踪同一批像素才不会算出假差距；预览图的参考色按图上的位置取，不按“颜色最接近”配。"""
import sys
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import audit  # noqa: E402


def block(rgb, n):
    return np.tile(np.array(rgb, float), (n, 1))


class ColorTrack(unittest.TestCase):
    def setUp(self):
        # 原版：深灰 5000 像素、棕色 5000、浅灰 2000
        self.orig = np.concatenate([block((40, 40, 44), 5000), block((100, 70, 50), 5000), block((130, 125, 128), 2000)])
        # 同一批位置上预览图的颜色：深灰处偏亮、棕色处偏橙、浅灰处略亮
        self.ref_at = np.concatenate([block((52, 50, 56), 5000), block((150, 90, 60), 5000), block((135, 128, 132), 2000)])

    def rows(self, new, ref_at=None):
        return {p["orig"]: p for p in audit.color_compare(None, new, self.orig, self.ref_at if ref_at is None else ref_at)}

    def test_untouched_colors_report_zero_even_when_other_colors_move(self):
        new = self.orig.copy()
        new[5000:10000] = (118, 76, 50)              # 只把棕色往橙挪了一步
        rows = list(self.rows(new).values())
        self.assertEqual(len(rows), 3)
        untouched = [p for p in rows if p["dE_new_orig"] < 0.5]
        moved = [p for p in rows if p["dE_new_orig"] >= 0.5]
        self.assertEqual(len(untouched), 2)          # 深灰、浅灰都没动，不能被棕色的改动连累
        self.assertEqual(len(moved), 1)
        self.assertTrue(4 < moved[0]["dE_new_orig"] < 14)
        self.assertLess(moved[0]["dE"], moved[0]["dE_orig_ref"])      # 往参考图的方向挪了

    def test_collateral_shift_on_a_neutral_color_is_caught(self):
        new = self.orig.copy()
        new[:5000] = (62, 48, 44)                    # 深灰被带红了（收不住的调色范围会这样）
        rows = self.rows(new)
        dark = min(rows.values(), key=lambda p: int(p["orig"][1:3], 16))    # 原版颜色最暗的那行 = 深灰
        self.assertGreater(dark["dE_new_orig"], 8)

    def test_reference_color_is_taken_by_position_not_by_nearest_color(self):
        # 回归：预览图上有一块亮蓝灰布。按“颜色最接近”会把它配给原版里最像它的小色块（这里是浅灰），
        # 按位置配则它只属于原版里它所在位置的那块（深灰）。
        ref_at = self.ref_at.copy()
        ref_at[:5000] = (120, 130, 150)              # 深灰所在位置，预览图上是亮蓝灰布
        rows = self.rows(self.orig, ref_at)
        dark = min(rows.values(), key=lambda p: int(p["orig"][1:3], 16))
        light = max(rows.values(), key=lambda p: int(p["orig"][1:3], 16))
        self.assertEqual(dark["ref"], audit.lab_to_rgb_hex(audit.srgb_to_lab(np.array([[120.0, 130.0, 150.0]]))[0]))
        # 浅灰的参考色不受影响，仍是它自己位置上的颜色（135,128,132）
        self.assertLess(abs(int(light["ref"][1:3], 16) - 135), 4)

    def test_reference_is_the_average_over_lit_and_shadow_positions(self):
        # 一块原版颜色在预览图上有亮面、阴影面：参考色取这块颜色所在位置的平均，只评一次
        ref_at = self.ref_at.copy()
        ref_at[:2500] = (70, 68, 74)
        ref_at[2500:5000] = (30, 28, 32)
        new = self.orig.copy()
        new[:5000] = (46, 46, 50)                    # 深灰提亮一点
        dark = [p for p in audit.color_compare(None, new, self.orig, ref_at) if int(p["orig"][1:3], 16) < 60]
        self.assertEqual(len(dark), 1)
        self.assertLess(dark[0]["dE"], dark[0]["dE_orig_ref"])        # 对平均参考色是更近了

    def test_pixels_without_a_reference_position_are_ignored_and_reported(self):
        ref_at = self.ref_at.copy()
        ref_at[:1000] = np.nan                       # 深灰里有 1000 个像素在预览图上对不到位置
        rows = self.rows(self.orig, ref_at)
        dark = min(rows.values(), key=lambda p: int(p["orig"][1:3], 16))
        self.assertAlmostEqual(dark["ref_coverage"], 0.8, places=1)

    def test_color_with_almost_no_reference_position_is_skipped(self):
        ref_at = self.ref_at.copy()
        ref_at[:5000] = np.nan                       # 深灰在预览图上完全对不到位置
        rows = self.rows(self.orig, ref_at)
        self.assertEqual(len(rows), 2)

    def test_mismatched_pixel_counts_are_rejected(self):
        with self.assertRaises(ValueError):
            audit.color_compare(None, self.orig[:-1], self.orig, self.ref_at)
        with self.assertRaises(ValueError):
            audit.color_compare(None, self.orig, self.orig, self.ref_at[:-1])

    def test_tracking_without_aligned_reference_is_rejected(self):
        with self.assertRaises(ValueError):
            audit.color_compare(self.ref_at, self.orig, self.orig)

    def test_diagnosing_the_original_still_works_without_a_baseline(self):
        rows = audit.color_compare(self.ref_at, self.orig)
        self.assertTrue(rows and all("orig" not in p for p in rows))


class RefColorsAt(unittest.TestCase):
    def square(self, size, box, rgb):
        """size×size 的图，box=(x0,y0,x1,y1) 内填 rgb，其余透明/空。返回 (mask, rgb 图)。"""
        a = np.zeros((size, size), bool)
        img = np.full((size, size, 3), 255, np.uint8)
        x0, y0, x1, y1 = box
        a[y0:y1, x0:x1] = True
        img[y0:y1, x0:x1] = rgb
        return a, Image.fromarray(img)

    def test_left_half_maps_to_left_half_even_when_scale_and_offset_differ(self):
        # 预览图：200×200 的图里，主体 100 宽 × 100 高，左半红右半蓝
        rmask, rimg = self.square(200, (50, 50, 150, 150), (0, 0, 255))
        arr = np.array(rimg)
        arr[50:150, 50:100] = (255, 0, 0)
        rimg = Image.fromarray(arr)
        # 原版渲染：400×400 的图里，主体 200×200（放大一倍、偏右下）
        omask = np.zeros((400, 400), bool)
        omask[120:320, 150:350] = True
        out = audit.ref_colors_at(rimg, rmask, omask, omask)
        ys, xs = np.nonzero(omask)
        left = out[xs < 235]                         # 主体左半（避开红蓝交界处被缩放抹开的那条）
        right = out[xs >= 265]
        ok_l = left[~np.isnan(left).any(1)]
        ok_r = right[~np.isnan(right).any(1)]
        self.assertGreater(len(ok_l), 1000)
        self.assertTrue((ok_l[:, 0] > 200).all() and (ok_l[:, 2] < 50).all())   # 红
        self.assertTrue((ok_r[:, 2] > 200).all() and (ok_r[:, 0] < 50).all())   # 蓝

    def test_pixels_outside_or_at_the_edge_of_the_reference_are_nan(self):
        rmask, rimg = self.square(100, (10, 10, 90, 90), (200, 100, 50))
        omask = np.zeros((100, 100), bool)
        omask[10:90, 0:100] = True                   # 原版比预览图宽：缩到同高后两侧伸出预览图主体
        out = audit.ref_colors_at(rimg, rmask, omask, omask)
        nan = np.isnan(out).any(1)
        ys, xs = np.nonzero(omask)
        self.assertTrue(nan[xs < 8].all() and nan[xs >= 92].all())    # 伸出去的两侧对不上
        self.assertTrue((~nan[(xs >= 15) & (xs < 85)]).all())           # 中间正常取到


if __name__ == "__main__":
    unittest.main()
