"""船长帽精修示例（小手术，只改原件，不新建部件）。2026-11-04 在真实素材上跑通的完整流程。

blender -b --factory-startup -P <skill>/examples/cap_refine.py -- <阶段> <工作目录> [k=v ...]

阶段：
  surgery        定尺寸、清漂浮碎片、小步调色（帽身按颜色半径，皮革 / 黄铜按“面区域”）→ out/cap_surgery.blend
  export         减面烘焙（内置先劈开非流形边）、装位置点和碰撞体、导出 → out/<id>-<tag>.glb
  export_keepuv  回退：不烘焙，在原件副本上直接减面、保留原 UV（会很棱角，只作对比）
  rebake         分开烘：低模不动，只对皮革区域重烘颜色（高模只用皮革的面）→ out/<id>-<tag>.glb

参数 k=v（都有默认值）：
  tag=v1        输出文件的版本标签
  out=out       输出目录名（相对工作目录）
  budget=…      面数预算，默认读 asset.json 的 tri_budget
  ratio=0.97    面数目标 = 预算 × ratio
  cage=0.0025   烘焙笼子（米）。export 默认 0.005；rebake 默认 0.004
  from=v2       rebake 用哪一版 export 的结果当低模
  zmax=0.075    rebake 里“皮带和帽檐”的高度上限（米，已按 height_m 缩放）
  facedist=0.004  rebake 面级限定：低模面中心离皮革高模多近才换

典型顺序（这趟的正确流程）：
  python <skill>/scripts/calibrate_colors.py <工作目录>             # 先量颜色（得到 colors.json），不凭眼睛
  … -- surgery <工作目录>
  … -- export <工作目录> tag=v2 cage=0.0025 ratio=0.97 budget=20000
  … -- rebake <工作目录> from=v2 tag=v8                              # 整体烘焙在薄壳处出斑时才需要

船长帽专用的数字（CEILING_Z、TOP_BUTTON、皮革 / 黄铜的面分类阈值）是从这件原版量的，换素材要重新量。
"""
import json
import sys
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "scripts"))
from refine_lib import *  # noqa: E402,F401
from refine_lib import _lab_to_srgb, _srgb_to_lab  # noqa: E402,F401
from split_bake import rebake_region  # noqa: E402
import bmesh  # noqa: E402
import bpy  # noqa: E402
import numpy as np  # noqa: E402

argv = sys.argv[sys.argv.index("--") + 1:]
STAGE, WORK = argv[0], Path(argv[1]).resolve()
ARGS = dict(a.split("=", 1) for a in argv[2:])
ASSET = json.loads((WORK / "asset.json").read_text(encoding="utf-8-sig"))
SRC = str(Path(ASSET["generated"]) if Path(ASSET["generated"]).is_absolute() else (WORK / ASSET["generated"]).resolve())
COLORS = json.loads((WORK / "colors.json").read_text(encoding="utf-8-sig"))
OUT = WORK / ARGS.get("out", "out")
OUT.mkdir(exist_ok=True)

# ---- 船长帽专用：从原版量的（normalize 到 height_m 之后的坐标）----
CEILING_Z = 0.156                       # 帽内顶的高度（从底面中心往上打射线）
TOP_BUTTON = (0.003, -0.061, 0.173)     # 顶部小圆扣中心
LEATHER_CLASS = dict(chroma_min=11, L_max=45)     # 皮革面：彩度 ≥ 11 且偏暗
BRASS_CLASS = dict(chroma_min=18, L_min=50)       # 黄铜面：彩度 ≥ 18 且偏亮


def hex_rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


def face_classes(ob):
    fs = face_samples(ob)
    lab = _srgb_to_lab(fs["rgb"])
    chroma = np.hypot(lab[:, 1], lab[:, 2])
    leather = (chroma >= LEATHER_CLASS["chroma_min"]) & (lab[:, 0] < LEATHER_CLASS["L_max"])
    brass = (chroma >= BRASS_CLASS["chroma_min"]) & (lab[:, 0] >= BRASS_CLASS["L_min"])
    return fs, leather, brass


def stage_surgery():
    reset_scene()
    ob = import_lux3d(SRC)
    ob.name = "cap"
    print("SCALE", round(normalize(ob, ASSET["height_m"]), 4))
    bm = bmesh.new()
    bm.from_mesh(ob.data)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-4)     # 导入时按 UV 拆开的点合回来（UV 不变）
    bm.to_mesh(ob.data)
    bm.free()
    removed, blocks = remove_small_islands(ob, 200)
    print("ISLANDS 删漂浮碎片", blocks, "块，", removed, "个面")
    # 开口环只统计，不补：1–2 条边、0.4–2.5 mm 的细缝是没焊上的接缝，补洞补不了，焊接会伤形状
    bm = bmesh.new()
    bm.from_mesh(ob.data)
    print("CRACKS", len(boundary_loops(bm)), "个开口环（不动）")
    bm.free()

    base, _ = material_images(ob)
    # 帽身几乎是中性深色：数据显示颜色已对上（need=False）就不动
    body = COLORS.get("body")
    if body and body.get("need", True):
        recolor_texture(base, [(hex_rgb(body["src"]), hex_rgb(body["dst"]), 8)], feather=8)
    # 皮革和黄铜：色移大，按“面区域”限定
    fs, leather, brass = face_classes(ob)
    total = fs["area"].sum()
    for name, fmask in (("leather", leather), ("brass", brass)):
        c = COLORS.get(name)
        if not c or not c.get("need", True):
            continue
        tex_mask = uv_mask(ob, fmask, base.size[0])
        moved = recolor_masked(base, tex_mask, hex_rgb(c["src"]), hex_rgb(c["dst"]), radius=c.get("radius", 30), feather=10)
        print(f"RECOLOR {name}: 面 {int(fmask.sum())}（占表面积 {fs['area'][fmask].sum() / total:.0%}），挪色 {moved} 像素")
    ob["lux3d_origin"] = True
    bpy.ops.wm.save_as_mainfile(filepath=str(OUT / "cap_surgery.blend"))
    print("SURGERY_DONE")


def finish(low, tag):
    """位置点 + 碰撞体 + 标记来源 + 导出。"""
    low.name = low.data.name = "cap_body"
    low["lux3d_origin"] = True
    add_socket("socket_wear", (0.0, 0.0, 0.0), extras={"function": "wear", "head_contact_z": CEILING_Z})
    add_socket("socket_pickup", (TOP_BUTTON[0], TOP_BUTTON[1], TOP_BUTTON[2] + 0.02), extras={"function": "pickup"})
    add_collider("COL_body", [low], mode="hull")
    extras = {"asset_id": ASSET["id"], "asset_name": ASSET["name"], "height_m": ASSET["height_m"],
              "functions": json.dumps(ASSET["functions"], ensure_ascii=False)}
    bpy.context.scene.render.engine = "BLENDER_EEVEE"
    bpy.ops.wm.save_as_mainfile(filepath=str(OUT / f"cap_{tag}_final.blend"))
    export_glb(str(OUT / f"{ASSET['id']}-{tag}.glb"), extras, jpeg_quality=90)
    print("EXPORTED", f"{ASSET['id']}-{tag}.glb")


def target_tris():
    return int(int(ARGS.get("budget", ASSET.get("tri_budget", 20000))) * float(ARGS.get("ratio", 0.97)))


def stage_export():
    bpy.ops.wm.open_mainfile(filepath=str(OUT / "cap_surgery.blend"))
    ob = bpy.data.objects["cap"]
    low = decimate_bake(ob, target_tris(), size=2048, cage=float(ARGS.get("cage", 0.005)))
    bpy.data.objects.remove(ob)
    print("SPLIT_NONMANIFOLD", low.get("split_nonmanifold_edges"))
    finish(low, ARGS.get("tag", "v1"))


def stage_export_keepuv():
    bpy.ops.wm.open_mainfile(filepath=str(OUT / "cap_surgery.blend"))
    ob = bpy.data.objects["cap"]
    low = decimate_keep_uv(ob, target_tris())
    bpy.data.objects.remove(ob)
    finish(low, ARGS.get("tag", "v3"))


def stage_rebake():
    src, tag = ARGS.get("from", "v2"), ARGS.get("tag", "v8")
    zmax = float(ARGS.get("zmax", 0.075))
    bpy.ops.wm.open_mainfile(filepath=str(OUT / f"cap_{src}_final.blend"))
    low = bpy.data.objects["cap_body"]
    with bpy.data.libraries.load(str(OUT / "cap_surgery.blend"), link=False) as (data_from, data_to):
        data_to.objects = ["cap"]
    high = data_to.objects[0]
    bpy.context.collection.objects.link(high)
    fs, leather, brass = face_classes(high)
    z = fs["center"][:, 2]
    # 区域高模：按颜色挑，**必须加高度范围**（只按颜色会把锚徽侧面、帽身上颜色相近的磨损斑也算进去）
    region = (leather | brass) & (z < zmax)
    print("REGION 皮带和帽檐高度内的面", int(region.sum()), f"（占表面积 {fs['area'][region].sum() / fs['area'].sum():.0%}）")
    color = next(i for i in bpy.data.images if i.name.endswith("_color") and i.name.startswith("cap_"))
    lz = np.array([p.center.z for p in low.data.polygons])

    def warm(lab):          # 皮革是暖色；灰白的是原版贴图岛间的蓝灰底色，不换
        return (lab[:, 1] > 2) & (np.hypot(lab[:, 1], lab[:, 2]) >= 8)

    rebake_region(low, high, region, color, normal_image=None,      # 只换颜色，不换法线
                  cage=float(ARGS.get("cage", 0.004)), face_dist=float(ARGS.get("facedist", 0.004)),
                  low_face_ok=lz < zmax + 0.01, accept=warm)
    bpy.data.objects.remove(high)
    bpy.ops.wm.save_as_mainfile(filepath=str(OUT / f"cap_{tag}_final.blend"))
    extras = {"asset_id": ASSET["id"], "asset_name": ASSET["name"], "height_m": ASSET["height_m"],
              "functions": json.dumps(ASSET["functions"], ensure_ascii=False)}
    export_glb(str(OUT / f"{ASSET['id']}-{tag}.glb"), extras, jpeg_quality=90)
    print("EXPORTED", f"{ASSET['id']}-{tag}.glb")


{"surgery": stage_surgery, "export": stage_export, "export_keepuv": stage_export_keepuv, "rebake": stage_rebake}[STAGE]()
