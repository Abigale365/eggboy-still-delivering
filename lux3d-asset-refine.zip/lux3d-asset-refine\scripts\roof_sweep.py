"""屋顶「剖面扫掠」生成器（Blender 内使用，bpy）。

为什么要有它：
  把参考图的屋檐轮廓逐个“投影”到 3D 里（projected），正/背/侧三套檐线互不约束，
  再用手调公式混合，屋檐必然扭曲；高度场网格 z=f(x,y) 也表达不了向下翻卷的檐口。
做法：
  1. 只定义一条“屋顶剖面曲线”(x -> 屋面高度 z) 和一条“进深收束曲线”(t -> 缩放/抬升)。
  2. 屋面 = 剖面沿进深(y)扫掠。前后檐口自动共用同一条剖面，不会互相打架。
  3. 檐口卷边 = 同一条剖面向外偏移 + 圆截面管，保证与屋面严格贴合。
用法（在 Blender 脚本里）：
  import sys; sys.path.insert(0, r"<skill>/scripts")
  from roof_sweep import build_roof
  parts = build_roof(profile=[(x,z),...], depth=(y0,y1), thickness=0.11, eave_radius=0.12,
                     sag=0.10, sides_lift=0.3, mat_tile=m1, mat_eave=m2)
返回 dict: roof / eave_front / eave_back / ridge 四个对象。
"""
import math

import bmesh
import bpy
from mathutils import Vector


def _catmull(points, steps=8):
    p = [points[0]] + list(points) + [points[-1]]
    out = []
    for i in range(1, len(p) - 2):
        a, b, c, d = (Vector(q) for q in p[i - 1:i + 3])
        for j in range(steps):
            t = j / steps
            out.append(tuple(.5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t * t
                                   + (-a + 3 * b - 3 * c + d) * t ** 3)))
    out.append(tuple(points[-1]))
    return out


def _sample(curve, x):
    if x <= curve[0][0]:
        return curve[0][1]
    if x >= curve[-1][0]:
        return curve[-1][1]
    for (a, b), (c, d) in zip(curve, curve[1:]):
        if a <= x <= c:
            return b + (d - b) * (x - a) / max(1e-9, c - a)
    return curve[-1][1]


def _mesh(name, verts, faces, mat=None, smooth=True):
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], faces)
    me.update()
    ob = bpy.data.objects.new(name, me)
    bpy.context.collection.objects.link(ob)
    if mat:
        me.materials.append(mat)
    for p in me.polygons:
        p.use_smooth = smooth
    return ob


def roof_height(profile, x, y, depth, sag, sides_lift):
    """同一条剖面在进深 t 处的屋面高度。
    sag：屋脊中段下沉量；sides_lift：两侧檐口中段上拱量。二者都乘 sin^2(pi t)，
    所以前后檐口(t=0,1)严格回到剖面本身，不会因为混合公式而错位。"""
    y0, y1 = depth
    t = max(0.0, min(1.0, (y - y0) / (y1 - y0)))
    base = _sample(profile, x)
    w = math.sin(math.pi * t) ** 2
    xs = [p[0] for p in profile]
    edge = abs(x - (xs[0] + xs[-1]) / 2) / ((xs[-1] - xs[0]) / 2)   # 0 中线 → 1 边缘
    return base + w * (-sag * (1 - edge) + sides_lift * edge ** 1.4)


def build_roof(profile, depth, thickness=0.11, eave_radius=0.12, sag=0.10, sides_lift=0.3,
               nx=160, ny=60, mat_tile=None, mat_eave=None, smooth_steps=8):
    prof = sorted(_catmull(profile, smooth_steps))
    x0, x1 = prof[0][0], prof[-1][0]
    y0, y1 = depth
    xs = [x0 + (x1 - x0) * i / nx for i in range(nx + 1)]
    ys = [y0 + (y1 - y0) * j / ny for j in range(ny + 1)]
    verts = [(x, y, roof_height(prof, x, y, depth, sag, sides_lift)) for y in ys for x in xs]
    faces = [(j * (nx + 1) + i, j * (nx + 1) + i + 1, (j + 1) * (nx + 1) + i + 1, (j + 1) * (nx + 1) + i)
             for j in range(ny) for i in range(nx)]
    roof = _mesh("Roof_swept", verts, faces, mat_tile)
    bpy.context.view_layer.objects.active = roof
    sol = roof.modifiers.new("thick", "SOLIDIFY")
    sol.thickness = thickness
    sol.offset = -1
    bpy.ops.object.modifier_apply(modifier=sol.name)

    def tube(name, pts, r, mat):
        """沿折线放一根圆截面管（檐口卷边）。"""
        n = 12
        vv, ff = [], []
        P = [Vector(p) for p in pts]
        tans = [(P[min(i + 1, len(P) - 1)] - P[max(0, i - 1)]).normalized() for i in range(len(P))]
        # 平行传输截面帧：逐点用 cross(tangent, 固定轴) 重新挑法向，切线接近该轴时会在分支间跳变，
        # 管子被拧断（B8 侧檐白线的断缝就是这么来的）。这里把上一截面的法向投影到新切线的垂直面。
        ref = Vector((0, 0, 1)) if abs(tans[0].z) < .9 else Vector((1, 0, 0))
        nrm = tans[0].cross(ref).normalized()
        for i, p in enumerate(P):
            if i:
                nrm = (nrm - nrm.dot(tans[i]) * tans[i]).normalized()
            b = tans[i].cross(nrm).normalized()
            for j in range(n):
                a = j * math.tau / n
                vv.append(tuple(p + r * (math.cos(a) * nrm + math.sin(a) * b)))
        for i in range(len(P) - 1):
            for j in range(n):
                a, c = i * n + j, i * n + (j + 1) % n
                ff.append((a, c, c + n, a + n))
        ff += [tuple(reversed(range(n))), tuple(range((len(P) - 1) * n, len(P) * n))]
        return _mesh(name, vv, ff, mat)

    # 前后檐口：沿同一条剖面，向屋面下方偏移半个管径，端部向外卷（curl）
    def eave_line(y, flip):
        pts = [(x, y, roof_height(prof, x, y, depth, sag, sides_lift) - eave_radius * .6) for x in xs]
        return pts
    ef = tube("Eave_front", eave_line(y0, False), eave_radius, mat_eave)
    eb = tube("Eave_back", eave_line(y1, True), eave_radius, mat_eave)
    # 屋脊：剖面最高点连线
    xr = max(prof, key=lambda p: p[1])[0]
    ridge = tube("Ridge", [(xr, y, roof_height(prof, xr, y, depth, sag, sides_lift) + eave_radius * .3)
                           for y in ys], eave_radius * .55, mat_eave)
    return {"roof": roof, "eave_front": ef, "eave_back": eb, "ridge": ridge}


def check_symmetry(profile, depth, sag, sides_lift, tol=1e-6):
    """自检：前后檐口(t=0 与 t=1)的屋面高度必须与剖面一致，否则说明混合公式又把檐线扭了。"""
    prof = sorted(_catmull(profile, 8))
    y0, y1 = depth
    worst = 0.0
    for k in range(0, 41):
        x = prof[0][0] + (prof[-1][0] - prof[0][0]) * k / 40
        for y in (y0, y1):
            worst = max(worst, abs(roof_height(prof, x, y, depth, sag, sides_lift) - _sample(prof, x)))
    return worst <= tol, worst
